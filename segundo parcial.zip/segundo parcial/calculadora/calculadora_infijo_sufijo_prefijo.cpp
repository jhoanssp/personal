#include <iostream>
#include <stack>
#include <string>
#include <cctype>
#include <unordered_map>
#include <windows.h>
#include <conio.h>

// Estructura del nodo del arbol de expresion
struct Nodo {
    char valor;
    Nodo* izquierdo;
    Nodo* derecho;
    Nodo(char val) : valor(val), izquierdo(nullptr), derecho(nullptr) {}
};

// Funcion para verificar si un caracter es un operador
bool esOperador(char c) {
    return (c == '+' || c == '-' || c == '*' || c == '/');
}

// Funcion para validar la expresion infija
bool validarExpresion(const std::string& expresion) {
    for (char c : expresion) {
        if (!std::isdigit(c) && !esOperador(c) && c != '(' && c != ')') {
            return false;
        }
    }
    return true;
}

// Funcion para evaluar una operacion
template<typename T>
T evaluar(T a, T b, char op) {
    switch (op) {
        case '+': return a + b;
        case '-': return a - b;
        case '*': return a * b;
        case '/': return a / b;
        default: throw std::invalid_argument("Operador invalido");
    }
}

// Funcion para convertir de infijo a arbol de expresion
Nodo* infijoAArbol(const std::string& infijo) {
    std::stack<Nodo*> operandos;
    std::stack<char> operadores;
    
    auto precedencia = [](char op) -> int {
        if (op == '+' || op == '-') return 1;
        if (op == '*' || op == '/') return 2;
        return 0;
    };
    
    for (char c : infijo) {
        if (std::isdigit(c)) {
            operandos.push(new Nodo(c));
        } else if (c == '(') {
            operadores.push(c);
        } else if (c == ')') {
            while (!operadores.empty() && operadores.top() != '(') {
                char op = operadores.top(); operadores.pop();
                Nodo* derecho = operandos.top(); operandos.pop();
                Nodo* izquierdo = operandos.top(); operandos.pop();
                Nodo* nodo = new Nodo(op);
                nodo->izquierdo = izquierdo;
                nodo->derecho = derecho;
                operandos.push(nodo);
            }
            operadores.pop();
        } else if (esOperador(c)) {
            while (!operadores.empty() && precedencia(operadores.top()) >= precedencia(c)) {
                char op = operadores.top(); operadores.pop();
                Nodo* derecho = operandos.top(); operandos.pop();
                Nodo* izquierdo = operandos.top(); operandos.pop();
                Nodo* nodo = new Nodo(op);
                nodo->izquierdo = izquierdo;
                nodo->derecho = derecho;
                operandos.push(nodo);
            }
            operadores.push(c);
        }
    }
    
    while (!operadores.empty()) {
        char op = operadores.top(); operadores.pop();
        Nodo* derecho = operandos.top(); operandos.pop();
        Nodo* izquierdo = operandos.top(); operandos.pop();
        Nodo* nodo = new Nodo(op);
        nodo->izquierdo = izquierdo;
        nodo->derecho = derecho;
        operandos.push(nodo);
    }
    
    return operandos.top();
}

// Funcion recursiva para convertir un arbol de expresion a notacion sufija
void arbolASufijo(Nodo* nodo, std::string& resultado) {
    if (nodo == nullptr) return;
    arbolASufijo(nodo->izquierdo, resultado); // Recursividad en subárbol izquierdo
    arbolASufijo(nodo->derecho, resultado);  // Recursividad en subárbol derecho
    resultado += nodo->valor;
}

// Funcion recursiva para convertir un arbol de expresion a notacion prefija
void arbolAPrefijo(Nodo* nodo, std::string& resultado) {
    if (nodo == nullptr) return;
    resultado += nodo->valor;
    arbolAPrefijo(nodo->izquierdo, resultado); // Recursividad en subárbol izquierdo
    arbolAPrefijo(nodo->derecho, resultado);  // Recursividad en subárbol derecho
}

// Funcion recursiva para evaluar un arbol de expresion
template<typename T>
T evaluarArbol(Nodo* nodo) {
    if (!nodo) return 0;
    if (!esOperador(nodo->valor)) return nodo->valor - '0';
    T izquierdo = evaluarArbol<T>(nodo->izquierdo); // Recursividad en subárbol izquierdo
    T derecho = evaluarArbol<T>(nodo->derecho);  // Recursividad en subárbol derecho
    return evaluar(izquierdo, derecho, nodo->valor);
}

// Funcion para convertir una expresion polaca inversa (postfija) a un arbol de expresion
Nodo* postfijoAArbol(const std::string& postfijo) {
    std::stack<Nodo*> pila;
    for (char c : postfijo) {
        if (std::isdigit(c)) {
            pila.push(new Nodo(c));
        } else if (esOperador(c)) {
            Nodo* nodo = new Nodo(c);
            nodo->derecho = pila.top(); pila.pop();
            nodo->izquierdo = pila.top(); pila.pop();
            pila.push(nodo);
        }
    }
    return pila.top();
}

// Funcion para mover el cursor a una posicion especifica en la consola
void gotoxy(int x, int y) {
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

// Opcion del menu para convertir infijo a sufijo
void opcionInfijoASufijo() {
    std::string infijo;
    std::cout << "Introduce la expresion infija: ";
    std::cin.ignore();
    std::getline(std::cin, infijo);

    if (!validarExpresion(infijo)) {
        std::cout << "Expresion invalida. Solo se permiten numeros, operadores y parentesis." << std::endl;
        return;
    }

    Nodo* arbol = infijoAArbol(infijo);
    std::string sufijo;
    arbolASufijo(arbol, sufijo);
    std::cout << "Expresion sufija: " << sufijo << std::endl;
}

// Opcion del menu para evaluar una expresion sufija
void opcionEvaluarSufijo() {
    std::string infijo;
    std::cout << "Introduce la expresion infija: ";
    std::cin.ignore();
    std::getline(std::cin, infijo);

    if (!validarExpresion(infijo)) {
        std::cout << "Expresion invalida. Solo se permiten numeros, operadores y parentesis." << std::endl;
        return;
    }

    Nodo* arbol = infijoAArbol(infijo);
    int resultado = evaluarArbol<int>(arbol);
    std::cout << "Resultado: " << resultado << std::endl;
}

// Opcion del menu para convertir infijo a prefijo
void opcionInfijoAPrefijo() {
    std::string infijo;
    std::cout << "Introduce la expresion infija: ";
    std::cin.ignore();
    std::getline(std::cin, infijo);

    if (!validarExpresion(infijo)) {
        std::cout << "Expresion invalida. Solo se permiten numeros, operadores y parentesis." << std::endl;
        return;
    }

    Nodo* arbol = infijoAArbol(infijo);
    std::string prefijo;
    arbolAPrefijo(arbol, prefijo);
    std::cout << "Expresion prefija: " << prefijo << std::endl;
}

// Opcion del menu para evaluar una expresion prefija
void opcionEvaluarPrefijo() {
    std::string infijo;
    std::cout << "Introduce la expresion infija: ";
    std::cin.ignore();
    std::getline(std::cin, infijo);

    if (!validarExpresion(infijo)) {
        std::cout << "Expresion invalida. Solo se permiten numeros, operadores y parentesis." << std::endl;
        return;
    }

    Nodo* arbol = infijoAArbol(infijo);
    int resultado = evaluarArbol<int>(arbol);
    std::cout << "Resultado: " << resultado << std::endl;
}

// Opcion del menu para convertir polaca inversa a sufijo
void opcionPostfijoASufijo() {
    std::string postfijo;
    std::cout << "Introduce la expresion polaca inversa (postfija): ";
    std::cin.ignore();
    std::getline(std::cin, postfijo);

    if (!validarExpresion(postfijo)) {
        std::cout << "Expresion invalida. Solo se permiten numeros, operadores y parentesis." << std::endl;
        return;
    }

    Nodo* arbol = postfijoAArbol(postfijo);
    std::string sufijo;
    arbolASufijo(arbol, sufijo);
    std::cout << "Expresion sufija: " << sufijo << std::endl;
}

int main() {
    int opcion = 1;
    int key = 0;

    // Ciclo del menu principal con navegacion usando las flechas del teclado
    do {
        system("cls");
        gotoxy(10, 5);
        std::cout << (opcion == 1 ? "> " : "  ") << "Convertir infijo a sufijo";
        gotoxy(10, 6);
        std::cout << (opcion == 2 ? "> " : "  ") << "Evaluar expresion sufija";
        gotoxy(10, 7);
        std::cout << (opcion == 3 ? "> " : "  ") << "Convertir infijo a prefijo";
        gotoxy(10, 8);
        std::cout << (opcion == 4 ? "> " : "  ") << "Evaluar expresion prefija";
        gotoxy(10, 9);
        std::cout << (opcion == 5 ? "> " : "  ") << "Convertir polaca inversa a sufijo";
        gotoxy(10, 10);
        std::cout << (opcion == 6 ? "> " : "  ") << "Salir";

        key = _getch();
        switch(key) {
            case 72: // Flecha arriba
                if(opcion > 1) opcion--;
                break;
            case 80: // Flecha abajo
                if(opcion < 6) opcion++;
                break;
            case 13: // Enter
                system("cls");
                switch(opcion) {
                    case 1: opcionInfijoASufijo(); break;
                    case 2: opcionEvaluarSufijo(); break;
                    case 3: opcionInfijoAPrefijo(); break;
                    case 4: opcionEvaluarPrefijo(); break;
                    case 5: opcionPostfijoASufijo(); break;
                    case 6: break;
                }
                system("pause");
                break;
            default:
                break;
        }
    } while (opcion != 6);
    
    return 0;
}
