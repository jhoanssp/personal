#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <chrono>
#include <algorithm>
#include <conio.h>  // Para _kbhit() y _getch() en Windows

const int width = 40;
const int height = 20;
char board[height][width];
std::vector<std::string> names = {"ALICE", "BOB", "CARL", "DAVID", "EVE"};

void initBoard() {
    for (int i = 0; i < height; ++i)
        for (int j = 0; j < width; ++j)
            board[i][j] = ' ';
}

void displayBoard() {
    system("cls");  // Usa "cls" en Windows, "clear" en Linux
    for (int i = 0; i < width + 2; ++i) std::cout << '#';
    std::cout << '\n';

    for (int i = 0; i < height; ++i) {
        std::cout << '#';
        for (int j = 0; j < width; ++j)
            std::cout << board[i][j];
        std::cout << "#\n";
    }

    for (int i = 0; i < width + 2; ++i) std::cout << '#';
    std::cout << '\n';

    // Mostrar nombres en la parte inferior
    int spacePerName = width / names.size();
    for (const auto& name : names) {
        std::cout << name;
        for (int i = name.length(); i < spacePerName; ++i) {
            std::cout << ' ';
        }
    }
    std::cout << std::endl;
}

bool canMove(int x, int y) {
    return (y >= 0 && y < width && x < height && board[x][y] == ' ');
}

void updateBoard(int &x, int &y, char piece, int dx, int dy) {
    if (canMove(x + dx, y + dy)) {
        board[x][y] = ' ';
        x += dx;
        y += dy;
        board[x][y] = piece;
    }
}

char generateRandomPiece() {
    return 'A' + rand() % 26;
}

bool reachedBottom(int x, int y) {
    return x == height - 1 || board[x + 1][y] != ' ';
}

void processCollision(int x, int y, char piece) {
    int nameIndex = (y / (width / names.size())) % names.size();
    if (names[nameIndex].back() == piece) {
        names[nameIndex].pop_back();
    } else {
        names[nameIndex] += piece;
    }
}

void sleep(int milliseconds) {
    auto start = std::chrono::steady_clock::now();
    auto end = start + std::chrono::milliseconds(milliseconds);
    while (std::chrono::steady_clock::now() < end) {
        // busy wait
    }
}

int main() {
    srand(static_cast<unsigned int>(time(0)));

    initBoard();

    int x = 0, y = width / 2;
    char currentPiece = generateRandomPiece();
    board[x][y] = currentPiece;

    displayBoard();

    while (true) {
        if (_kbhit()) {
            char ch = _getch();
            switch (ch) {
                case 'a':
                    updateBoard(x, y, currentPiece, 0, -1);
                    break;
                case 'd':
                    updateBoard(x, y, currentPiece, 0, 1);
                    break;
            }
        }

        if (reachedBottom(x, y)) {
            if (x == height - 1) {
                processCollision(x, y, currentPiece);
                board[x][y] = ' ';
            }
            x = 0;
            y = width / 2;
            currentPiece = generateRandomPiece();
            if (!canMove(x, y)) {
                std::cout << "Game Over!\n";
                break;
            }
            board[x][y] = currentPiece;
        } else {
            updateBoard(x, y, currentPiece, 1, 0);
        }

        displayBoard();
        sleep(400); // Pausa de 400 ms para actualizar más rápido
    }

    return 0;
}
