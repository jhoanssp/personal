#include <iostream>
#include <stack>
#include <string>
#include <algorithm>

// Funcion para verificar si un caracter es un operador
bool esOperador(char c) {
    return (c == '+' || c == '-' || c == '*' || c == '/');
}

// Funcion para obtener la precedencia de los operadores
int precedencia(char operador) {
    switch (operador) {
        case '+':
        case '-':
            return 1;
        case '*':
        case '/':
            return 2;
    }
    return 0;
}

// Funcion recursiva para convertir infijo a sufijo (RPN)
std::string infijoASufijo(const std::string &expresion, int &i) {
    std::stack<char> operadores;
    std::string resultado;

    while (i < expresion.size()) {
        if (expresion[i] == ' ') {
            i++;
            continue;
        }

        if (isdigit(expresion[i])) {
            resultado += expresion[i++];
        } else if (expresion[i] == '(') {
            i++;
            resultado += infijoASufijo(expresion, i);
        } else if (expresion[i] == ')') {
            i++;
            while (!operadores.empty()) {
                resultado += operadores.top();
                operadores.pop();
            }
            return resultado;
        } else if (esOperador(expresion[i])) {
            while (!operadores.empty() && precedencia(operadores.top()) >= precedencia(expresion[i])) {
                resultado += operadores.top();
                operadores.pop();
            }
            operadores.push(expresion[i++]);
        }
    }

    while (!operadores.empty()) {
        resultado += operadores.top();
        operadores.pop();
    }

    return resultado;
}

// Funcion recursiva para convertir RPN a prefijo
std::string sufijoAPrefijo(const std::string &expresion, int &i) {
    if (i < 0) return "";
    if (isdigit(expresion[i])) return std::string(1, expresion[i--]);

    char operador = expresion[i--];
    std::string operando2 = sufijoAPrefijo(expresion, i);
    std::string operando1 = sufijoAPrefijo(expresion, i);

    return std::string(1, operador) + operando1 + operando2;
}

// Funcion recursiva para convertir prefijo a sufijo
std::string prefijoASufijo(const std::string &expresion, int &i) {
    if (i >= expresion.size()) return "";
    if (isdigit(expresion[i])) return std::string(1, expresion[i++]);

    char operador = expresion[i++];
    std::string operando1 = prefijoASufijo(expresion, i);
    std::string operando2 = prefijoASufijo(expresion, i);

    return operando1 + operando2 + operador;
}

// Funcion recursiva para convertir infijo a prefijo
std::string infijoAPrefijo(const std::string &expresion, int &i) {
    std::stack<char> operadores;
    std::stack<std::string> operandos;

    while (i < expresion.size()) {
        if (expresion[i] == ' ') {
            i++;
            continue;
        }

        if (isdigit(expresion[i])) {
            operandos.push(std::string(1, expresion[i++]));
        } else if (expresion[i] == '(') {
            operadores.push(expresion[i++]);
        } else if (expresion[i] == ')') {
            while (!operadores.empty() && operadores.top() != '(') {
                std::string operando2 = operandos.top(); operandos.pop();
                std::string operando1 = operandos.top(); operandos.pop();
                char operador = operadores.top(); operadores.pop();
                std::string temp = operador + operando1 + operando2;
                operandos.push(temp);
            }
            operadores.pop(); // Eliminar '('
            i++;
        } else if (esOperador(expresion[i])) {
            while (!operadores.empty() && precedencia(operadores.top()) >= precedencia(expresion[i])) {
                std::string operando2 = operandos.top(); operandos.pop();
                std::string operando1 = operandos.top(); operandos.pop();
                char operador = operadores.top(); operadores.pop();
                std::string temp = operador + operando1 + operando2;
                operandos.push(temp);
            }
            operadores.push(expresion[i++]);
        }
    }

    while (!operadores.empty()) {
        std::string operando2 = operandos.top(); operandos.pop();
        std::string operando1 = operandos.top(); operandos.pop();
        char operador = operadores.top(); operadores.pop();
        std::string temp = operador + operando1 + operando2;
        operandos.push(temp);
    }

    return operandos.top();
}

int main() {
    int opcion;

    while (true) {
        std::cout << "\nSeleccione la operacion que desea realizar:\n";
        std::cout << "1. Convertir expresion infija a sufija (RPN)\n";
        std::cout << "2. Convertir expresion sufija (RPN) a prefija\n";
        std::cout << "3. Convertir expresion prefija a sufija (RPN)\n";
        std::cout << "4. Convertir expresion infija a prefija\n";
        std::cout << "5. Salir\n";
        std::cout << "Ingrese su opcion: ";
        std::cin >> opcion;
        std::cin.ignore(); // Ignorar el salto de linea despues de la opcion

        if (opcion == 5) break;

        std::string expresion;
        std::cout << "Ingrese la expresion: ";
        std::getline(std::cin, expresion);

        int index;
        switch(opcion) {
            case 1:
                index = 0;
                std::cout << "Expresion Sufija (RPN): " << infijoASufijo(expresion, index) << std::endl;
                break;
            case 2:
                index = expresion.size() - 1;
                {
                    std::string expresionPrefija = sufijoAPrefijo(expresion, index);
                    std::reverse(expresionPrefija.begin(), expresionPrefija.end());
                    std::cout << "Expresion Prefija: " << expresionPrefija << std::endl;
                }
                break;
            case 3:
                index = 0;
                std::cout << "Expresion Sufija de Prefijo: " << prefijoASufijo(expresion, index) << std::endl;
                break;
            case 4:
                index = 0;
                std::cout << "Expresion Prefija: " << infijoAPrefijo(expresion, index) << std::endl;
                break;
            default:
                std::cout << "Opcion no valida" << std::endl;
        }
    }

    return 0;
}
