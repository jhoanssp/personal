#include "conversions.h"
#include <stack>
#include <string>
#include <algorithm>
#include <sstream>
#include <cctype>
#include <stdexcept>
#include <unordered_set>

bool esCaracterValido(char c) {
    return (isdigit(c) || c == '+' || c == '-' || c == '*' || c == '/' || c == '^' || c == '(' || c == ')' || isspace(c) || isalpha(c));
}

bool esOperador(char c) {
    return (!isdigit(c) && c != ' ' && c != '(' && c != ')' && !isalpha(c));
}

int obtenerPrioridad(char C) {
    if (C == '-' || C == '+')
        return 1;
    else if (C == '*' || C == '/')
        return 2;
    else if (C == '^')
        return 3;
    return 0;
}

bool esFuncion(const std::string& token) {
    static const std::unordered_set<std::string> funciones = {"sqrt", "sin", "cos", "tan"};
    return funciones.find(token) != funciones.end();
}

int obtenerPrioridadFuncion(const std::string& token) {
    if (esFuncion(token))
        return 4;
    return 0;
}

bool esExpresionValida(const std::string& expresion) {
    for (char c : expresion) {
        if (!esCaracterValido(c)) {
            return false;
        }
    }
    return true;
}

std::string infijoASufijo(const std::string& infijo) {
    std::stack<std::string> stk;
    std::string sufijo;
    std::istringstream iss(infijo);
    std::string token;

    while (iss >> token) {
        if (isdigit(token[0]) || isalpha(token[0])) {
            sufijo += token + ' ';
        } else if (esFuncion(token)) {
            stk.push(token);
        } else if (token == "(") {
            stk.push(token);
        } else if (token == ")") {
            while (!stk.empty() && stk.top() != "(") {
                sufijo += stk.top() + ' ';
                stk.pop();
            }
            if (!stk.empty() && stk.top() == "(") {
                stk.pop();
            }
            if (!stk.empty() && esFuncion(stk.top())) {
                sufijo += stk.top() + ' ';
                stk.pop();
            }
        } else {
            while (!stk.empty() && obtenerPrioridad(token[0]) <= obtenerPrioridad(stk.top()[0])) {
                sufijo += stk.top() + ' ';
                stk.pop();
            }
            stk.push(token);
        }
    }

    while (!stk.empty()) {
        sufijo += stk.top() + ' ';
        stk.pop();
    }

    return sufijo;
}

std::string infijoAPrefijo(const std::string& infijo) {
    std::stack<std::string> operadores;
    std::stack<std::string> operandos;
    std::istringstream iss(infijo);
    std::string token;

    while (iss >> token) {
        if (isdigit(token[0]) || isalpha(token[0])) {
            operandos.push(token);
        } else if (esFuncion(token)) {
            operadores.push(token);
        } else if (token == "(") {
            operadores.push(token);
        } else if (token == ")") {
            while (!operadores.empty() && operadores.top() != "(") {
                std::string op = operadores.top();
                operadores.pop();

                if (esFuncion(op)) {
                    std::string op1 = operandos.top();
                    operandos.pop();
                    std::string exp = op + "(" + op1 + ")";
                    operandos.push(exp);
                } else {
                    std::string op1 = operandos.top();
                    operandos.pop();
                    std::string op2 = operandos.top();
                    operandos.pop();
                    std::string exp = op + " " + op2 + " " + op1;
                    operandos.push(exp);
                }
            }
            operadores.pop(); // Remove '('
        } else {
            while (!operadores.empty() && obtenerPrioridad(token[0]) <= obtenerPrioridad(operadores.top()[0])) {
                std::string op = operadores.top();
                operadores.pop();

                if (esFuncion(op)) {
                    std::string op1 = operandos.top();
                    operandos.pop();
                    std::string exp = op + "(" + op1 + ")";
                    operandos.push(exp);
                } else {
                    std::string op1 = operandos.top();
                    operandos.pop();
                    std::string op2 = operandos.top();
                    operandos.pop();
                    std::string exp = op + " " + op2 + " " + op1;
                    operandos.push(exp);
                }
            }
            operadores.push(token);
        }
    }

    while (!operadores.empty()) {
        std::string op = operadores.top();
        operadores.pop();

        if (esFuncion(op)) {
            std::string op1 = operandos.top();
            operandos.pop();
            std::string exp = op + "(" + op1 + ")";
            operandos.push(exp);
        } else {
            std::string op1 = operandos.top();
            operandos.pop();
            std::string op2 = operandos.top();
            operandos.pop();
            std::string exp = op + " " + op2 + " " + op1;
            operandos.push(exp);
        }
    }

    return operandos.top();
}

std::string sufijoAInfijo(const std::string& sufijo) {
    std::stack<std::string> stk;
    std::istringstream iss(sufijo);
    std::string token;

    while (iss >> token) {
        if (isdigit(token[0]) || isalpha(token[0])) {
            stk.push(token);
        } else if (esFuncion(token)) {
            std::string op1 = stk.top(); stk.pop();
            std::string exp = token + "(" + op1 + ")";
            stk.push(exp);
        } else {
            std::string op1 = stk.top(); stk.pop();
            std::string op2 = stk.top(); stk.pop();
            std::string exp = "(" + op2 + " " + token + " " + op1 + ")";
            stk.push(exp);
        }
    }

    return stk.top();
}

std::string prefijoASufijo(const std::string& prefijo) {
    std::stack<std::string> stk;
    std::istringstream iss(prefijo);
    std::string token;
    std::stack<std::string> tokens;

    while (iss >> token) {
        tokens.push(token);
    }

    while (!tokens.empty()) {
        token = tokens.top();
        tokens.pop();

        if (isdigit(token[0]) || isalpha(token[0])) {
            stk.push(token);
        } else if (esFuncion(token)) {
            std::string op1 = stk.top(); stk.pop();
            std::string temp = op1 + " " + token;
            stk.push(temp);
        } else {
            std::string op1 = stk.top(); stk.pop();
            std::string op2 = stk.top(); stk.pop();
            std::string temp = op1 + " " + op2 + " " + token;
            stk.push(temp);
        }
    }

    return stk.top();
}

std::string prefijoAInfijo(const std::string& prefijo) {
    std::stack<std::string> stk;
    std::istringstream iss(prefijo);
    std::string token;
    std::stack<std::string> tokens;

    while (iss >> token) {
        tokens.push(token);
    }

    while (!tokens.empty()) {
        token = tokens.top();
        tokens.pop();

        if (isdigit(token[0]) || isalpha(token[0])) {
            stk.push(token);
        } else if (esFuncion(token)) {
            std::string op1 = stk.top(); stk.pop();
            std::string exp = token + "(" + op1 + ")";
            stk.push(exp);
        } else {
            std::string op1 = stk.top(); stk.pop();
            std::string op2 = stk.top(); stk.pop();
            std::string exp = "(" + op1 + " " + token + " " + op2 + ")";
            stk.push(exp);
        }
    }

    return stk.top();
}

std::string sufijoAPrefijo(const std::string& sufijo) {
    std::stack<std::string> stk;
    std::istringstream iss(sufijo);
    std::string token;

    while (iss >> token) {
        if (isdigit(token[0]) || isalpha(token[0])) {
            stk.push(token);
        } else if (esFuncion(token)) {
            std::string op1 = stk.top(); stk.pop();
            std::string temp = token + " " + op1;
            stk.push(temp);
        } else {
            std::string op1 = stk.top(); stk.pop();
            std::string op2 = stk.top(); stk.pop();
            std::string temp = token + " " + op2 + " " + op1;
            stk.push(temp);
        }
    }

    return stk.top();
}
double evaluarSufijo(const std::string& sufijo) {
    std::stack<double> stk;
    std::istringstream iss(sufijo);
    std::string token;

    while (iss >> token) {
        if (isdigit(token[0])) {
            stk.push(std::stod(token));
        } else {
            double op1 = stk.top(); stk.pop();
            double op2 = stk.top(); stk.pop();
            if (token == "+") stk.push(op2 + op1);
            else if (token == "-") stk.push(op2 - op1);
            else if (token == "*") stk.push(op2 * op1);
            else if (token == "/") stk.push(op2 / op1);
        }
    }

    return stk.top();
}
double evaluarPrefijo(const std::string& prefijo) {
    std::stack<double> stk;
    std::istringstream iss(prefijo);
    std::string token;
    std::stack<std::string> tokens;

    while (iss >> token) {
        tokens.push(token);
    }

    while (!tokens.empty()) {
        token = tokens.top();
        tokens.pop();

        if (isdigit(token[0])) {
            stk.push(std::stod(token));
        } else {
            double op1 = stk.top(); stk.pop();
            double op2 = stk.top(); stk.pop();
            if (token == "+") stk.push(op1 + op2);
            else if (token == "-") stk.push(op1 - op2);
            else if (token == "*") stk.push(op1 * op2);
            else if (token == "/") stk.push(op1 / op2);
        }
    }

    return stk.top();
}
double evaluarInfijo(const std::string& infijo) {
    return evaluarSufijo(infijoASufijo(infijo));
}