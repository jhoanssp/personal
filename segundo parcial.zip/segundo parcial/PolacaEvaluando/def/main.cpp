#include <iostream>
#include <string>
#include <conio.h>
#include "conversions.cpp"

enum OpcionMenu {
    INFIX_TO_POSTFIX_AND_PREFIX,
    POSTFIX_TO_INFIX,
    PREFIX_TO_POSTFIX,
    POSTFIX_TO_PREFIX,
    PREFIX_TO_INFIX,
    EXIT,
    MENU_OPTIONS_COUNT
};

void mostrarMenu(int opcionSeleccionada) {
    system("cls");
    std::string opcionesMenu[MENU_OPTIONS_COUNT] = {
        "Convertir infijo a sufijo y prefijo",
        "Convertir sufijo a infijo",
        "Convertir prefijo a sufijo",
        "Convertir sufijo a prefijo",
        "Convertir prefijo a infijo",
        "Salir"
    };

    std::cout << "Seleccione una opcion:\n";
    for (int i = 0; i < MENU_OPTIONS_COUNT; ++i) {
        if (i == opcionSeleccionada) {
            std::cout << "-> " << opcionesMenu[i] << "\n";
        } else {
            std::cout << "   " << opcionesMenu[i] << "\n";
        }
    }
}

int main() {
    std::string expresion;
    int opcionSeleccionada = 0;
    char tecla;

    do {
        mostrarMenu(opcionSeleccionada);

        tecla = _getch();
        switch (tecla) {
        case 72: // Flecha arriba
            if (opcionSeleccionada > 0) {
                --opcionSeleccionada;
            }
            break;
        case 80: // Flecha abajo
            if (opcionSeleccionada < MENU_OPTIONS_COUNT - 1) {
                ++opcionSeleccionada;
            }
            break;
        case 13: // Tecla Enter
            system("cls");
            try {
                switch (opcionSeleccionada) {
                case INFIX_TO_POSTFIX_AND_PREFIX: {
                    std::cout << "Ingrese la expresion infija: ";
                    std::getline(std::cin, expresion);

                    if (esExpresionValida(expresion)) {
                        std::string sufijo = infijoASufijo(expresion);
                        std::string prefijo = infijoAPrefijo(expresion);

                        std::cout << "Expresion infija: " << expresion << std::endl;
                        std::cout << "Conversion a sufijo: " << sufijo << std::endl;
                        std::cout << "Conversion a prefijo: " << prefijo << std::endl;
                        std::cout << "Resultado expresion: " << evaluarSufijo(sufijo) << std::endl;
                    } else {
                        std::cout << "Entrada invalida. Por favor, ingrese solo numeros y operadores validos.\n";
                    }
                    break;
                }
                case POSTFIX_TO_INFIX: {
                    std::cout << "Ingrese la expresion sufija: ";
                    std::getline(std::cin, expresion);

                    std::string infijo = sufijoAInfijo(expresion);
                    std::string prefijo = sufijoAPrefijo(expresion);
                    std::cout << "Conversion a infijo: " << infijo << std::endl;
                    std::cout << "Resultado Expresion: " << evaluarInfijo(expresion) << std::endl;
                    break;
                }
                case PREFIX_TO_POSTFIX: {
                    std::cout << "Ingrese la expresion prefija: ";
                    std::getline(std::cin, expresion);

                    std::string sufijo = prefijoASufijo(expresion);

                    std::cout << "Conversion a sufijo: " << sufijo << std::endl;
                    std::cout << "Resultado expresion: " << evaluarSufijo(sufijo) << std::endl;
                    break;
                }
                case POSTFIX_TO_PREFIX: {
                    std::cout << "Ingrese la expresion sufija: ";
                    std::getline(std::cin, expresion);

                    std::string prefijo = sufijoAPrefijo(expresion);

                    std::cout << "Conversion a prefijo: " << prefijo << std::endl;
                    std:: cout << "Resultado expresion: " << evaluarPrefijo(prefijo) << std::endl;
                    break;
                }
                case PREFIX_TO_INFIX: {
                    std::cout << "Ingrese la expresion prefija: ";
                    std::getline(std::cin, expresion);

                    std::string infijo = prefijoAInfijo(expresion);

                    std::cout << "Conversion a infijo: " << infijo << std::endl;
                    std::cout << "Resultado de la expresion: " << evaluarPrefijo(expresion) << std::endl;
                    break;
                }
                case EXIT:
                    std::cout << "Saliendo...\n";
                    break;
                }
            } catch (const std::exception& e) {
                std::cout << "Error: " << e.what() << std::endl;
            }
            system("pause");
            break;
        }

    } while (opcionSeleccionada != EXIT || tecla != 13);

    return 0;
}
