#ifndef CONVERSIONS_H
#define CONVERSIONS_H

#include <string>

// Caracteres válidos para la expresión de entrada
bool esCaracterValido(char c);

bool esOperador(char c);

int obtenerPrioridad(char C);

// Función para convertir infijo a sufijo (postfijo)
std::string infijoASufijo(const std::string& infijo);

// Función para convertir infijo a prefijo
std::string infijoAPrefijo(const std::string& infijo);

// Función para convertir sufijo (postfijo) a infijo
std::string sufijoAInfijo(const std::string& sufijo);

// Función para convertir prefijo a sufijo (postfijo)
std::string prefijoASufijo(const std::string& prefijo);

// Función para convertir sufijo (postfijo) a prefijo
std::string sufijoAPrefijo(const std::string& sufijo);

// Función para convertir prefijo a infijo
std::string prefijoAInfijo(const std::string& prefijo);

// Funciones adicionales para operaciones de raíz y trigonométricas
bool esFuncion(const std::string& token);
int obtenerPrioridadFuncion(const std::string& token);
bool esExpresionValida(const std::string& expresion);
double evaluarSufijo(const std::string& sufijo);
double evaluarPrefijo(const std::string& prefijo);
double evaluarInfijo(const std::string& infijo);

#endif
