#include <iostream>
#include <chrono>
#include <cmath>

// Template para medir el tiempo de ejecución de una función lambda con un parámetro de tipo T
template<typename Func, typename T>
void measureTime(Func func, T n, const std::string& complexity) {
    auto start = std::chrono::high_resolution_clock::now();
    func(n);
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> duration = end - start;
    std::cout << "Tiempo para " << complexity << ": " << duration.count() << " segundos." << std::endl;
}

int main() {
    int n = 20;

    // O(1) - Constante
    auto constantFunction = [](int n) {
        int result = n + 1;
    };

    // O(log n) - Logarítmica
    auto logarithmicFunction = [](int n) {
        while (n > 1) {
            n /= 2;
        }
    };

    // O(n) - Lineal
    auto linearFunction = [](int n) {
        for (int i = 0; i < n; ++i) {
            int result = i + 1;
        }
    };

    // O(n log n) - Linealítmica
    auto linearithmicFunction = [](int n) {
        for (int i = 0; i < n; ++i) {
            int j = i;
            while (j > 1) {
                j /= 2;
            }
        }
    };

    // O(n^2) - Cuadrática
    auto quadraticFunction = [](int n) {
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                int result = i + j;
            }
        }
    };

    // O(2^n) - Exponencial
    auto exponentialFunction = [](int n) {
        if (n == 0 || n == 1) return;
        auto recurse = [](int m, auto& recurse_ref) {
            if (m == 0 || m == 1) return;
            recurse_ref(m - 1, recurse_ref);
            recurse_ref(m - 1, recurse_ref);
        };
        recurse(n, recurse);
    };

    std::cout << "Analizando la notación Big O con n = " << n << ":\n";
    measureTime(constantFunction, n, "O(1)");
    measureTime(logarithmicFunction, n, "O(log n)");
    measureTime(linearFunction, n, "O(n)");
    measureTime(linearithmicFunction, n, "O(n log n)");
    measureTime(quadraticFunction, n, "O(n^2)");

    // Reducir n para evitar tiempos de ejecución excesivos en O(2^n)
    n = 20;
    measureTime(exponentialFunction, n, "O(2^n)");

    return 0;
}
