#include <iostream>
#include <fstream>
#include <string>
#include <regex>
#include <filesystem>
#include <chrono>
#include <graphics.h>
#include <cmath>
#include <cstring> // para strcpy
#include <vector>
#include <map>

namespace fs = std::filesystem;

// Plantilla para graficar la función de complejidad
template <typename Func>
void graficarComplejidad(Func funcion, const std::string& etiqueta) {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    // Configurar el título y los ejes
    setcolor(WHITE);
    outtextxy(250, 20, "Grafico de Complejidad");

    setcolor(YELLOW);
    line(50, 400, 600, 400); // Eje X
    line(50, 400, 50, 50);   // Eje Y

    // Etiquetas de los ejes
    outtextxy(600, 410, "Tamaño de Entrada");
    outtextxy(20, 30, "Tiempo");

    // Graficar la función lambda pasada como argumento
    setcolor(CYAN);
    for (int x = 50; x <= 600; x += 1) { // Puntos muy seguidos (incremento de 1)
        int y = funcion(x);  // Usar la función lambda para calcular y
        if (y < 50) { // Detener la gráfica cuando llegue a la parte superior
            break;
        }
        circle(x, y, 2);
    }

    // Convertir la etiqueta de std::string a char* para outtextxy
    char etiquetaChar[100];
    strcpy(etiquetaChar, etiqueta.c_str());
    outtextxy(500, 50, etiquetaChar);

    // Mantener la ventana abierta hasta que el usuario presione una tecla
    std::cout << "Presiona cualquier tecla para cerrar la ventana gráfica...\n";
    getch(); // Esperar la interacción del usuario
    closegraph();
}

// Función para analizar funciones en un archivo
std::vector<std::string> obtenerFunciones(const std::string& codigo) {
    std::regex patronFuncion(R"((\w+\s+)+(\w+)\s*\([^)]*\)\s*\{)");
    std::sregex_iterator iter(codigo.begin(), codigo.end(), patronFuncion);
    std::sregex_iterator end;
    std::vector<std::string> funciones;

    while (iter != end) {
        funciones.push_back((*iter).str());
        ++iter;
    }

    return funciones;
}

// Función para determinar la complejidad del código leído
std::string determinarComplejidad(const std::string& codigo) {
    std::regex patronBucle("(for|while)\\s*\\("); // Patrón para detectar bucles
    std::regex patronRecursion("(\\w+)\\s*\\(.*\\)\\s*\\{[^}]*\\1\\s*\\("); // Patrón para detectar recursión

    int cuentaBucles = 0;
    int cuentaRecursion = 0;

    // Contar bucles en el código
    std::sregex_iterator iter(codigo.begin(), codigo.end(), patronBucle);
    std::sregex_iterator end;
    while (iter != end) {
        cuentaBucles++;
        ++iter;
    }

    // Contar recursiones en el código
    iter = std::sregex_iterator(codigo.begin(), codigo.end(), patronRecursion);
    while (iter != end) {
        cuentaRecursion++;
        ++iter;
    }

    // Determinar la complejidad en función de la cantidad de bucles y recursiones
    if (cuentaRecursion > 0) {
        return "O(2^n)";
    } else if (cuentaBucles > 1) {
        return "O(n^2)";
    } else if (cuentaBucles == 1) {
        return "O(n)";
    } else {
        return "O(1)";
    }
}

int main() {
    std::string rutaDirectorio;
    std::cout << "Ingresa la ruta del directorio a analizar: ";
    std::cin >> rutaDirectorio;

    // Mapear para almacenar funciones por archivo
    std::map<std::string, std::vector<std::string>> funcionesPorArchivo;

    // Medir tiempo total de análisis
    auto inicioTotal = std::chrono::high_resolution_clock::now();

    // Recorrer archivos en el directorio
    for (const auto& entrada : fs::directory_iterator(rutaDirectorio)) {
        if (entrada.path().extension() == ".cpp" || entrada.path().extension() == ".h") {
            std::ifstream archivo(entrada.path());
            if (archivo.is_open()) {
                std::string codigo((std::istreambuf_iterator<char>(archivo)), std::istreambuf_iterator<char>());
                archivo.close();

                // Medir tiempo de análisis por archivo
                auto inicio = std::chrono::high_resolution_clock::now();

                // Obtener funciones del archivo
                std::vector<std::string> funciones = obtenerFunciones(codigo);
                funcionesPorArchivo[entrada.path().string()] = funciones;

                // Determinar complejidad
                std::string complejidad = determinarComplejidad(codigo);
                std::cout << "Archivo: " << entrada.path() << " - Complejidad: " << complejidad << std::endl;

                // Medir tiempo final de análisis por archivo
                auto fin = std::chrono::high_resolution_clock::now();
                std::chrono::duration<double> duracion = fin - inicio;
                std::cout << "Tiempo de análisis para " << entrada.path() << ": " << duracion.count() << " segundos\n";

                // Graficar según la complejidad detectada
                if (complejidad == "O(1)") {
                    auto funcionO1 = [](int x) { return 350; };  // Constante
                    graficarComplejidad(funcionO1, "O(1)");

                } else if (complejidad == "O(log n)") {
                    auto funcionOlogn = [](int x) { return 400 - log(x - 49) * 50; };  // Logarítmica
                    graficarComplejidad(funcionOlogn, "O(log n)");

                } else if (complejidad == "O(n)") {
                    auto funcionOn = [](int x) { return 400 - (x - 50) / 2; };  // Lineal
                    graficarComplejidad(funcionOn, "O(n)");

                } else if (complejidad == "O(n^2)") {
                    auto funcionOn2 = [](int x) { return 400 - ((x - 50) * (x - 50)) / 2000; };  // Cuadrática
                    graficarComplejidad(funcionOn2, "O(n^2)");

                } else if (complejidad == "O(2^n)") {
                    auto funcionO2n = [](int x) { 
                        return 400 - pow(2, (x - 50) / 10);  // Exponencial con escala ajustada
                    };
                    graficarComplejidad(funcionO2n, "O(2^n)");
                }
            }
        }
    }

    // Medir tiempo total de análisis
    auto finTotal = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> duracionTotal = finTotal - inicioTotal;
    std::cout << "Tiempo total de análisis: " << duracionTotal.count() << " segundos\n";

    // Mostrar funciones encontradas por archivo
    std::cout << "\nFunciones encontradas:\n";
    for (const auto& [archivo, funciones] : funcionesPorArchivo) {
        std::cout << "Archivo: " << archivo << std::endl;
        for (const auto& funcion : funciones) {
            std::cout << "  " << funcion << std::endl;
        }
    }

    return 0;
}
