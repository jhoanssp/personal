#include "FileHasher.h"
#include "SHA224.cpp"
#include <fstream>
#include <sstream>
#include <iostream>

string FileHasher::hashFile(const string& filename) {
    ifstream file(filename, ios::binary);
    if (!file) {
        cerr << "No se pudo abrir el archivo: " << filename << endl;
        return "";
    }
    
    stringstream buffer;
    buffer << file.rdbuf();
    string content = buffer.str();
    
    SHA224 sha224;
    return sha224.hash(content);
}
