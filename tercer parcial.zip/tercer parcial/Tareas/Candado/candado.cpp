#include <iostream>
#include <vector>
#include <string>
#include <cstdlib>
#include <ctime>
#include <graphics.h>

using namespace std;

// Función que genera una clave aleatoria de 3 caracteres (letras y números)
template <typename T>
string generarClaveAleatoria(T caracteresPermitidos) {
    string clave = "";
    for (int i = 0; i < 3; ++i) {
        clave += caracteresPermitidos[rand() % caracteresPermitidos.size()];
    }
    return clave;
}

// Función que busca la clave correcta usando fuerza bruta
template <typename T>
bool buscarClavePorFuerzaBruta(const string &clave, T caracteresPermitidos, int candadoX, int candadoY) {
    string intento = "   ";  // Inicializar una clave de 3 caracteres
    for (char c1 : caracteresPermitidos) {
        for (char c2 : caracteresPermitidos) {
            for (char c3 : caracteresPermitidos) {
                intento[0] = c1;
                intento[1] = c2;
                intento[2] = c3;

                // Borrar la clave anterior (rectángulo de fondo negro para eliminar letras basura)
                setcolor(BLACK);
                bar(candadoX - 50, candadoY + 100, candadoX + 50, candadoY + 120);

                // Mostrar la clave que se está probando debajo del candado
                setcolor(WHITE);
                outtextxy(candadoX - 50, candadoY + 100, const_cast<char*>(intento.c_str()));
                delay(10); // Reducción drástica del retraso para una búsqueda mucho más rápida

                // Si la clave es encontrada, cambiar el color del candado a verde
                if (intento == clave) {
                    setcolor(GREEN);
                    rectangle(candadoX - 40, candadoY - 60, candadoX + 40, candadoY + 60);  // Agrandar el candado
                    setfillstyle(SOLID_FILL, GREEN);
                    floodfill(candadoX, candadoY, GREEN);
                    return true;
                }
            }
        }
    }
    return false;
}

// Función para dibujar el candado en el centro de la pantalla, con el centro amarillo
void dibujarCandado(int x, int y) {
    setcolor(WHITE);
    rectangle(x - 40, y - 60, x + 40, y + 60);  // Cuerpo del candado grande
    rectangle(x - 20, y - 100, x + 20, y - 60); // Parte superior del candado

    setfillstyle(SOLID_FILL, YELLOW);  // Centro del candado en amarillo
    floodfill(x, y, WHITE);
}

int main() {
    // Inicializar la semilla del generador de números aleatorios
    srand(time(0));

    // Iniciar el modo gráfico
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    // Coordenadas del centro de la pantalla
    int centerX = getmaxx() / 2;
    int centerY = getmaxy() / 2;

    // Dibujar el candado cerrado en el centro de la pantalla con centro amarillo
    dibujarCandado(centerX, centerY);

    // Conjunto de caracteres permitidos para la generación de claves (letras y números)
    string caracteresPermitidos = "0123456789";
    //ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz
    // Generar la clave a buscar
    string claveABuscar = generarClaveAleatoria(caracteresPermitidos);

    // Mostrar la clave generada a la izquierda del candado
    outtextxy(centerX - 150, centerY, const_cast<char*>(claveABuscar.c_str()));

    // Intentar buscar la clave usando fuerza bruta
    buscarClavePorFuerzaBruta(claveABuscar, caracteresPermitidos, centerX, centerY);

    // Mostrar mensaje de éxito
    outtextxy(centerX - 50, centerY + 120, "Clave encontrada");

    // Esperar a que se cierre la ventana
    getch();
    closegraph();

    return 0;
}
