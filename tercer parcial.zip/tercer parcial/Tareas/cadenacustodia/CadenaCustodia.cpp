#include "CadenaCustodia.h"
#include <openssl/des.h>
#include <sstream>
#include <iomanip>
#include <cstring>  // Incluir cstring para memcpy

// Generar un hash simple usando una función de hash básica (ejemplo: SHA-256)
std::string GenerarHash(const std::string& datos) {
    std::stringstream ss;
    ss << std::hex << std::setfill('0');
    
    for (unsigned char c : datos) {
        ss << std::setw(2) << static_cast<int>(c);
    }

    return ss.str();
}

// Cifrado DES básico usando OpenSSL
std::string CifrarDES(const std::string& datos, const std::string& clave) {
    DES_cblock clave2;
    DES_key_schedule schedule;

    memcpy(clave2, clave.c_str(), 8);
    DES_set_key_checked(&clave2, &schedule);

    DES_cblock entrada;
    DES_cblock salida;
    memcpy(entrada, datos.c_str(), 8);

    DES_ecb_encrypt(&entrada, &salida, &schedule, DES_ENCRYPT);

    std::stringstream ss;
    ss << std::hex << std::setfill('0');

    for (int i = 0; i < 8; ++i) {
        ss << std::setw(2) << static_cast<int>(salida[i]);
    }

    return ss.str();
}
