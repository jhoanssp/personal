#ifndef CADENACUSTODIA_H
#define CADENACUSTODIA_H

#ifdef CADENACUSTODIA_EXPORTS
#define CADENACUSTODIA_API __declspec(dllexport)
#else
#define CADENACUSTODIA_API __declspec(dllimport)
#endif

#include <string>

extern "C" {
    CADENACUSTODIA_API std::string GenerarHash(const std::string& datos);
    CADENACUSTODIA_API std::string CifrarDES(const std::string& datos, const std::string& clave);
}

#endif // CADENACUSTODIA_H
