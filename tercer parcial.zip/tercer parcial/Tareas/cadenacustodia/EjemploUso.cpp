#include <iostream>
#include "CadenaCustodia.h"

int main() {
    std::string cedula = "123456789";
    std::string apellido = "Perez";
    std::string clave = "8bytekey"; // Clave DES de 8 bytes

    // Generar hash de la cédula
    std::string hashCedula = GenerarHash(cedula);
    std::cout << "Hash de la cédula: " << hashCedula << std::endl;

    // Cifrar apellido usando DES
    std::string apellidoCifrado = CifrarDES(apellido, clave);
    std::cout << "Apellido cifrado: " << apellidoCifrado << std::endl;

    return 0;
}
