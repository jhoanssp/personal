#include <iostream>
#include <limits>
#include <graphics.h>
#include <conio.h>
#include <cstring>

using namespace std;

// Función recursiva para encontrar y graficar las combinaciones que suman el número objetivo
void encontrarCombinaciones(int inicio, int sumaActual, int objetivo, int x, int &y, string combinacion, int &yMax) {
    if (sumaActual == objetivo) {
        // Convertir la combinación en texto para la gráfica
        char texto[100];
        strcpy(texto, combinacion.c_str());

        // Imprimir la combinación en la consola
        cout << combinacion << "= " << objetivo << endl;

        // Imprimir la combinación en la pantalla gráfica si está dentro del rango visible
        if (y - yMax >= 0 && y - yMax <= getmaxy()) {
            outtextxy(x, y - yMax, texto);
        }
        y += 20;  // Mover hacia abajo para la próxima combinación
        return;
    }

    // Bucle que recorre desde el número actual (inicio) hasta el objetivo
    for (int i = inicio; i <= objetivo; i++) {
        if (sumaActual + i <= objetivo) {
            string nuevaCombinacion = combinacion + to_string(i) + " ";
            encontrarCombinaciones(i + 1, sumaActual + i, objetivo, x, y, nuevaCombinacion, yMax);
        }
    }
}

// Función para dibujar el botón "X" en la esquina superior derecha
void dibujarBotonCerrar() {
    int anchoBoton = 30;
    int altoBoton = 30;
    int xBoton = getmaxx() - anchoBoton - 10;
    int yBoton = 10;

    setfillstyle(SOLID_FILL, RED);  // Color de fondo del botón
    bar(xBoton, yBoton, xBoton + anchoBoton, yBoton + altoBoton);  // Dibujar botón
    setcolor(WHITE);  // Color del texto "X"
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 2);
    outtextxy(xBoton + 7, yBoton + 5, "X");
}

// Función para verificar si se hizo clic en el botón "X"
bool clicEnBotonCerrar(int x, int y) {
    int anchoBoton = 30;
    int altoBoton = 30;
    int xBoton = getmaxx() - anchoBoton - 10;
    int yBoton = 10;

    return (x >= xBoton && x <= xBoton + anchoBoton && y >= yBoton && y <= yBoton + altoBoton);
}

// Función para actualizar la pantalla gráfica
void actualizarPantalla(int objetivo, int yInicial, int yMax) {
    cleardevice();  // Limpiar la pantalla gráfica

    setcolor(WHITE);  // Asegurar el color blanco del texto
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 2);

    outtextxy(10, 10, "Combinaciones que suman el numero:");

    char objetivoStr[10];
    sprintf(objetivoStr, "%d", objetivo);
    outtextxy(10, 40, objetivoStr);

    int y = yInicial;  // Restaurar la posición inicial para cada nueva impresión
    encontrarCombinaciones(1, 0, objetivo, 10, y, "", yMax);

    dibujarBotonCerrar();  // Dibujar el botón "X"
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");  // Inicializar el modo gráfico
    setbkcolor(BLACK);  // Establecer el fondo negro
    cleardevice();  // Limpiar la pantalla gráfica con el fondo negro

    int objetivo;
    char opcion;

    do {
        while (true) {
            cout << "Introduce el numero maximo al que deseas llegar (solo numeros positivos): ";
            cin >> objetivo;

            if (cin.fail() || objetivo <= 0) {
                cout << "Entrada no valida. Por favor, introduce un numero positivo." << endl;
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
            } else {
                break;
            }
        }

        int yInicial = 70;  // Coordenada Y inicial para las combinaciones
        int yMax = 0;  // Desplazamiento vertical

        actualizarPantalla(objetivo, yInicial, yMax);  // Inicializar la pantalla con la primera impresión

        char tecla;
        bool recargarPantalla = false;

        do {
            if (kbhit()) {
                tecla = getch();  // Capturar la tecla presionada

                if (tecla == 72) {  // Flecha hacia arriba
                    yMax -= 20;
                    if (yMax < 0) {
                        yMax = 0;  // No permitir desplazamiento negativo
                    }
                    recargarPantalla = true;
                } else if (tecla == 80) {  // Flecha hacia abajo
                    yMax += 20;
                    recargarPantalla = true;
                }
            }

            if (ismouseclick(WM_LBUTTONDOWN)) {
                int x, y;
                getmouseclick(WM_LBUTTONDOWN, x, y);
                if (clicEnBotonCerrar(x, y)) {
                    break;  // Salir del bucle si se hace clic en el botón "X"
                }
            }

            if (recargarPantalla) {
                actualizarPantalla(objetivo, yInicial, yMax);
                recargarPantalla = false;
            }

        } while (true);

      // Preguntar si desea realizar otra búsqueda
        while (true) {
            cout << "¿Deseas buscar combinaciones para otro numero? (s/n): ";
            cin >> opcion;

            // Convertir la entrada a minúscula para simplificar la comparación
            opcion = tolower(opcion);

            if (opcion == 's' || opcion == 'n') {
                break;  // Entrada válida, salir del bucle
            } else {
                cout << "Entrada no valida. Por favor, introduce 's' para sí o 'n' para no." << endl;
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
            }
        }

        cin.ignore(numeric_limits<streamsize>::max(), '\n');


    } while (opcion == 's' || opcion == 'S');  // Continuar mientras la opción sea 's' o 'S'

    closegraph();  // Cerrar el modo gráfico

    cout << "Programa finalizado." << endl;

    return 0;
}
