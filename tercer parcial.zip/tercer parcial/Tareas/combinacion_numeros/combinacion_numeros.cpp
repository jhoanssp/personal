#include <iostream>
#include <limits>
#include <graphics.h>
#include <cstring>  // Incluir para usar strcpy

using namespace std;

// Función recursiva para encontrar y graficar las combinaciones que suman el número objetivo
void encontrarCombinaciones(int inicio, int sumaActual, int objetivo, int x, int &y, string combinacion) {
    if (sumaActual == objetivo) {
        // Mostrar la combinación en la consola
        cout << combinacion << endl;

        // Convertir la cadena combinacion a char* para usarla en outtextxy
        char texto[100];
        strcpy(texto, combinacion.c_str());
        
        // Mostrar la combinación completa en la ventana gráfica
        outtextxy(x, y, texto);
        y += 20;  // Mover la posición y hacia abajo para la siguiente combinación
        return;
    }

    // Bucle que recorre desde el número actual (inicio) hasta el objetivo
    for (int i = inicio; i <= objetivo; i++) {
        // Si al agregar el número actual no se excede el objetivo
        if (sumaActual + i <= objetivo) {
            string nuevaCombinacion = combinacion + to_string(i) + " ";
            encontrarCombinaciones(i + 1, sumaActual + i, objetivo, x, y, nuevaCombinacion);
        }
    }
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");  // Inicializar el modo gráfico

    int objetivo;
    char opcion;

    do {
        // Bucle para asegurarse de que el usuario ingrese un número válido
        while (true) {
            cout << "Introduce el numero maximo al que deseas llegar (solo numeros positivos): ";
            cin >> objetivo;

            if (cin.fail() || objetivo <= 0) {
                // Si la entrada no es válida o es un número negativo
                cout << "Entrada no valida. Por favor, introduce un numero positivo." << endl;
                cin.clear();  // Limpiar el estado del error
                cin.ignore(numeric_limits<streamsize>::max(), '\n');  // Descartar la entrada incorrecta
            } else {
                break;  // Entrada válida, salir del bucle
            }
        }

        cleardevice();  // Limpiar la pantalla gráfica antes de comenzar a dibujar
        settextstyle(DEFAULT_FONT, HORIZ_DIR, 2);
        outtextxy(10, 10, "Combinaciones que suman el numero:");

        char objetivoStr[10];
        sprintf(objetivoStr, "%d", objetivo);  // Convertir el objetivo a cadena de caracteres
        outtextxy(10, 40, objetivoStr);  // Mostrar el número objetivo en pantalla

        cout << "Combinaciones que suman " << objetivo << ":" << endl;
        int y = 70;  // Coordenada Y inicial para las combinaciones
        encontrarCombinaciones(1, 0, objetivo, 10, y, "");  // Llamada inicial a la función para encontrar combinaciones

        // Preguntar si desea realizar otra búsqueda
        cout << "¿Deseas buscar combinaciones para otro numero? (s/n): ";
        cin >> opcion;

        // Limpiar la entrada para evitar errores en el siguiente ciclo
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

    } while (opcion == 's' || opcion == 'S');  // Continuar mientras la opción sea 's' o 'S'

    closegraph();  // Cerrar el modo gráfico

    cout << "Programa finalizado." << endl;

    return 0;
}
