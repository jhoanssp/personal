// Imprimir la combinación en la consola
        cout << combinacion << "= " << objetivo << endl;