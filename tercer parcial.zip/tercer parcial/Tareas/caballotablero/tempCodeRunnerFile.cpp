#include <graphics.h>
#include <conio.h>

void drawPixelKnight(int x, int y) {
    // Cambiar el color a rojo
    setcolor(RED);
    setfillstyle(SOLID_FILL, RED);

    // Base del caballo
    rectangle(x, y, x + 40, y + 10);
    floodfill(x + 1, y + 1, RED);

    // Parte inferior de la base
    rectangle(x + 5, y - 5, x + 35, y);
    floodfill(x + 6, y - 4, RED);

    // Cuerpo del caballo
    rectangle(x + 10, y - 20, x + 30, y);
    floodfill(x + 11, y - 19, RED);

    // Cuello del caballo
    rectangle(x + 15, y - 35, x + 25, y - 20);
    floodfill(x + 16, y - 34, RED);

    // Cabeza del caballo
    rectangle(x + 10, y - 45, x + 25, y - 35);
    floodfill(x + 11, y - 44, RED);

    // Oreja del caballo
    line(x + 10, y - 45, x + 15, y - 55);
    line(x + 15, y - 55, x + 20, y - 45);
    floodfill(x + 11, y - 46, RED);

    // Ojo del caballo
    putpixel(x + 20, y - 40, WHITE); // Se deja blanco para destacar sobre el rojo
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    // Dibujar el caballo en pixel art de color rojo
    drawPixelKnight(100, 300);

    getch();
    closegraph();
    return 0;
}
