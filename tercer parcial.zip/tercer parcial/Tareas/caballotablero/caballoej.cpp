#include <graphics.h>
#include <conio.h>

// Función para dibujar un caballo pequeño de ajedrez en estilo pixel art
void dibujarCaballo(int x, int y) {
    // Cambiar el color a rojo
    setcolor(RED);
    setfillstyle(SOLID_FILL, RED);

    // Base del caballo
    rectangle(x, y, x + 20, y + 5);
    floodfill(x + 1, y + 1, RED);

    // Parte inferior de la base
    rectangle(x + 3, y - 3, x + 17, y);
    floodfill(x + 4, y - 2, RED);

    // Cuerpo del caballo
    rectangle(x + 5, y - 10, x + 15, y);
    floodfill(x + 6, y - 9, RED);

    // Cuello del caballo
    rectangle(x + 8, y - 18, x + 12, y - 10);
    floodfill(x + 9, y - 17, RED);

    // Mejora en la cabeza del caballo
    line(x + 8, y - 18, x + 5, y - 23); // Lado izquierdo del cuello a la parte superior de la cabeza
    line(x + 5, y - 23, x + 10, y - 28); // Parte superior de la cabeza
    line(x + 10, y - 28, x + 15, y - 23); // Parte superior derecha de la cabeza
    line(x + 15, y - 23, x + 12, y - 18); // Lado derecho de la cabeza al cuello
    line(x + 12, y - 18, x + 8, y - 18);  // Parte inferior de la cabeza

    // Ojo del caballo
    putpixel(x + 10, y - 21, WHITE); // Se deja blanco para destacar sobre el rojo

    // Parte inferior de la cabeza (hocico)
    line(x + 5, y - 23, x + 8, y - 20);
    line(x + 8, y - 20, x + 10, y - 18);
    floodfill(x + 7, y - 22, RED); // Relleno en la cabeza
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    // Dibujar el caballo en pixel art de color rojo y más pequeño
    dibujarCaballo(100, 200);

    getch();
    closegraph();
    return 0;
}
