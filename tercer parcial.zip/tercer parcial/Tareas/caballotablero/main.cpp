#include "graficos.h"
#include "constantes.h"
#include <graphics.h>
#include <iostream>
#include <conio.h> // Para la función _getch
#include <limits>  // Para numeric_limits
#include <cstdlib> // Para rand() y srand()
#include <ctime>   // Para time()

int N; // Definición de la variable N

// Función para liberar la memoria asignada dinámicamente al tablero
void liberarMemoria(int** tablero, int n) {
    for (int i = 0; i < n; i++) {
        delete[] tablero[i];
    }
    delete[] tablero;
}

// Función para mostrar el menú
void printMenu(const char* menu[], int size, int currentSelection) {
    for (int i = 0; i < size; ++i) {
        if (i == currentSelection) {
            std::cout << "> " << menu[i] << " <" << std::endl;
        } else {
            std::cout << "  " << menu[i] << std::endl;
        }
    }
}

int leerTamanoTablero() {
    int tamano = 0;
    while (true) {
        std::cout << "Ingrese el tamano del tablero (minimo 8): ";
        std::cin >> tamano;
        if (std::cin.fail() || tamano < 8) {
            std::cin.clear(); // Limpiar el error de entrada
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Descartar la entrada inválida
            std::cout << "Entrada no valida. Por favor, ingrese un numero entero mayor o igual a 8." << std::endl;
        } else {
            break; // Salir del bucle si la entrada es válida
        }
    }
    return tamano;
}

int main() {
    const char* menu[] = {"Crear el tablero", "Salir"};
    int menuSize = sizeof(menu) / sizeof(menu[0]);
    int currentSelection = 0;

    srand(time(0)); // Inicializar la semilla para números aleatorios

    while (true) {
        system("cls"); // Limpiar la consola (en Windows)
        printMenu(menu, menuSize, currentSelection);

        char key = _getch();
        if (key == 72) { // Flecha arriba
            currentSelection = (currentSelection - 1 + menuSize) % menuSize;
        } else if (key == 80) { // Flecha abajo
            currentSelection = (currentSelection + 1) % menuSize;
        } else if (key == 13) { // Enter
            if (currentSelection == 1) {
                break; // Salir del bucle si el usuario elige salir
            }

            system("cls");
            N = leerTamanoTablero(); // Leer el tamaño del tablero usando la nueva función

            // Generar una posición aleatoria para el caballo
            int caballoX = rand() % N;
            int caballoY = rand() % N;

            int gd = DETECT, gm;
            initgraph(&gd, &gm, (char*)"C:\\Turboc3\\BGI");

            dibujarTablero(caballoX, caballoY);

            // Mostrar los movimientos posibles del caballo
            mostrarMovimientosCaballo(caballoX, caballoY, N);

            while (true) {
                manejarDesplazamiento(desplazamientoIzquierda, desplazamientoSuperior, getmaxx(), getmaxy(), caballoX, caballoY);
                if (manejarClicCerrar() || GetAsyncKeyState(VK_ESCAPE)) {
                    break;
                }
            }

            closegraph(); // Cerrar la ventana gráfica después de usar
        }
    }

    return 0;
}
