#ifndef GRAFICOS_H
#define GRAFICOS_H

#include <graphics.h>
#include "constantes.h"

// Declaración de las variables globales y constantes para el manejo del gráfico
extern int desplazamientoIzquierda; // Desplazamiento horizontal del tablero
extern int desplazamientoSuperior;  // Desplazamiento vertical del tablero
const int tamanoCelda = 50;         // Tamaño de cada celda del tablero

// Declaración de las funciones de gráficos
void dibujarTablero(int caballoX, int caballoY); // Función para dibujar el tablero y la pieza del caballo
void manejarDesplazamiento(int &desplazamientoX, int &desplazamientoY, int anchoPantalla, int altoPantalla, int caballoX, int caballoY); // Función para manejar el desplazamiento del tablero
void dibujarBotonCerrar(); // Función para dibujar el botón de cerrar la ventana
bool manejarClicCerrar();  // Función para manejar el clic en el botón de cerrar
void mostrarMovimientosCaballo(int x, int y, int N); // Función para mostrar los movimientos posibles del caballo (implementa backtracking)

#endif
