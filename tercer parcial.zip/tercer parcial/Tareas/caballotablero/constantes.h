#ifndef CONSTANTES_H
#define CONSTANTES_H

extern int N; // Declarar N como variable externa

#endif
