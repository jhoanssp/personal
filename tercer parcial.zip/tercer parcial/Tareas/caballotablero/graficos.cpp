#include "graficos.h"
#include <iostream>
#include <windows.h> // Para GetAsyncKeyState
#include <cstdlib>   // Para rand() y srand()
#include <ctime>     // Para time()

int desplazamientoIzquierda = 100;
int desplazamientoSuperior = 100;

// Función para dibujar un caballo pequeño de ajedrez en estilo pixel art
void dibujarCaballo(int x, int y) {
    // Cambiar el color a rojo
    setcolor(RED);
    setfillstyle(SOLID_FILL, RED);

    // Base del caballo
    rectangle(x, y, x + 20, y + 5);
    floodfill(x + 1, y + 1, RED);

    // Parte inferior de la base
    rectangle(x + 3, y - 3, x + 17, y);
    floodfill(x + 4, y - 2, RED);

    // Cuerpo del caballo
    rectangle(x + 5, y - 10, x + 15, y);
    floodfill(x + 6, y - 9, RED);

    // Cuello del caballo
    rectangle(x + 8, y - 18, x + 12, y - 10);
    floodfill(x + 9, y - 17, RED);

    // Mejora en la cabeza del caballo
    line(x + 8, y - 18, x + 5, y - 23); // Lado izquierdo del cuello a la parte superior de la cabeza
    line(x + 5, y - 23, x + 10, y - 28); // Parte superior de la cabeza
    line(x + 10, y - 28, x + 15, y - 23); // Parte superior derecha de la cabeza
    line(x + 15, y - 23, x + 12, y - 18); // Lado derecho de la cabeza al cuello
    line(x + 12, y - 18, x + 8, y - 18);  // Parte inferior de la cabeza

    // Ojo del caballo
    putpixel(x + 10, y - 21, WHITE); // Se deja blanco para destacar sobre el rojo

    // Parte inferior de la cabeza (hocico)
    line(x + 5, y - 23, x + 8, y - 20);
    line(x + 8, y - 20, x + 10, y - 18);
    floodfill(x + 7, y - 22, RED); // Relleno en la cabeza
}

// Función para verificar si una posición es válida en el tablero
bool esPosicionValida(int x, int y, int N) {
    // Verifica si la posición está dentro de los límites del tablero
    return (x >= 0 && x < N && y >= 0 && y < N);
}

// Función para encontrar y mostrar las posiciones a las que se puede mover el caballo
void mostrarMovimientosCaballo(int x, int y, int N) {
    // Definición de los movimientos posibles del caballo en ajedrez
    int movimientos[8][2] = {
        {2, 1}, {1, 2}, {-1, 2}, {-2, 1},
        {-2, -1}, {-1, -2}, {1, -2}, {2, -1}
    };

    int posX, posY;
    std::cout << "Movimientos posibles para el caballo en (" << x << ", " << y << "):" << std::endl;
    // Recorre todos los movimientos posibles del caballo
    for (int i = 0; i < 8; i++) {
        posX = x + movimientos[i][0];
        posY = y + movimientos[i][1];
        // Verifica si la posición es válida
        if (esPosicionValida(posX, posY, N)) {
            std::cout << "Fila: " << posX << ", Columna: " << posY << std::endl;
        }
    }
}

// Función para dibujar el tablero de ajedrez y colocar el caballo
void dibujarTablero(int caballoX, int caballoY) {
    // Limpia la pantalla
    cleardevice();
    // Dibuja el tablero de ajedrez
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            int x = desplazamientoIzquierda + j * tamanoCelda;
            int y = desplazamientoSuperior + i * tamanoCelda;

            // Alterna los colores de las celdas del tablero
            if ((i + j) % 2 == 0)
                setfillstyle(SOLID_FILL, WHITE);
            else
                setfillstyle(SOLID_FILL, BLACK);

            // Dibuja la celda del tablero
            bar(x, y, x + tamanoCelda, y + tamanoCelda);

            // Centrar el caballo en la celda correspondiente
            if (i == caballoY && j == caballoX) {
                int centroX = x + tamanoCelda / 2 - 10; // Ajusta para centrar el caballo horizontalmente
                int centroY = y + tamanoCelda / 2 + 10; // Ajusta para centrar el caballo verticalmente
                dibujarCaballo(centroX, centroY); // Llama a la función para dibujar el caballo
            }
        }
    }
    // Dibuja el botón de cerrar
    dibujarBotonCerrar();
}

// Función para manejar el desplazamiento del tablero
void manejarDesplazamiento(int &desplazamientoX, int &desplazamientoY, int anchoPantalla, int altoPantalla, int caballoX, int caballoY) {
    bool necesitaRedibujar = false;

    // Detecta las teclas de dirección y ajusta el desplazamiento del tablero
    if (GetAsyncKeyState(VK_RIGHT)) {
        desplazamientoX -= 10;
        necesitaRedibujar = true;
    }
    if (GetAsyncKeyState(VK_LEFT)) {
        desplazamientoX += 10;
        necesitaRedibujar = true;
    }
    if (GetAsyncKeyState(VK_DOWN)) {
        desplazamientoY -= 10;
        necesitaRedibujar = true;
    }
    if (GetAsyncKeyState(VK_UP)) {
        desplazamientoY += 10;
        necesitaRedibujar = true;
    }

    // Si se ha detectado movimiento, redibuja el tablero
    if (necesitaRedibujar) {
        cleardevice();
        dibujarTablero(caballoX, caballoY);
        delay(50);
    }
}

// Función para dibujar un botón "X" para cerrar la ventana
void dibujarBotonCerrar() {
    int x1 = getmaxx() - 40;
    int y1 = 10;
    int x2 = getmaxx() - 10;
    int y2 = 40;

    setfillstyle(SOLID_FILL, LIGHTRED);
    bar(x1, y1, x2, y2);
    setcolor(WHITE);
    line(x1, y1, x2, y2);
    line(x1, y2, x2, y1);
}

// Función para manejar el clic en el botón de cerrar
bool manejarClicCerrar() {
    if (ismouseclick(WM_LBUTTONDOWN)) {
        int x, y;
        getmouseclick(WM_LBUTTONDOWN, x, y);
        int x1 = getmaxx() - 40;
        int y1 = 10;
        int x2 = getmaxx() - 10;
        int y2 = 40;

        // Verifica si el clic ocurrió dentro del botón "X"
        if (x >= x1 && x <= x2 && y >= y1 && y <= y2) {
            return true;
        }
    }
    return false;
}
