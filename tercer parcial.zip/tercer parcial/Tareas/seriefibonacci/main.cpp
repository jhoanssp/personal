#include "ArbolRadix.h"
#include "validar.h"
#include "NodoRadix.h"
#include <graphics.h>
#include <iostream>
#include <fstream>
#include <conio.h>
#include <windows.h>
#include <map>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

// Función para mostrar el menú
void printMenu(const char* menu[], int size, int currentSelection) {
    for (int i = 0; i < size; ++i) {
        if (i == currentSelection) {
            cout << "> " << menu[i] << " <" << endl;
        } else {
            cout << "  " << menu[i] << endl;
        }
    }
}

// Función para validar que la entrada sea numérica
bool validarEntradaNumerica(const string &entrada) {
    for (char c : entrada) {
        if (!isdigit(c)) {
            return false;
        }
    }
    return true;
}

// Función para guardar datos en el archivo
void guardarDatosEnArchivo(const string& cedula, const string& nombre, const string& apellido) {
    ofstream archivo("usuarios.txt", ios::app); // Abre el archivo en modo append
    if (archivo.is_open()) {
        archivo << cedula << "|" << nombre << "|" << apellido << endl;
        archivo.close();
    } else {
        cerr << "No se pudo abrir el archivo para escribir." << endl;
    }
}

// Función para cargar datos desde el archivo
void cargarDatosDesdeArchivo(RadixTree &nameTree, RadixTree &surnameTree, map<string, string>& cedulaMap, vector<vector<string>>& usuarios) {
    ifstream archivo("usuarios.txt");
    string linea;
    if (archivo.is_open()) {
        while (getline(archivo, linea)) {
            size_t pos1 = linea.find('|');
            size_t pos2 = linea.find('|', pos1 + 1);
            if (pos1 != string::npos && pos2 != string::npos) {
                string cedula = linea.substr(0, pos1);
                string nombre = linea.substr(pos1 + 1, pos2 - pos1 - 1);
                string apellido = linea.substr(pos2 + 1);
                string userInfo = cedula + " - " + nombre + " - " + apellido;
                nameTree.insert(nombre, userInfo);
                surnameTree.insert(apellido, userInfo);
                cedulaMap[cedula] = userInfo;

                // Agregar usuario a la lista para ordenamiento
                usuarios.push_back({cedula, nombre, apellido});
            }
        }
        archivo.close();
    } else {
        cerr << "No se pudo abrir el archivo para leer." << endl;
    }
}

// Función para mostrar todos los usuarios desde el archivo
void mostrarUsuariosDesdeArchivo() {
    ifstream archivo("usuarios.txt");
    string linea;
    if (archivo.is_open()) {
        cout << "Usuarios registrados:" << endl;
        while (getline(archivo, linea)) {
            cout << linea << endl;
        }
        archivo.close();
    } else {
        cerr << "No se pudo abrir el archivo para leer." << endl;
    }
}

// Función para buscar un usuario en el archivo
bool buscarUsuarioEnArchivo(const string& clave, string &resultado) {
    ifstream archivo("usuarios.txt");
    string linea;
    if (archivo.is_open()) {
        while (getline(archivo, linea)) {
            if (linea.find(clave) != string::npos) {
                resultado = linea;
                archivo.close();
                return true;
            }
        }
        archivo.close();
    } else {
        cerr << "No se pudo abrir el archivo para leer." << endl;
    }
    return false;
}

// Función para eliminar un usuario del archivo y de los árboles
void eliminarUsuarioDelArchivo(const string& cedula, RadixTree& nameTree, RadixTree& surnameTree) {
    ifstream archivo("usuarios.txt");
    ofstream temp("temp.txt");
    string linea;
    bool found = false;  // Indicar si la cédula fue encontrada
    string nombre, apellido;

    if (archivo.is_open() && temp.is_open()) {
        while (getline(archivo, linea)) {
            // Dividir la línea para extraer la cédula
            size_t pos1 = linea.find('|');
            size_t pos2 = linea.find('|', pos1 + 1);
            if (pos1 != string::npos && pos2 != string::npos) {
                string cedulaArchivo = linea.substr(0, pos1);
                nombre = linea.substr(pos1 + 1, pos2 - pos1 - 1);
                apellido = linea.substr(pos2 + 1);

                // Solo eliminar si la cédula coincide
                if (cedulaArchivo != cedula) {
                    temp << linea << endl;
                } else {
                    found = true;
                }
            }
        }
        archivo.close();
        temp.close();
        remove("usuarios.txt");
        rename("temp.txt", "usuarios.txt");

        if (found) {
            // Eliminar del árbol de nombres y apellidos
            nameTree.remove(nombre);
            surnameTree.remove(apellido);
            cout << "Usuario eliminado correctamente." << endl;
        } else {
            cout << "Usuario no encontrado." << endl;
        }
    } else {
        cerr << "No se pudo abrir el archivo para modificar." << endl;
    }
}

// Función para insertar un nodo en el árbol
void insertarNodo(Nodo*& raiz, const string& cedula) {
    if (!raiz) {
        raiz = new Nodo(cedula);
        return;
    }
    if (cedula < raiz->getCedula()) {
        insertarNodo(raiz->getIzquierdo(), cedula);
    } else if (cedula > raiz->getCedula()) {
        insertarNodo(raiz->getDerecho(), cedula);
    }
}

// Función para manejar el desplazamiento
void manejarDesplazamiento(int &xOffset, int &yOffset, int screenWidth, int screenHeight, RadixTree &tree, int &gd, int &gm) {
    bool needRedraw = false;

    if (GetAsyncKeyState(VK_RIGHT)) {  // Mover a la izquierda
        xOffset -= 10;
        needRedraw = true;
    }
    if (GetAsyncKeyState(VK_LEFT)) {  // Mover a la derecha
        xOffset += 10;
        needRedraw = true;
    }
    if (GetAsyncKeyState(VK_DOWN)) {  // Mover hacia arriba
        yOffset -= 10;
        needRedraw = true;
    }
    if (GetAsyncKeyState(VK_UP)) {  // Mover hacia abajo
        yOffset += 10;
        needRedraw = true;
    }

    if (needRedraw) {
        cleardevice();
        tree.drawRadixTree(screenWidth, screenHeight, xOffset, yOffset);
        delay(50);  // Pequeña pausa para estabilizar el redibujado
    }
}

// Función para generar la serie de Fibonacci
void fibonacci(int n, vector<int>& fib) {
    if (n > 0) fib[0] = 0;
    if (n > 1) fib[1] = 1;
    for (int i = 2; i < n; ++i) {
        fib[i] = fib[i - 1] + fib[i - 2];
    }
}

// Función para mostrar la serie de Fibonacci
void mostrarFibonacci(const vector<int>& fib) {
    cout << "Serie de Fibonacci:" << endl;
    for (int num : fib) {
        cout << num << " ";
    }
    cout << endl;
}

// Función para graficar la lista de usuarios ordenados
void graficarUsuarios(const vector<vector<string>>& usuarios, int screenWidth, int screenHeight) {
    // Inicializar la ventana gráfica
    int gd = DETECT, gm;
    initwindow(screenWidth, screenHeight, "Usuarios Ordenados");

    int barWidth = screenWidth / (usuarios.size() + 1); // Ancho de cada barra
    int maxBarHeight = screenHeight - 50; // Altura máxima de las barras (dejando espacio en la parte inferior)

    // Encuentra el máximo valor en la serie de Fibonacci para normalizar las alturas
    int maxValue = usuarios.size();
    // Dibujar las barras para cada valor en la lista de usuarios
    for (int i = 0; i < usuarios.size(); ++i) {
        int barHeight = (i * maxBarHeight) / maxValue; // Normalizar la altura de la barra
        int x = i * barWidth;
        int y = screenHeight - barHeight;

        // Dibuja una barra
        setfillstyle(SOLID_FILL, RED);
        bar(x + 10, y, x + barWidth - 10, screenHeight - 30); // Deja espacio para etiquetas

        // Dibuja el texto sobre la barra
        setcolor(WHITE);
        string texto = usuarios[i][0]; // Usar cédula como etiqueta
        outtextxy(x + 15, screenHeight - 20, texto.c_str()); // Ajusta la posición para que el texto esté centrado
    }

    // Mantener la ventana abierta hasta que el usuario presione una tecla
    getch();
    closegraph();
}

// Función principal
int main() {
    // Obtener las dimensiones de la pantalla
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    RadixTree nameTree;
    RadixTree surnameTree;
    Nodo* cedulaRoot = nullptr;  // Nodo raíz para buscar cédulas repetidas
    map<string, string> cedulaMap; // Mapa para verificar cédulas repetidas
    vector<vector<string>> usuarios; // Lista para ordenar usuarios

    // Cargar datos desde el archivo al iniciar
    cargarDatosDesdeArchivo(nameTree, surnameTree, cedulaMap, usuarios);

    string cedula, nombre, apellido, input, userInfo, resultado;
    int xOffset = 0, yOffset = 0;

    // Definición del menú
    const char* menu[] = {
        "Insertar usuario",
        "Eliminar usuario",
        "Buscar usuario",
        "Mostrar Arbol por Nombre",
        "Mostrar Arbol por Apellido",
        "Mostrar todos los usuarios",
        "Mostrar Serie Fibonacci",
        "Salir"
    };

    int currentSelection = 0;
    int menuSize = sizeof(menu) / sizeof(menu[0]);
    char key;

    do {
        system("cls");  // Limpiar pantalla
        cout << "\t\t.:MENU DE ARBOL RADIX:." << endl;
        printMenu(menu, menuSize, currentSelection);

        key = _getch();

        switch (key) {
            case 72: // Flecha arriba
                if (currentSelection > 0) {
                    currentSelection--;
                }
                break;
            case 80: // Flecha abajo
                if (currentSelection < menuSize - 1) {
                    currentSelection++;
                }
                break;
            case 13: // Enter
                switch (currentSelection) {
                    case 0: { // Insertar usuario
                        // Ingresar y validar la cédula
                        cedula = ingresarCedula("Ingrese la cedula");
                        if (!esNumeroCedulaValido(cedula) || !validarCedula(stol(cedula))) {
                            cout << "Cédula inválida. Intente nuevamente." << endl;
                            break;
                        }
                        if (cedulaMap.find(cedula) != cedulaMap.end()) {
                            cout << "Cédula ya registrada. Intente nuevamente." << endl;
                            break;
                        }

                        // Ingresar y validar el nombre y apellido
                        nombre = convertirMayusculas(ingresarLetras("Ingrese el nombre", false));
                        apellido = convertirMayusculas(ingresarLetras("Ingrese el apellido", false));

                        userInfo = cedula + " - " + nombre + " - " + apellido;
                        nameTree.insert(nombre, userInfo);
                        surnameTree.insert(apellido, userInfo);

                        // Guardar datos en el archivo
                        guardarDatosEnArchivo(cedula, nombre, apellido);

                        // Añadir cédula al mapa para futuras verificaciones
                        cedulaMap[cedula] = userInfo;

                        // Añadir cédula al árbol de cédulas
                        insertarNodo(cedulaRoot, cedula);
                        
                        break;
                    }
                    case 1: { // Eliminar usuario
                        bool exitSubmenu = false;
                        while (!exitSubmenu) {
                            cout << "Ingrese la cédula para eliminar (o 'salir' para volver al menú): ";
                            getline(cin, input);

                            // Salir de este menú
                            if (input == "salir") {
                                exitSubmenu = true;
                                continue;
                            }

                            // Validar que la entrada sea numérica
                            if (!validarEntradaNumerica(input)) {
                                cout << "Entrada inválida. Solo se permiten números." << endl;
                                continue;
                            }

                            eliminarUsuarioDelArchivo(input, nameTree, surnameTree);
                            cedulaMap.erase(input); // Eliminar del mapa
                        }
                        break;
                    }
                    case 2: { // Buscar usuario
                        bool exitSubmenu = false;
                        while (!exitSubmenu) {
                            cout << "Ingrese el nombre, apellido o cédula para buscar (o 'salir' para volver al menú): ";
                            getline(cin, input);

                            // Salir de este menú
                            if (input == "salir") {
                                exitSubmenu = true;
                                continue;
                            }

                            if (buscarUsuarioEnArchivo(input, resultado)) {
                                cout << "Encontrado: " << resultado << endl;
                            } else {
                                cout << "No encontrado." << endl;
                            }
                        }
                        break;
                    }
                    case 3: { // Mostrar Árbol por Nombre
                        // Inicia la ventana gráfica aquí
                        int gd = DETECT, gm;
                        initwindow(screenWidth, screenHeight, "Radix Tree Visualizer");

                        xOffset = 0; yOffset = 0; // Reiniciar desplazamiento
                        cleardevice();  // Limpiar antes de dibujar
                        while (true) {
                            manejarDesplazamiento(xOffset, yOffset, screenWidth, screenHeight, nameTree, gd, gm);
                            int x, y;
                            if (ismouseclick(WM_LBUTTONDOWN)) {
                                getmouseclick(WM_LBUTTONDOWN, x, y);
                                if (nameTree.checkCloseButton(x, y, screenWidth)) {
                                    break;
                                }
                            }
                        }
                        closegraph(); // Cerrar la ventana gráfica después de usar
                        break;
                    }
                    case 4: { // Mostrar Árbol por Apellido
                        // Inicia la ventana gráfica aquí
                        int gd = DETECT, gm;
                        initwindow(screenWidth, screenHeight, "Radix Tree Visualizer");

                        xOffset = 0; yOffset = 0; // Reiniciar desplazamiento
                        cleardevice();  // Limpiar antes de dibujar
                        while (true) {
                            manejarDesplazamiento(xOffset, yOffset, screenWidth, screenHeight, surnameTree, gd, gm);
                            int x, y;
                            if (ismouseclick(WM_LBUTTONDOWN)) {
                                getmouseclick(WM_LBUTTONDOWN, x, y);
                                if (surnameTree.checkCloseButton(x, y, screenWidth)) {
                                    break;
                                }
                            }
                        }
                        closegraph(); // Cerrar la ventana gráfica después de usar
                        break;
                    }
                    case 5: { // Mostrar todos los usuarios
                        mostrarUsuariosDesdeArchivo();
                        cout << "Presione Enter para volver al menú..." << endl;
                        cin.ignore();
                        break;
                    }
                    case 6: { // Mostrar Serie Fibonacci
                        int n;
                        cout << "Ingrese el número de términos de la serie de Fibonacci a mostrar: ";
                        cin >> n;
                        cin.ignore(); // Limpiar el buffer de entrada
                        vector<int> fib(n);
                        fibonacci(n, fib);
                        mostrarFibonacci(fib);

                        // Ordenar los usuarios basados en el índice de Fibonacci
                        sort(usuarios.begin(), usuarios.end(), [&](const vector<string>& a, const vector<string>& b) {
                            return find(fib.begin(), fib.end(), stoi(a[0])) < find(fib.begin(), fib.end(), stoi(b[0]));
                        });

                        // Graficar los usuarios ordenados
                        graficarUsuarios(usuarios, screenWidth, screenHeight);
                        cout << "Presione Enter para volver al menú..." << endl;
                        cin.ignore();
                        break;
                    }
                    case 7: { // Salir
                        cout << "Saliendo del programa..." << endl;
                        return 0;
                    }
                    default:
                        cout << "Opción inválida. Inténtalo nuevamente." << endl;
                        break;
                }
                break;
            default:
                break;
        }
    } while (true);

    return 0;
}
