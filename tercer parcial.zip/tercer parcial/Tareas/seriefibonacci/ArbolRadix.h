#ifndef ARBOLRADIX_H
#define ARBOLRADIX_H

#include <map>
#include <string>

// Clase para representar un árbol radix
class RadixTree {
public:
    // Estructura de nodo para el árbol
    struct Node {
        std::map<char, Node*> children; // Hijos del nodo
        bool isEndOfWord;               // Indica si es el final de una palabra
        std::string userInfo;           // Información del usuario

        // Constructor para inicializar un nodo
        Node() : isEndOfWord(false), userInfo("") {}
    };

    RadixTree();  // Constructor

    // Funciones para insertar, buscar y eliminar
    void insert(const std::string &key, const std::string &userInfo);
    bool search(const std::string &key, std::string &userInfo);
    bool remove(const std::string &key);

    // Funciones para obtener la profundidad máxima y la raíz del árbol
    int getMaxDepth(Node* node);
    Node* getRoot();

    // Funciones para graficar el árbol
    void drawRadixTree(int screenWidth, int screenHeight, int xOffset, int yOffset);
    void drawTree(Node* node, int x, int y, int offsetX, int level);
    void drawNode(int x, int y, const std::string &text, int radius);
    bool checkCloseButton(int x, int y, int screenWidth);

private:
    Node* root; // Raíz del árbol

    // Función auxiliar para eliminar un nodo
    bool remove(Node* node, const std::string &key, int depth);
};

#endif // ARBOLRADIX_H
