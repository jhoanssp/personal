#ifndef NODO_H
#define NODO_H

#include <string>

class Nodo {
public:
    Nodo(const std::string& cedula)
        : cedula(cedula), izquierdo(nullptr), derecho(nullptr) {}

    std::string getCedula() const { return cedula; }
    Nodo*& getIzquierdo() { return izquierdo; }
    Nodo*& getDerecho() { return derecho; }

private:
    std::string cedula;
    Nodo* izquierdo;
    Nodo* derecho;
};

#endif // NODO_H

