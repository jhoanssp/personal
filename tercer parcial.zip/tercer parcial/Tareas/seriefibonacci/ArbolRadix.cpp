#include "ArbolRadix.h"
#include <graphics.h>

// Constructor de la clase RadixTree
RadixTree::RadixTree() {
    root = new Node(); // Inicializar la raíz
}

// Insertar una clave y la información de usuario asociada
void RadixTree::insert(const std::string &key, const std::string &userInfo) {
    Node* currentNode = root;
    for (char ch : key) {
        if (currentNode->children.find(ch) == currentNode->children.end()) {
            currentNode->children[ch] = new Node(); // Crear nuevo nodo si no existe
        }
        currentNode = currentNode->children[ch];
    }
    currentNode->isEndOfWord = true;
    currentNode->userInfo = userInfo; // Almacenar información de usuario
}

// Buscar una clave en el árbol
bool RadixTree::search(const std::string &key, std::string &userInfo) {
    Node* currentNode = root;
    for (char ch : key) {
        if (currentNode->children.find(ch) == currentNode->children.end()) {
            return false; // Clave no encontrada
        }
        currentNode = currentNode->children[ch];
    }
    if (currentNode->isEndOfWord) {
        userInfo = currentNode->userInfo; // Devolver información de usuario
        return true;
    }
    return false;
}

// Eliminar una clave del árbol
bool RadixTree::remove(const std::string &key) {
    return remove(root, key, 0); // Llamada a función auxiliar
}

// Obtener la profundidad máxima del árbol
int RadixTree::getMaxDepth(Node* node) {
    if (!node) return 0;
    int maxDepth = 0;
    for (auto &child : node->children) {
        maxDepth = std::max(maxDepth, getMaxDepth(child.second));
    }
    return maxDepth + 1;
}

// Obtener la raíz del árbol
RadixTree::Node* RadixTree::getRoot() {
    return root;
}

// Función auxiliar para eliminar un nodo
bool RadixTree::remove(Node* node, const std::string &key, int depth) {
    if (!node) return false;
    
    if (depth == key.size()) {
        if (!node->isEndOfWord) return false;
        node->isEndOfWord = false;
        node->userInfo = "";
        return node->children.empty();
    }

    char ch = key[depth];
    if (node->children.find(ch) == node->children.end()) return false;

    bool shouldDeleteChild = remove(node->children[ch], key, depth + 1);

    if (shouldDeleteChild) {
        delete node->children[ch];
        node->children.erase(ch);
        return node->children.empty() && !node->isEndOfWord;
    }

    return false;
}

// Funciones para manejar gráficos

// Dibujar un nodo con texto
void RadixTree::drawNode(int x, int y, const std::string &text, int radius) {
    // Rellenar el círculo en negro
    setfillstyle(SOLID_FILL, BLACK);
    fillellipse(x, y, radius, radius);

    // Dibujar el borde del círculo en rojo
    setcolor(GREEN);
    circle(x, y, radius);

    // Dibujar el texto en verde sobre fondo negro
    setbkcolor(BLACK);
    setcolor(WHITE);
    outtextxy(x - 10, y - 10, const_cast<char*>(text.c_str()));  // Ajustar posición del texto
}

// Dibujar el árbol recursivamente
void RadixTree::drawTree(Node* node, int x, int y, int offsetX, int level) {
    if (!node) return;

    int numChildren = node->children.size();
    int childIndex = 0;

    // Calcular el espaciado dinámico basado en el nivel del nodo
    int dynamicOffset = offsetX / std::max(1, level + 1);

    for (auto &child : node->children) {
        int childX = x + dynamicOffset * (childIndex - numChildren / 2);  // Ajustar posición horizontal
        int childY = y + 120;  // Aumentar espaciado vertical para evitar superposición

        // Dibujar línea de conexión diagonal
        setcolor(BLUE);
        line(x, y + 20, childX, childY - 20);

        drawNode(childX, childY, std::string(1, child.first), 20);  // Nodo secundario más grande
        drawTree(child.second, childX, childY, offsetX, level + 1);  // Ajustar espaciado horizontal

        childIndex++;
    }
}

// Dibujar todo el árbol radix
void RadixTree::drawRadixTree(int screenWidth, int screenHeight, int xOffset, int yOffset) {
    // Limpiar la pantalla y establecer fondo blanco
    setbkcolor(WHITE);
    clearviewport();

    // Calcular la profundidad máxima del árbol para determinar el espaciado
    int maxDepth = getMaxDepth(getRoot());
    int offsetX = screenWidth / (1 << (maxDepth - 1)); // Espaciado horizontal basado en la profundidad del árbol
    if (offsetX < 360) offsetX = 360; // Aumentar el espaciado mínimo para evitar superposición

    // Dibujar el árbol
    drawNode((screenWidth / 2) + xOffset, 100 + yOffset, "Root", 40);  // Nodo raíz más grande
    drawTree(getRoot(), (screenWidth / 2) + xOffset, 100 + yOffset, offsetX, 0);

    // Dibujar botón de cierre más pequeño
    rectangle(screenWidth - 70, 10, screenWidth - 30, 30);
    outtextxy(screenWidth - 60, 15, "X");
}

// Verificar si se presionó el botón de cierre
bool RadixTree::checkCloseButton(int x, int y, int screenWidth) {
    return (x >= screenWidth - 70 && x <= screenWidth - 30 && y >= 10 && y <= 30);
}
