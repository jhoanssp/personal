    // Solicitar la fecha al usuario
    dia = solicitarEntrada("Ingrese el día de hoy (dd): ", 1, 31);
    mes = solicitarEntrada("Ingrese el mes de hoy (mm): ", 1, 12);
    anio = solicitarEntrada("Ingrese el año de hoy (aaaa): ", 1900, 2100);

    // Crear la estructura de tiempo para la fecha ingresada
    std::tm fechaUsuario = {};
    fechaUsuario.tm_mday = dia;
    fechaUsuario.tm_mon = mes - 1;
    fechaUsuario.tm_year = anio - 1900;

    // Verificar que la fecha ingresada esté dentro del rango permitido
    if (!validarRangoFecha(&fechaUsuario, fechaActual, 5)) {
        std::cout << "La fecha ingresada no está dentro del rango permitido de 5 días antes o después de la fecha actual.\n";
        return 1;
    }