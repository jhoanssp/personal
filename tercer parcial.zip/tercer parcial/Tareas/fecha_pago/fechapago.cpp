#include <iostream>
#include <ctime>
#include <set>
#include <sstream>
#include <functional>
#include <graphics.h>

const int MAX_FILAS = 10;
const int COL_WIDTH = 150;

// Template para validar si una fecha es válida según las restricciones dadas
template<typename T>
bool validarFecha(T dia, T mes, T anio) {
    if (anio < 1900 || anio > 2100 || mes < 1 || mes > 12 || dia < 1 || dia > 31) {
        return false;
    }
    return true;
}

// Función para convertir una fecha específica a time_t
std::time_t convertirFecha(int dia, int mes, int anio) {
    std::tm fecha = {};
    fecha.tm_mday = dia;
    fecha.tm_mon = mes - 1;
    fecha.tm_year = anio - 1900;
    return std::mktime(&fecha);
}

// Función para verificar si un año es bisiesto
bool esBisiesto(int anio) {
    return (anio % 4 == 0 && anio % 100 != 0) || (anio % 400 == 0);
}

// Función lambda para determinar si un día es fin de semana
auto esFinDeSemana = [](std::time_t fecha) {
    std::tm* tm = std::localtime(&fecha);
    int diaSemana = tm->tm_wday;
    return diaSemana == 0 || diaSemana == 6; // Domingo o Sábado
};

// Función para ajustar al siguiente día laborable
std::time_t ajustarDiaLaborable(std::time_t fecha, const std::set<std::time_t>& feriados) {
    // Lambda para verificar si una fecha es feriado o fin de semana
    auto esDiaInvalido = [&](std::time_t f) {
        return esFinDeSemana(f) || feriados.find(f) != feriados.end();
    };

    while (esDiaInvalido(fecha)) {
        fecha += 24 * 3600; // Avanzar un día
    }
    return fecha;
}

// Función para imprimir la fecha en formato dd-mm-aaaa
void imprimirFecha(std::time_t fecha) {
    std::tm* tm = std::localtime(&fecha);
    std::cout << (tm->tm_mday < 10 ? "0" : "") << tm->tm_mday << "-"
              << (tm->tm_mon + 1 < 10 ? "0" : "") << tm->tm_mon + 1 << "-"
              << tm->tm_year + 1900 << std::endl;
}

// Función recursiva para calcular e imprimir las fechas de pago
void calcularFechasPago(std::tm* tm, int cuotasRestantes, const std::set<std::time_t>& feriados, int x, int y, int columna, int& totalColumnas) {
    if (cuotasRestantes == 0) {
        totalColumnas = columna;
        return;
    }

    tm->tm_mon += 1; // Avanzar un mes
    std::time_t fechaPago = std::mktime(tm);

    // Ajustar si la fecha cae en un día no laborable
    if (esFinDeSemana(fechaPago) || feriados.find(fechaPago) != feriados.end()) {
        fechaPago = ajustarDiaLaborable(fechaPago, feriados);
    }

    std::tm* fechaTm = std::localtime(&fechaPago);
    std::ostringstream oss;
    oss << (fechaTm->tm_mday < 10 ? "0" : "") << fechaTm->tm_mday << "-"
        << (fechaTm->tm_mon + 1 < 10 ? "0" : "") << fechaTm->tm_mon + 1 << "-"
        << fechaTm->tm_year + 1900;

    // Imprimir la fecha en la consola
    std::cout << oss.str() << std::endl;

    // Imprimir la fecha usando graphics.h
    std::string fechaStr = oss.str();
    outtextxy(x + columna * COL_WIDTH, y, const_cast<char*>(fechaStr.c_str()));

    // Si llegamos al límite de filas, pasamos a la siguiente columna
    if ((cuotasRestantes % MAX_FILAS) == 1) {
        calcularFechasPago(std::localtime(&fechaPago), cuotasRestantes - 1, feriados, x, y, columna + 1, totalColumnas);
    } else {
        calcularFechasPago(std::localtime(&fechaPago), cuotasRestantes - 1, feriados, x, y + 30, columna, totalColumnas);
    }
}

// Función para validar la entrada del usuario
int solicitarEntrada(const std::string& mensaje, int min, int max) {
    int valor;
    std::string entrada;
    while (true) {
        std::cout << mensaje;
        std::getline(std::cin, entrada);
        std::stringstream ss(entrada);
        if (ss >> valor && valor >= min && valor <= max && ss.eof()) {
            break; // Entrada válida
        } else {
            std::cout << "Entrada inválida. Intente nuevamente.\n";
        }
    }
    return valor;
}

// Función para verificar si la fecha ingresada por el usuario está dentro del rango permitido
bool validarRangoFecha(std::tm* fechaUsuario, std::tm* fechaActual, int rango) {
    std::time_t tiempoUsuario = std::mktime(fechaUsuario);
    std::time_t tiempoActual = std::mktime(fechaActual);

    double diferenciaDias = std::difftime(tiempoUsuario, tiempoActual) / (24 * 3600);

    return std::abs(diferenciaDias) <= rango;
}

// Función para mostrar las fechas en un recuadro utilizando graphics.h
void mostrarFechas(int cuotas, std::tm* fechaActual, const std::set<std::time_t>& feriados) {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    // Título
    settextstyle(SANS_SERIF_FONT, HORIZ_DIR, 3);
    outtextxy(150, 20, "Fechas a Pagar");

    // Dibujar el recuadro
    rectangle(100, 80, 640, 400);

    // Calcular y mostrar las fechas dentro del recuadro
    settextstyle(SANS_SERIF_FONT, HORIZ_DIR, 1);
    int totalColumnas = 1;
    calcularFechasPago(fechaActual, cuotas, feriados, 120, 100, 0, totalColumnas);

    // Navegación con el teclado
    int x = 120, y = 100;
    while (true) {
        char tecla = getch();
        switch (tecla) {
            case 72: // Flecha arriba
                if (y > 100) {
                    y -= 30;
                }
                break;
            case 80: // Flecha abajo
                if (y < 100 + (MAX_FILAS - 1) * 30) {
                    y += 30;
                }
                break;
            case 75: // Flecha izquierda
                if (x > 120) {
                    x -= COL_WIDTH;
                }
                break;
            case 77: // Flecha derecha
                if (x < 120 + (totalColumnas - 1) * COL_WIDTH) {
                    x += COL_WIDTH;
                }
                break;
            case 27: // Esc para salir
                closegraph();
                return;
        }
        // Mostrar el rectángulo resaltado
        rectangle(x, y, x + COL_WIDTH - 30, y + 30);
    }

    closegraph();
}

int main() {
    std::time_t now = std::time(nullptr);
    std::tm* fechaActual = std::localtime(&now);
    
    int dia, mes, anio, cuotas;

    // Solicitar la fecha al usuario hasta que ingrese una fecha válida
    do {
        dia = solicitarEntrada("Ingrese el día de hoy (dd): ", 1, 31);
        mes = solicitarEntrada("Ingrese el mes de hoy (mm): ", 1, 12);
        anio = solicitarEntrada("Ingrese el año de hoy (aaaa): ", 1900, 2100);

        // Crear la estructura de tiempo para la fecha ingresada
        std::tm fechaUsuario = {};
        fechaUsuario.tm_mday = dia;
        fechaUsuario.tm_mon = mes - 1;
        fechaUsuario.tm_year = anio - 1900;

        // Verificar que la fecha ingresada esté dentro del rango permitido
        if (validarRangoFecha(&fechaUsuario, fechaActual, 5)) {
            break; // Fecha válida
        } else {
            std::cout << "La fecha ingresada no está dentro del rango permitido de 5 días antes o después de la fecha actual.\n";
        }
    } while (true);

    cuotas = solicitarEntrada("Ingrese el número de cuotas a diferir (1-48): ", 1, 48);

    // Días feriados en Ecuador
    std::set<std::time_t> feriados = {
        convertirFecha(1, 1, fechaActual->tm_year + 1900),
        convertirFecha(12, 2, fechaActual->tm_year + 1900),
        convertirFecha(13, 2, fechaActual->tm_year + 1900),
        convertirFecha(29, 3, fechaActual->tm_year + 1900),
        convertirFecha(10, 5, fechaActual->tm_year + 1900),
        convertirFecha(24, 5, fechaActual->tm_year + 1900),
        convertirFecha(9, 8, fechaActual->tm_year + 1900),
        convertirFecha(11, 10, fechaActual->tm_year + 1900),
        convertirFecha(1, 11, fechaActual->tm_year + 1900),
        convertirFecha(4, 11, fechaActual->tm_year + 1900),
        convertirFecha(25, 12, fechaActual->tm_year + 1900)
    };

    // Mostrar las fechas utilizando graphics.h
    mostrarFechas(cuotas, fechaActual, feriados);

    return 0;
}
