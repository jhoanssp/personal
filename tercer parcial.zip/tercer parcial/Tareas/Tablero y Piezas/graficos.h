#ifndef GRAFICOS_H
#define GRAFICOS_H

#include <graphics.h>
#include "constantes.h"

// Declaración de las variables globales y constantes para el manejo del gráfico
extern int desplazamientoIzquierda;
extern int desplazamientoSuperior;
const int tamanoCelda = 50;

// Declaración de las funciones de gráficos
void dibujarTablero(int** tablero);
void manejarDesplazamiento(int &desplazamientoX, int &desplazamientoY, int anchoPantalla, int altoPantalla, int** tablero);
bool ventanaCerrada(); // Nueva función para verificar si la ventana gráfica está cerrada
void dibujarBotonCerrar();
bool manejarClicCerrar();
void inicializarPiezasAjedrez(int** tablero);

#endif
