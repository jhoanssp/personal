#include "graficos.h"
#include <iostream>
#include <windows.h> // Para GetAsyncKeyState

int desplazamientoIzquierda = 100;
int desplazamientoSuperior = 100;

// Códigos para las piezas de ajedrez
enum Piezas {
    VACIO = 0,
    PEON = 1,
    TORRE = 2,
    CABALLO = 3,
    ALFIL = 4,
    REINA = 5,
    REY = 6
};

// Colores para las piezas
const int COLOR_BLANCO = LIGHTGRAY;
const int COLOR_NEGRO = DARKGRAY;

// Función para dibujar las piezas de ajedrez
void dibujarPieza(int pieza, int x, int y, int color) {
    setcolor(color);
    switch (pieza) {
        case PEON:
            circle(x + tamanoCelda / 2, y + tamanoCelda / 2, tamanoCelda / 4);
            break;
        case TORRE:
            rectangle(x + tamanoCelda / 4, y + tamanoCelda / 4, x + 3 * tamanoCelda / 4, y + 3 * tamanoCelda / 4);
            break;
        case CABALLO:
            ellipse(x + tamanoCelda / 2, y + tamanoCelda / 2, 0, 360, tamanoCelda / 4, tamanoCelda / 8);
            break;
        case ALFIL:
            line(x + tamanoCelda / 2, y + tamanoCelda / 4, x + tamanoCelda / 2, y + 3 * tamanoCelda / 4);
            break;
        case REINA:
            rectangle(x + tamanoCelda / 3, y + tamanoCelda / 3, x + 2 * tamanoCelda / 3, y + 2 * tamanoCelda / 3);
            break;
        case REY:
            line(x + tamanoCelda / 3, y + tamanoCelda / 3, x + 2 * tamanoCelda / 3, y + 2 * tamanoCelda / 3);
            break;
    }
}

void dibujarTablero(int** tablero) {
    cleardevice();
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            int x = desplazamientoIzquierda + j * tamanoCelda;
            int y = desplazamientoSuperior + i * tamanoCelda;

            if ((i + j) % 2 == 0)
                setfillstyle(SOLID_FILL, WHITE);
            else
                setfillstyle(SOLID_FILL, BLACK);

            bar(x, y, x + tamanoCelda, y + tamanoCelda);

            // Dibujar las piezas de ajedrez
            if (tablero[i][j] != VACIO) {
                int color = (i < 2) ? COLOR_NEGRO : COLOR_BLANCO;
                dibujarPieza(tablero[i][j], x, y, color);
            }
        }
    }
    dibujarBotonCerrar();
}


void manejarDesplazamiento(int &desplazamientoX, int &desplazamientoY, int anchoPantalla, int altoPantalla, int** tablero) {
    bool necesitaRedibujar = false;

    if (GetAsyncKeyState(VK_RIGHT)) {
        desplazamientoX -= 10;
        necesitaRedibujar = true;
    }
    if (GetAsyncKeyState(VK_LEFT)) {
        desplazamientoX += 10;
        necesitaRedibujar = true;
    }
    if (GetAsyncKeyState(VK_DOWN)) {
        desplazamientoY -= 10;
        necesitaRedibujar = true;
    }
    if (GetAsyncKeyState(VK_UP)) {
        desplazamientoY += 10;
        necesitaRedibujar = true;
    }

    if (necesitaRedibujar) {
        cleardevice();
        dibujarTablero(tablero);
        delay(50);
    }
}


// Función para dibujar el botón "X" en la esquina superior derecha
void dibujarBotonCerrar() {
    int x1 = getmaxx() - 40;
    int y1 = 10;
    int x2 = getmaxx() - 10;
    int y2 = 40;

    setfillstyle(SOLID_FILL, LIGHTRED);
    bar(x1, y1, x2, y2);
    setcolor(WHITE);
    line(x1, y1, x2, y2);
    line(x1, y2, x2, y1);
}

// Función para manejar el clic en el botón "X"
bool manejarClicCerrar() {
    if (ismouseclick(WM_LBUTTONDOWN)) {
        int x, y;
        getmouseclick(WM_LBUTTONDOWN, x, y);
        int x1 = getmaxx() - 40;
        int y1 = 10;
        int x2 = getmaxx() - 10;
        int y2 = 40;

        if (x >= x1 && x <= x2 && y >= y1 && y <= y2) {
            return true;
        }
    }
    return false;
}

// Función para inicializar las piezas de ajedrez en el tablero
void inicializarPiezasAjedrez(int** tablero) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            tablero[i][j] = VACIO; // Inicializar cada celda como vacía
        }
    }

    // Colocar las piezas de ajedrez para ambos lados
    if (N >= 8) {
        for (int j = 0; j < 8; j++) {
            tablero[1][j] = PEON; // Peones negros
            tablero[N - 2][j] = PEON; // Peones blancos
        }
        tablero[0][0] = tablero[0][7] = TORRE; // Torres negras
        tablero[0][1] = tablero[0][6] = CABALLO; // Caballos negros
        tablero[0][2] = tablero[0][5] = ALFIL; // Alfiles negros
        tablero[0][3] = REINA; // Reina negra
        tablero[0][4] = REY; // Rey negro

        tablero[N - 1][0] = tablero[N - 1][7] = TORRE; // Torres blancas
        tablero[N - 1][1] = tablero[N - 1][6] = CABALLO; // Caballos blancos
        tablero[N - 1][2] = tablero[N - 1][5] = ALFIL; // Alfiles blancos
        tablero[N - 1][3] = REINA; // Reina blanca
        tablero[N - 1][4] = REY; // Rey blanco
    }
}
