
#include <iostream>

// Función recursiva para resolver las Torres de Hanoi
void hanoi(int n, char origen, char destino, char aux) {
    if (n == 1) {
        std::cout << "Mover disco 1 de la torre " << origen << " a la torre " << destino << std::endl;
        return;
    }
    hanoi(n - 1, origen, aux, destino);
    std::cout << "Mover disco " << n << " de la torre " << origen << " a la torre " << destino << std::endl;
    hanoi(n - 1, aux, destino, origen);
}

int main() {
    int n;
    std::cout << "Introduce el número de discos: ";
    std::cin >> n;
    hanoi(n, 'A', 'C', 'B'); // A, B y C son los nombres de las torres
    return 0;
}

