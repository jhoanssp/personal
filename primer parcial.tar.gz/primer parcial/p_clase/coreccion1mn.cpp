#include <iostream>
#include <vector>
#include <stdexcept>

using namespace std;

typedef vector<vector<int>> Matriz;

// Función para multiplicar dos matrices de diferentes tamaños
Matriz multiplicar(const Matriz& A, const Matriz& B) {
    int filasA = A.size();
    int columnasA = A[0].size();
    int columnasB = B[0].size();
    Matriz C(filasA, vector<int>(columnasB, 0));
    for (int i = 0; i < filasA; ++i) {
        for (int j = 0; j < columnasB; ++j) {
            for (int k = 0; k < columnasA; ++k) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
    return C;
}

// Función para elevar una matriz cuadrada a una potencia usando exponenciación rápida
Matriz potencia(const Matriz& A, int p) {
    if (A.size() != A[0].size()) {
        throw invalid_argument("La matriz debe ser cuadrada para la exponenciación.");
    }
    int n = A.size();
    if (p == 1) return A;
    if (p % 2 == 0) {
        Matriz X = potencia(A, p / 2);
        return multiplicar(X, X);
    } else {
        return multiplicar(A, potencia(A, p - 1));
    }
}

// Función para imprimir una matriz
void imprimirMatriz(const Matriz& A) {
    for (const auto& fila : A) {
        for (int valor : fila) {
            cout << valor << " ";
        }
        cout << endl;
    }
}

// Función recursiva que recibe dos matrices y un entero
Matriz operacionMatricialRecursiva(const Matriz& A, const Matriz& B, int n) {
    if (n == 0) return A;  // Caso base
    if (n == 1) return multiplicar(A, B);  // Caso base
    Matriz C = multiplicar(A, B);
    Matriz D = C;
    if (C.size() == C[0].size()) {  // Solo eleva si la matriz es cuadrada
        D = potencia(C, n);
    }
    return operacionMatricialRecursiva(C, D, n - 1);
}

int main() {
    // Ejemplo de matrices de diferentes tamaños
    Matriz A = {{1, 2, 3}, {4, 5, 6}};
    Matriz B = {{7, 8}, {9, 10}, {11, 12}};
    int n = 2;

    try {
        Matriz resultado = operacionMatricialRecursiva(A, B, n);
        cout << "Resultado de la operación recursiva:\n";
        imprimirMatriz(resultado);
    } catch (const exception& e) {
        cerr << "Error: " << e.what() << endl;
    }

    return 0;
}

