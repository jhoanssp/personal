/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: listas
AUTOR: Jhoan Salazar
FECHA DE CREACION: 4/06/2024
FECHA DE ULTIMA MODIFICACION:4/06/2024

*/
#include <iostream>

struct Nodo {
    int dato;
    Nodo* siguiente;
};

class ListaCircularSimpleEnlazada {
public:
    Nodo* cabeza;

    ListaCircularSimpleEnlazada() : cabeza(nullptr) {}

    void agregar(int dato) {
        Nodo* nuevoNodo = new Nodo{dato, nullptr};
        if (!cabeza) {
            cabeza = nuevoNodo;
            cabeza->siguiente = cabeza;
            return;
        }
        Nodo* temp = cabeza;
        while (temp->siguiente != cabeza) {
            temp = temp->siguiente;
        }
        temp->siguiente = nuevoNodo;
        nuevoNodo->siguiente = cabeza;
    }

    void eliminar(int dato) {
        if (!cabeza) return;
        if (cabeza->dato == dato) {
            if (cabeza->siguiente == cabeza) {
                delete cabeza;
                cabeza = nullptr;
                return;
            }
            Nodo* temp = cabeza;
            while (temp->siguiente != cabeza) {
                temp = temp->siguiente;
            }
            Nodo* nodoAEliminar = cabeza;
            temp->siguiente = cabeza->siguiente;
            cabeza = cabeza->siguiente;
            delete nodoAEliminar;
            return;
        }
        Nodo* temp = cabeza;
        while (temp->siguiente != cabeza && temp->siguiente->dato != dato) {
            temp = temp->siguiente;
        }
        if (temp->siguiente->dato == dato) {
            Nodo* nodoAEliminar = temp->siguiente;
            temp->siguiente = nodoAEliminar->siguiente;
            delete nodoAEliminar;
        }
    }

    void mostrar() {
        if (!cabeza) return;
        Nodo* temp = cabeza;
        do {
            std::cout << temp->dato << " -> ";
            temp = temp->siguiente;
        } while (temp != cabeza);
        std::cout << "cabeza\n";
    }
};

int main() {
    ListaCircularSimpleEnlazada lista;
    lista.agregar(1);
    lista.agregar(2);
    lista.agregar(3);
    lista.mostrar();
    lista.eliminar(2);
    lista.mostrar();
    return 0;
}
