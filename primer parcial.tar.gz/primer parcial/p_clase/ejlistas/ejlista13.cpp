/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: listas
AUTOR: Jhoan Salazar
FECHA DE CREACION: 3/06/2024
FECHA DE ULTIMA MODIFICACION:3/06/2024

*/
#include <iostream>

struct Nodo {
    int dato;
    Nodo* siguiente;
};

class ListaCircularSimpleEnlazada {
public:
    Nodo* cabeza;

    ListaCircularSimpleEnlazada() : cabeza(nullptr) {}

    void agregar(int dato) {
        Nodo* nuevoNodo = new Nodo{dato, nullptr};
        if (!cabeza) {
            cabeza = nuevoNodo;
            cabeza->siguiente = cabeza;
            return;
        }
        Nodo* temp = cabeza;
        while (temp->siguiente != cabeza) {
            temp = temp->siguiente;
        }
        temp->siguiente = nuevoNodo;
        nuevoNodo->siguiente = cabeza;
    }

    void mostrar() {
        if (!cabeza) return;
        Nodo* temp = cabeza;
        do {
            std::cout << temp->dato << " -> ";
            temp = temp->siguiente;
        } while (temp != cabeza);
        std::cout << "cabeza\n";
    }
};

int main() {
    ListaCircularSimpleEnlazada lista;
    lista.agregar(1);
    lista.agregar(2);
    lista.agregar(3);
    lista.mostrar();
    return 0;
}

