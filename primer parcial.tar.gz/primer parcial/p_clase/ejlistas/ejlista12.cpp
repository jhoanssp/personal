/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: listas
AUTOR: Jhoan Salazar
FECHA DE CREACION: 3/06/2024
FECHA DE ULTIMA MODIFICACION:3/06/2024

*/
#include <iostream>

struct Nodo {
    int dato;
    Nodo* siguiente;
    Nodo* anterior;
};

class ListaDobleEnlazada {
public:
    Nodo* cabeza;

    ListaDobleEnlazada() : cabeza(nullptr) {}

    void agregar(int dato) {
        Nodo* nuevoNodo = new Nodo{dato, nullptr, nullptr};
        if (!cabeza) {
            cabeza = nuevoNodo;
            return;
        }
        Nodo* temp = cabeza;
        while (temp->siguiente) {
            temp = temp->siguiente;
        }
        temp->siguiente = nuevoNodo;
        nuevoNodo->anterior = temp;
    }

    void mostrar() {
        Nodo* temp = cabeza;
        while (temp) {
            std::cout << temp->dato << " <-> ";
            temp = temp->siguiente;
        }
        std::cout << "nullptr\n";
    }
};

int main() {
    ListaDobleEnlazada lista;
    lista.agregar(1);
    lista.agregar(2);
    lista.agregar(3);
    lista.mostrar();
    return 0;
}
