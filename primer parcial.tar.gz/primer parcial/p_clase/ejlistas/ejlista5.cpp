/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: listas
AUTOR: Jhoan Salazar
FECHA DE CREACION: 1/06/2024
FECHA DE ULTIMA MODIFICACION:2/06/2024

*/
#include <iostream>

// Definición de la estructura de un nodo
struct Nodo {
    int dato;
    Nodo* siguiente;
};

// Función para insertar un nodo al inicio de la lista
void insertarCabeza(Nodo*& cabeza, int valor) {
    Nodo* nuevo_nodo = new Nodo();
    nuevo_nodo->dato = valor;
    nuevo_nodo->siguiente = cabeza;
    cabeza = nuevo_nodo;
}

// Función para imprimir todos los elementos de la lista
void imprimirLista(Nodo* cabeza) {
    Nodo* actual = cabeza;
    while (actual != nullptr) {
        std::cout << actual->dato << " -> ";
        actual = actual->siguiente;
    }
    std::cout << "NULL" << std::endl;
}

// Función para contar los nodos en la lista
int contarNodos(Nodo* cabeza) {
    int contador = 0;
    Nodo* actual = cabeza;
    while (actual != nullptr) {
        contador++;
        actual = actual->siguiente;
    }
    return contador;
}

int main() {
    Nodo* cabeza = nullptr;

    insertarCabeza(cabeza, 3);
    insertarCabeza(cabeza, 2);
    insertarCabeza(cabeza, 1);

    imprimirLista(cabeza);

    std::cout << "La lista contiene " << contarNodos(cabeza) << " nodos." << std::endl;

    return 0;
}
