
// lista circular simple

#include <iostream>

// Definición de un nodo
struct Nodo {
    int dato;
    Nodo* siguiente;
};

// Función para insertar un nuevo nodo al inicio de la lista
void insertar(Nodo** cabeza, int dato) {
    Nodo* nuevoNodo = new Nodo();
    nuevoNodo->dato = dato;
    nuevoNodo->siguiente = *cabeza;

    if (*cabeza != nullptr) {
        Nodo* temp = *cabeza;
        while (temp->siguiente != *cabeza) {
            temp = temp->siguiente;
        }
        temp->siguiente = nuevoNodo;
    } else {
        nuevoNodo->siguiente = nuevoNodo;
    }
    *cabeza = nuevoNodo;
}

// Función para imprimir la lista
void imprimirLista(Nodo* cabeza) {
    if (cabeza != nullptr) {
        Nodo* temp = cabeza;
        do {
            std::cout << temp->dato << " ";
            temp = temp->siguiente;
        } while (temp != cabeza);
    }
}

int main() {
    Nodo* cabeza = nullptr;

    insertar(&cabeza, 1);
    insertar(&cabeza, 2);
    insertar(&cabeza, 3);

    std::cout << "Lista circular simple: ";
    imprimirLista(cabeza);

    return 0;
}

