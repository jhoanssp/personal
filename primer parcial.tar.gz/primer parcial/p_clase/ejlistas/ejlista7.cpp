
/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: listas
AUTOR: Jhoan Salazar
FECHA DE CREACION: 2/06/2024
FECHA DE ULTIMA MODIFICACION:2/06/2024

*/


#include <iostream>

// Definición de un nodo
struct Nodo {
    int dato;         // Dato almacenado en el nodo
    Nodo* siguiente;  // Puntero al siguiente nodo
};

// Función para insertar un nuevo nodo al inicio de la lista
void insertar(Nodo** cabeza, int dato) {
    Nodo* nuevoNodo = new Nodo();  // Crear un nuevo nodo
    nuevoNodo->dato = dato;        // Asignar el dato al nuevo nodo
    nuevoNodo->siguiente = *cabeza; // Hacer que el nuevo nodo apunte a la antigua cabeza
    *cabeza = nuevoNodo;           // Actualizar la cabeza para que apunte al nuevo nodo
}

// Función para imprimir la lista
void mostrar(Nodo* nodo) {
    while (nodo != nullptr) {      // Mientras no se llegue al final de la lista
        std::cout << nodo->dato << " "; // Imprimir el dato del nodo actual
        nodo = nodo->siguiente;    // Moverse al siguiente nodo
    }
    std::cout << std::endl;        // Nueva línea después de imprimir todos los elementos
}

// Función para buscar un elemento en la lista
bool buscar(Nodo* cabeza, int dato) {
    Nodo* actual = cabeza;         // Empezar desde la cabeza
    while (actual != nullptr) {    // Mientras no se llegue al final de la lista
        if (actual->dato == dato) { // Si el dato del nodo actual es el que buscamos
            return true;           // Retornar verdadero
        }
        actual = actual->siguiente; // Moverse al siguiente nodo
    }
    return false;                  // Si no se encuentra, retornar falso
}

// Función para eliminar un nodo con un valor específico
void eliminar(Nodo** cabeza, int dato) {
    Nodo* temp = *cabeza;          // Puntero temporal para recorrer la lista
    Nodo* prev = nullptr;          // Puntero al nodo anterior

    // Si la cabeza contiene el dato a eliminar
    if (temp != nullptr && temp->dato == dato) {
        *cabeza = temp->siguiente; // Cambiar la cabeza al siguiente nodo
        delete temp;               // Liberar el nodo eliminado
        return;
    }

    // Buscar el nodo a eliminar
    while (temp != nullptr && temp->dato != dato) {
        prev = temp;
        temp = temp->siguiente;
    }

    // Si no se encontró el dato
    if (temp == nullptr) return;

    prev->siguiente = temp->siguiente; // Saltar el nodo a eliminar
    delete temp;                       // Liberar el nodo eliminado
}

int main() {
    Nodo* cabeza = nullptr;  // Inicializar la lista vacía

    // Insertar algunos elementos
    insertar(&cabeza, 1);
    insertar(&cabeza, 2);
    insertar(&cabeza, 3);

    // Mostrar la lista
    std::cout << "Lista enlazada simple: ";
    mostrar(cabeza);

    // Buscar un elemento
    std::cout << "Buscar 2: " << (buscar(cabeza, 2) ? "Encontrado" : "No encontrado") << std::endl;

    // Eliminar un elemento
    eliminar(&cabeza, 2);
    std::cout << "Lista después de eliminar 2: ";
    mostrar(cabeza);

    return 0;
}

