/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: listas
AUTOR: Jhoan Salazar
FECHA DE CREACION: 4/06/2024
FECHA DE ULTIMA MODIFICACION:4/06/2024

*/
#include <iostream>

struct Nodo {
    int dato;
    Nodo* siguiente;
};

class ListaCircularSimpleEnlazada {
public:
    Nodo* cabeza;

    ListaCircularSimpleEnlazada() : cabeza(nullptr) {}

    void agregar(int dato) {
        Nodo* nuevoNodo = new Nodo{dato, nullptr};
        if (!cabeza) {
            cabeza = nuevoNodo;
            cabeza->siguiente = cabeza;
            return;
        }
        Nodo* temp = cabeza;
        while (temp->siguiente != cabeza) {
            temp = temp->siguiente;
        }
        temp->siguiente = nuevoNodo;
        nuevoNodo->siguiente = cabeza;
    }

    void mostrar() {
        if (!cabeza) return;
        Nodo* temp = cabeza;
        do {
            std::cout << temp->dato << " -> ";
            temp = temp->siguiente;
        } while (temp != cabeza);
        std::cout << "cabeza\n";
    }
};

int main() {
    ListaCircularSimpleEnlazada lista;
    int dato, n;

    std::cout << "Ingrese el número de elementos: ";
    std::cin >> n;

    for (int i = 0; i < n; ++i) {
        std::cout << "Ingrese el dato " << i + 1 << ": ";
        std::cin >> dato;
        lista.agregar(dato);
    }

    lista.mostrar();
    return 0;
}

