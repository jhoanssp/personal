//lista enlazada simple

#include <iostream>

// Definición de un nodo
struct Nodo {
    int dato;
    Nodo* siguiente;
};

// Función para insertar un nuevo nodo al inicio de la lista
void insertar(Nodo** cabeza, int dato) {
    Nodo* nuevoNodo = new Nodo();
    nuevoNodo->dato = dato;
    nuevoNodo->siguiente = *cabeza;
    *cabeza = nuevoNodo;
}

// Función para imprimir la lista
void imprimirLista(Nodo* nodo) {
    while (nodo != nullptr) {
        std::cout << nodo->dato << " ";
        nodo = nodo->siguiente;
    }
}

int main() {
    Nodo* cabeza = nullptr;

    insertar(&cabeza, 1);
    insertar(&cabeza, 2);
    insertar(&cabeza, 3);

    std::cout << "Lista enlazada simple: ";
    imprimirLista(cabeza);

    return 0;
}
