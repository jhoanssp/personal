/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: listas
AUTOR: Jhoan Salazar
FECHA DE CREACION: 1/06/2024
FECHA DE ULTIMA MODIFICACION:2/06/2024

*/
#include <iostream>

// Definición de la estructura de un nodo
struct Nodo {
    int dato;
    Nodo* siguiente;
};

// Función para insertar un nodo al inicio de la lista
void insertarCabeza(Nodo*& cabeza, int valor) {
    Nodo* nuevo_nodo = new Nodo();
    nuevo_nodo->dato = valor;
    nuevo_nodo->siguiente = cabeza;
    cabeza = nuevo_nodo;
}

// Función para imprimir todos los elementos de la lista
void imprimirLista(Nodo* cabeza) {
    Nodo* actual = cabeza;
    while (actual != nullptr) {
        std::cout << actual->dato << " -> ";
        actual = actual->siguiente;
    }
    std::cout << "NULL" << std::endl;
}

// Función para eliminar el primer nodo de la lista
void eliminarCabeza(Nodo*& cabeza) {
    if (cabeza != nullptr) {
        Nodo* nodo_a_eliminar = cabeza;
        cabeza = cabeza->siguiente;
        delete nodo_a_eliminar;
    }
}

int main() {
    Nodo* cabeza = nullptr;

    insertarCabeza(cabeza, 3);
    insertarCabeza(cabeza, 2);
    insertarCabeza(cabeza, 1);

    imprimirLista(cabeza);

    eliminarCabeza(cabeza);
    imprimirLista(cabeza);

    return 0;
}
