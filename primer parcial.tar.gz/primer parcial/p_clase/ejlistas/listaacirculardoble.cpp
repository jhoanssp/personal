
//lista circular doble

#include <iostream>

// Definición de un nodo
struct Nodo {
    int dato;
    Nodo* siguiente;
    Nodo* anterior;
};

// Función para insertar un nuevo nodo al inicio de la lista
void insertar(Nodo** cabeza, int dato) {
    Nodo* nuevoNodo = new Nodo();
    nuevoNodo->dato = dato;
    if (*cabeza == nullptr) {
        nuevoNodo->siguiente = nuevoNodo->anterior = nuevoNodo;
        *cabeza = nuevoNodo;
    } else {
        Nodo* ultimo = (*cabeza)->anterior;
        nuevoNodo->siguiente = *cabeza;
        nuevoNodo->anterior = ultimo;
        ultimo->siguiente = (*cabeza)->anterior = nuevoNodo;
        *cabeza = nuevoNodo;
    }
}

// Función para imprimir la lista desde el inicio hasta el final
void imprimirLista(Nodo* cabeza) {
    if (cabeza != nullptr) {
        Nodo* temp = cabeza;
        do {
            std::cout << temp->dato << " ";
            temp = temp->siguiente;
        } while (temp != cabeza);
    }
}

int main() {
    Nodo* cabeza = nullptr;

    insertar(&cabeza, 1);
    insertar(&cabeza, 2);
    insertar(&cabeza, 3);

    std::cout << "Lista circular doble: ";
    imprimirLista(cabeza);

    return 0;
}

