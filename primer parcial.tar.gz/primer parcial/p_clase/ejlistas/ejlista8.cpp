
/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: listas
AUTOR: Jhoan Salazar
FECHA DE CREACION: 2/06/2024
FECHA DE ULTIMA MODIFICACION:2/06/2024

*/


#include <iostream>

// Definición de un nodo
struct Nodo {
    int dato;          // Dato almacenado en el nodo
    Nodo* siguiente;   // Puntero al siguiente nodo
    Nodo* anterior;    // Puntero al nodo anterior
};

// Función para insertar un nuevo nodo al inicio de la lista
void insertar(Nodo** cabeza, int dato) {
    Nodo* nuevoNodo = new Nodo();  // Crear un nuevo nodo
    nuevoNodo->dato = dato;        // Asignar el dato al nuevo nodo
    nuevoNodo->siguiente = *cabeza; // Hacer que el nuevo nodo apunte a la antigua cabeza
    nuevoNodo->anterior = nullptr; // El nuevo nodo no tiene anterior al ser el primero

    if (*cabeza != nullptr) {       // Si la lista no está vacía
        (*cabeza)->anterior = nuevoNodo; // La antigua cabeza ahora apunta al nuevo nodo
    }
    *cabeza = nuevoNodo;            // Actualizar la cabeza para que apunte al nuevo nodo
}

// Función para imprimir la lista desde el inicio hasta el final
void mostrar(Nodo* nodo) {
    Nodo* ultimo = nullptr;         // Puntero para el último nodo
    while (nodo != nullptr) {       // Mientras no se llegue al final de la lista
        std::cout << nodo->dato << " "; // Imprimir el dato del nodo actual
        ultimo = nodo;              // Actualizar el último nodo
        nodo = nodo->siguiente;     // Moverse al siguiente nodo
    }
    std::cout << std::endl;         // Nueva línea después de imprimir todos los elementos
}

// Función para buscar un elemento en la lista
bool buscar(Nodo* cabeza, int dato) {
    Nodo* actual = cabeza;          // Empezar desde la cabeza
    while (actual != nullptr) {     // Mientras no se llegue al final de la lista
        if (actual->dato == dato) { // Si el dato del nodo actual es el que buscamos
            return true;            // Retornar verdadero
        }
        actual = actual->siguiente; // Moverse al siguiente nodo
    }
    return false;                   // Si no se encuentra, retornar falso
}

// Función para eliminar un nodo con un valor específico
void eliminar(Nodo** cabeza, int dato) {
    Nodo* temp = *cabeza;           // Puntero temporal para recorrer la lista

    // Buscar el nodo a eliminar
    while (temp != nullptr && temp->dato != dato) {
        temp = temp->siguiente;
    }

    // Si no se encontró el dato
    if (temp == nullptr) return;

    // Si el nodo a eliminar es la cabeza
    if (*cabeza == temp) *cabeza = temp->siguiente;
    if (temp->siguiente != nullptr) temp->siguiente->anterior = temp->anterior;
    if (temp->anterior != nullptr) temp->anterior->siguiente = temp->siguiente;

    delete temp;                    // Liberar el nodo eliminado
}

int main() {
    Nodo* cabeza = nullptr;  // Inicializar la lista vacía

    // Insertar algunos elementos
    insertar(&cabeza, 1);
    insertar(&cabeza, 2);
    insertar(&cabeza, 3);

    // Mostrar la lista
    std::cout << "Lista enlazada doble: ";
    mostrar(cabeza);

    // Buscar un elemento
    std::cout << "Buscar 2: " << (buscar(cabeza, 2) ? "Encontrado" : "No encontrado") << std::endl;

    // Eliminar un elemento
    eliminar(&cabeza, 2);
    std::cout << "Lista después de eliminar 2: ";
    mostrar(cabeza);

    return 0;
}

