/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: listas
AUTOR: Jhoan Salazar
FECHA DE CREACION: 2/06/2024
FECHA DE ULTIMA MODIFICACION:2/06/2024

*/
#include <iostream>

// Definición de un nodo
struct Nodo {
    int dato;          // Dato almacenado en el nodo
    Nodo* siguiente;   // Puntero al siguiente nodo
};

// Función para insertar un nuevo nodo al inicio de la lista
void insertar(Nodo** cabeza, int dato) {
    Nodo* nuevoNodo = new Nodo();  // Crear un nuevo nodo
    nuevoNodo->dato = dato;        // Asignar el dato al nuevo nodo
    nuevoNodo->siguiente = *cabeza; // Hacer que el nuevo nodo apunte a la antigua cabeza

    if (*cabeza != nullptr) {      // Si la lista no está vacía
        Nodo* temp = *cabeza;
        while (temp->siguiente != *cabeza) { // Encontrar el último nodo
            temp = temp->siguiente;
        }
        temp->siguiente = nuevoNodo; // El último nodo ahora apunta al nuevo nodo
    } else {
        nuevoNodo->siguiente = nuevoNodo; // Si la lista estaba vacía, el nuevo nodo apunta a sí mismo
    }
    *cabeza = nuevoNodo;           // Actualizar la cabeza para que apunte al nuevo nodo
}

// Función para imprimir la lista
void mostrar(Nodo* cabeza) {
    if (cabeza != nullptr) {       // Si la lista no está vacía
        Nodo* temp = cabeza;
        do {
            std::cout << temp->dato << " "; // Imprimir el dato del nodo actual
            temp = temp->siguiente;         // Moverse al siguiente nodo
        } while (temp != cabeza);           // Detenerse cuando se vuelve a la cabeza
        std::cout << std::endl;             // Nueva línea después de imprimir todos los elementos
    }
}

// Función para buscar un elemento en la lista
bool buscar(Nodo* cabeza, int dato) {
    if (cabeza == nullptr) return false; // Si la lista está vacía
    Nodo* temp = cabeza;
    do {
        if (temp->dato == dato) {        // Si el dato del nodo actual es el que buscamos
            return true;                 // Retornar verdadero
        }
        temp = temp->siguiente;          // Moverse al siguiente nodo
    } while (temp != cabeza);            // Detenerse cuando se vuelve a la cabeza
    return false;                        // Si no se encuentra, retornar falso
}

// Función para eliminar un nodo con un valor específico
void eliminar(Nodo** cabeza, int dato) {
    if (*cabeza == nullptr) return;     // Si la lista está vacía

    Nodo* temp = *cabeza;
    Nodo* prev = nullptr;

    // Encontrar el nodo a eliminar
    do {
        if (temp->dato == dato) {
            if (prev != nullptr) {       // Si no es el primer nodo
                prev->siguiente = temp->siguiente;
            } else {                    // Si es el primer nodo
                Nodo* last = *cabeza;
                while (last->siguiente != *cabeza) { // Encontrar el último nodo
                    last = last->siguiente;
                }
                last->siguiente = temp->siguiente; // El último nodo ahora apunta al siguiente del eliminado
                *cabeza = temp->siguiente;         // Actualizar la cabeza
            }
            delete temp;               // Liberar el nodo eliminado
            return;
        }
        prev = temp;
        temp = temp->siguiente;
    } while (temp != *cabeza);
}

int main() {
    Nodo* cabeza = nullptr;  // Inicializar la lista vacía

    // Insertar algunos elementos
    insertar(&cabeza, 1);
    insertar(&cabeza, 2);
    insertar(&cabeza, 3);

    // Mostrar la lista
    std::cout << "Lista circular simple: ";
    mostrar(cabeza);

    // Buscar un elemento
    std::cout << "Buscar 2: " << (buscar(cabeza, 2) ? "Encontrado" : "No encontrado") << std::endl;

    // Eliminar un elemento
    eliminar(&cabeza, 2);
    std::cout << "Lista después de eliminar 2: ";
    mostrar(cabeza);

    return 0;
}

