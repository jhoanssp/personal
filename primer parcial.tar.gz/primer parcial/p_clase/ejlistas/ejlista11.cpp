/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: listas
AUTOR: Jhoan Salazar
FECHA DE CREACION: 3/06/2024
FECHA DE ULTIMA MODIFICACION:3/06/2024

*/
#include <iostream>

struct Nodo {
    int dato;
    Nodo* siguiente;
};

class ListaSimpleEnlazada {
public:
    Nodo* cabeza;

    ListaSimpleEnlazada() : cabeza(nullptr) {}

    void agregar(int dato) {
        Nodo* nuevoNodo = new Nodo{dato, nullptr};
        if (!cabeza) {
            cabeza = nuevoNodo;
            return;
        }
        Nodo* temp = cabeza;
        while (temp->siguiente) {
            temp = temp->siguiente;
        }
        temp->siguiente = nuevoNodo;
    }

    void mostrar() {
        Nodo* temp = cabeza;
        while (temp) {
            std::cout << temp->dato << " -> ";
            temp = temp->siguiente;
        }
        std::cout << "nullptr\n";
    }
};

int main() {
    ListaSimpleEnlazada lista;
    lista.agregar(1);
    lista.agregar(2);
    lista.agregar(3);
    lista.mostrar();
    return 0;
}

