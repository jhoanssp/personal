/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: listas
AUTOR: Jhoan Salazar
FECHA DE CREACION: 1/06/2024
FECHA DE ULTIMA MODIFICACION:1/06/2024

*/
#include <iostream>

// Definición de la estructura de un nodo
struct Nodo {
    int dato;
    Nodo* siguiente;
};

// Función para insertar un nodo al inicio de la lista
void insertarCabeza(Nodo*& cabeza, int valor) {
    Nodo* nuevo_nodo = new Nodo(); // Crear un nuevo nodo
    nuevo_nodo->dato = valor;      // Asignar el valor al nuevo nodo
    nuevo_nodo->siguiente = cabeza;// Hacer que el nuevo nodo apunte al antiguo cabeza
    cabeza = nuevo_nodo;           // Actualizar la cabeza para que sea el nuevo nodo
}

// Función para imprimir todos los elementos de la lista
void imprimirLista(Nodo* cabeza) {
    Nodo* actual = cabeza; // Empezar desde la cabeza
    while (actual != nullptr) { // Recorrer hasta el final de la lista
        std::cout << actual->dato << " -> ";
        actual = actual->siguiente;
    }
    std::cout << "NULL" << std::endl; // Indicar el final de la lista
}

int main() {
    Nodo* cabeza = nullptr; // Inicialmente la lista está vacía

    // Insertar algunos elementos en la lista
    insertarCabeza(cabeza, 3);
    insertarCabeza(cabeza, 2);
    insertarCabeza(cabeza, 1);

    // Imprimir los elementos de la lista
    imprimirLista(cabeza);

    // Liberar la memoria de los nodos
    Nodo* actual = cabeza;
    while (actual != nullptr) {
        Nodo* siguiente = actual->siguiente;
        delete actual;
        actual = siguiente;
    }

    return 0;
}
