#include <iostream>

// Definición de la estructura de un nodo
struct Nodo {
    int dato;
    Nodo* siguiente;
};

// Función para insertar un nodo al inicio de la lista
void insertarCabeza(Nodo*& cabeza, int valor) {
    Nodo* nuevo_nodo = new Nodo();
    nuevo_nodo->dato = valor;
    nuevo_nodo->siguiente = cabeza;
    cabeza = nuevo_nodo;
}

// Función para imprimir todos los elementos de la lista
void imprimirLista(Nodo* cabeza) {
    Nodo* actual = cabeza;
    while (actual != nullptr) {
        std::cout << actual->dato << " -> ";
        actual = actual->siguiente;
    }
    std::cout << "NULL" << std::endl;
}

// Función para buscar un elemento en la lista
bool buscarElemento(Nodo* cabeza, int valor) {
    Nodo* actual = cabeza;
    while (actual != nullptr) {
        if (actual->dato == valor) {
            return true;
        }
        actual = actual->siguiente;
    }
    return false;
}

// Función para liberar la memoria de la lista
void liberarLista(Nodo*& cabeza) {
    Nodo* actual = cabeza;
    while (actual != nullptr) {
        Nodo* siguiente = actual->siguiente;
        delete actual;
        actual = siguiente;
    }
    cabeza = nullptr;
}

int main() {
    Nodo* cabeza = nullptr;  // Inicialmente la lista está vacía

    // Insertar algunos elementos en la lista
    insertarCabeza(cabeza, 5);
    insertarCabeza(cabeza, 10);
    insertarCabeza(cabeza, 15);

    // Imprimir los elementos de la lista
    imprimirLista(cabeza);

    // Buscar un elemento en la lista
    int valorBuscado = 10;
    if (buscarElemento(cabeza, valorBuscado)) {
        std::cout << "El valor " << valorBuscado << " se encuentra en la lista." << std::endl;
    } else {
        std::cout << "El valor " << valorBuscado << " NO se encuentra en la lista." << std::endl;
    }

    // Liberar la memoria de los nodos
    liberarLista(cabeza);

    return 0;
}

