/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: listas
AUTOR: Jhoan Salazar
FECHA DE CREACION: 4/06/2024
FECHA DE ULTIMA MODIFICACION:4/06/2024

*/
#include <iostream>

struct Nodo {
    int dato;
    Nodo* siguiente;
};

class ListaSimpleEnlazada {
public:
    Nodo* cabeza;

    ListaSimpleEnlazada() : cabeza(nullptr) {}

    void agregar(int dato) {
        Nodo* nuevoNodo = new Nodo{dato, nullptr};
        if (!cabeza) {
            cabeza = nuevoNodo;
            return;
        }
        Nodo* temp = cabeza;
        while (temp->siguiente) {
            temp = temp->siguiente;
        }
        temp->siguiente = nuevoNodo;
    }

    void mostrar() {
        Nodo* temp = cabeza;
        while (temp) {
            std::cout << temp->dato << " -> ";
            temp = temp->siguiente;
        }
        std::cout << "nullptr\n";
    }
};

int main() {
    ListaSimpleEnlazada lista;
    int dato, n;

    std::cout << "Ingrese el número de elementos: ";
    std::cin >> n;

    for (int i = 0; i < n; ++i) {
        std::cout << "Ingrese el dato " << i + 1 << ": ";
        std::cin >> dato;
        lista.agregar(dato);
    }

    lista.mostrar();
    return 0;
}

