/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: listas
AUTOR: Jhoan Salazar
FECHA DE CREACION: 3/06/2024
FECHA DE ULTIMA MODIFICACION:3/06/2024

*/
#include <iostream>

struct Nodo {
    int dato;
    Nodo* siguiente;
    Nodo* anterior;
};

class ListaDobleEnlazada {
public:
    Nodo* cabeza;

    ListaDobleEnlazada() : cabeza(nullptr) {}

    void agregar(int dato) {
        Nodo* nuevoNodo = new Nodo{dato, nullptr, nullptr};
        if (!cabeza) {
            cabeza = nuevoNodo;
            return;
        }
        Nodo* temp = cabeza;
        while (temp->siguiente) {
            temp = temp->siguiente;
        }
        temp->siguiente = nuevoNodo;
        nuevoNodo->anterior = temp;
    }

    void eliminar(int dato) {
        if (!cabeza) return;
        if (cabeza->dato == dato) {
            Nodo* temp = cabeza;
            cabeza = cabeza->siguiente;
            if (cabeza) cabeza->anterior = nullptr;
            delete temp;
            return;
        }
        Nodo* temp = cabeza;
        while (temp && temp->dato != dato) {
            temp = temp->siguiente;
        }
        if (temp) {
            if (temp->anterior) temp->anterior->siguiente = temp->siguiente;
            if (temp->siguiente) temp->siguiente->anterior = temp->anterior;
            delete temp;
        }
    }

    void mostrar() {
        Nodo* temp = cabeza;
        while (temp) {
            std::cout << temp->dato << " <-> ";
            temp = temp->siguiente;
        }
        std::cout << "nullptr\n";
    }
};

int main() {
    ListaDobleEnlazada lista;
    lista.agregar(1);
    lista.agregar(2);
    lista.agregar(3);
    lista.mostrar();
    lista.eliminar(2);
    lista.mostrar();
    return 0;
}
