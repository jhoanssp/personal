
//lista enlazada doble

#include <iostream>

// Definición de un nodo
struct Nodo {
    int dato;
    Nodo* siguiente;
    Nodo* anterior;
};

// Función para insertar un nuevo nodo al inicio de la lista
void insertar(Nodo** cabeza, int dato) {
    Nodo* nuevoNodo = new Nodo();
    nuevoNodo->dato = dato;
    nuevoNodo->siguiente = *cabeza;
    nuevoNodo->anterior = nullptr;

    if (*cabeza != nullptr) {
        (*cabeza)->anterior = nuevoNodo;
    }
    *cabeza = nuevoNodo;
}

// Función para imprimir la lista desde el inicio hasta el final
void imprimirLista(Nodo* nodo) {
    Nodo* ultimo;
    std::cout << "Lista enlazada doble: ";
    while (nodo != nullptr) {
        std::cout << nodo->dato << " ";
        ultimo = nodo;
        nodo = nodo->siguiente;
    }
}

int main() {
    Nodo* cabeza = nullptr;

    insertar(&cabeza, 1);
    insertar(&cabeza, 2);
    insertar(&cabeza, 3);

    imprimirLista(cabeza);

    return 0;
}

