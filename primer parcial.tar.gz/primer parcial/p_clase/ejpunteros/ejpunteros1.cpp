#include <iostream>

int main() {
    int var = 20;  // Variable normal
    int *ptr;     // Declaración de un puntero

    ptr = &var;   // El puntero almacena la dirección de var

    std::cout << "El valor de var es: " << var << std::endl;
    std::cout << "El valor de *ptr es: " << *ptr << std::endl;

    *ptr = 30;    // Cambiando el valor de var usando el puntero
    std::cout << "El nuevo valor de var es: " << var << std::endl;

    return 0;
}