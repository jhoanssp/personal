
#include <iostream>

int main() {
    int n;
    std::cout << "Introduce el tamaño del arreglo: ";
    std::cin >> n;

    int *arr = new int[n];  // Crear un arreglo dinámico

    std::cout << "Introduce los elementos del arreglo:\n";
    for (int i = 0; i < n; ++i) {
        std::cin >> arr[i];
    }

    std::cout << "Los elementos del arreglo son:\n";
    for (int i = 0; i < n; ++i) {
        std::cout << arr[i] << " ";
    }
    std::cout << std::endl;

    delete[] arr;  // Liberar la memoria asignada dinámicamente

    return 0;
}
