
#include <iostream>

int main() {
    int var = 10;
    int *ptr = &var;
    int **ptr2 = &ptr;  // Puntero a puntero

    std::cout << "El valor de var es: " << var << std::endl;
    std::cout << "El valor de *ptr es: " << *ptr << std::endl;
    std::cout << "El valor de **ptr2 es: " << **ptr2 << std::endl;

    return 0;
}
