
#include <iostream>

struct Punto {
    int x, y;
};

int main() {
    Punto p1 = {10, 20};
    Punto *ptr = &p1;

    std::cout << "El punto tiene coordenadas: (" << ptr->x << ", " << ptr->y << ")" << std::endl;

    ptr->x = 30;  // Cambiando el valor usando el puntero
    ptr->y = 40;

    std::cout << "El nuevo valor del punto es: (" << ptr->x << ", " << ptr->y << ")" << std::endl;

    return 0;
}
