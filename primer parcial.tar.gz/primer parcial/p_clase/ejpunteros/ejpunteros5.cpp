
#include <iostream>

int main() {
    const int size = 5;
    int arr[size] = {1, 2, 3, 4, 5};
    int *ptrs[size];  // Arreglo de punteros

    for (int i = 0; i < size; ++i) {
        ptrs[i] = &arr[i];  // Asignar la dirección de cada elemento del arreglo
    }

    std::cout << "Los elementos del arreglo a través de punteros son:\n";
    for (int i = 0; i < size; ++i) {
        std::cout << *ptrs[i] << " ";
    }
    std::cout << std::endl;

    return 0;
}
