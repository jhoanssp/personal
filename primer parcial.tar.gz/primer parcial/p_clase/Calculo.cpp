
#include<conio.h>
#include <iostream>
#include "Calculo.h"
using namespace std;


template <typename T>
T Calculo<T>::suma(){

return a+b;

}
T Calculo<T>::resta(){

return a-b;

}
T Calculo<T>::multiplicacion(){

return a*b;

}