#include<iostream>
#include<conio.h>
using namespace std;


template <typename T>
class Calculo
{
public:
    /* data */
private:
    Calculo(/* args */);
    ~Calculublic

Calculo::Cprivate(/* args ublic}

Calculo::~Calculprivate