/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: LAMBDA
AUTOR: Jhoan Salazar
FECHA DE CREACION: 16/05/2024
FECHA DE ULTIMA MODIFICACION:16/05/2024

*/


#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    // Solicitar al usuario que ingrese una serie de números enteros
    std::cout << "Por favor, ingrese una serie de números enteros separados por espacio (ingrese un carácter no numérico para finalizar): ";
    std::vector<int> numeros;
    int num;
    while (std::cin >> num) {
        numeros.push_back(num);
    }

    // Definición de la función lambda que filtra números pares y calcula su suma
    auto sumaPares = [](const std::vector<int>& arreglo) {
        int suma = 0;
        for (int num : arreglo) {
            if (num % 2 == 0) { // Si el número es par
                suma += num;
            }
        }
        return suma;
    };

    // Utilizando la función lambda para filtrar números pares y calcular su suma
    int resultado = sumaPares(numeros);

    // Mostrando el resultado
    std::cout << "La suma de los números pares ingresados es: " << resultado << std::endl;

    return 0;
}
