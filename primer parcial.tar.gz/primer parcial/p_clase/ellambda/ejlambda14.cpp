
/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: LAMBDA
AUTOR: Jhoan Salazar
FECHA DE CREACION: 20/05/2024
FECHA DE ULTIMA MODIFICACION:20/05/2024

*/
#include <iostream>

int main() {
    int contador = 0;
    auto incrementar = [contador]() mutable {
        contador++;
        return contador;
    };

    std::cout << incrementar() << std::endl; // Debería imprimir: 1
    std::cout << incrementar() << std::endl; // Debería imprimir: 2
    std::cout << incrementar() << std::endl; // Debería imprimir: 3

    std::cout << "Valor original del contador: " << contador << std::endl; // Debería imprimir: 0
    return 0;
}

