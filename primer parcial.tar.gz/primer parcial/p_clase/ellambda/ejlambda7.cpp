/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: LAMBDA
AUTOR: Jhoan Salazar
FECHA DE CREACION: 16/05/2024
FECHA DE ULTIMA MODIFICACION:16/05/2024

*/

#include <iostream>

int main() {
    // Solicitar al usuario que ingrese un número
    std::cout << "Por favor, ingrese un número entero: ";
    int numero;
    std::cin >> numero;

    // Definición de la función lambda que encuentra el cuadrado de un número
    auto cuadrado = [](int x) {
        return x * x;
    };

    // Utilizando la función lambda para encontrar el cuadrado del número ingresado
    int resultado = cuadrado(numero);

    // Mostrando el resultado
    std::cout << "El cuadrado de " << numero << " es: " << resultado << std::endl;

    return 0;
}
