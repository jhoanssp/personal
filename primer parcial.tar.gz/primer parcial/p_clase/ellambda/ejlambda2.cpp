/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: LAMBDA
AUTOR: Jhoan Salazar
FECHA DE CREACION: 15/05/2024
FECHA DE ULTIMA MODIFICACION:15/05/2024

*/

#include <iostream>
#include <vector>
#include <algorithm>

class EncontrarMayor {
public:
    // Constructor que toma el arreglo como argumento
    EncontrarMayor(const std::vector<int>& arreglo) : arreglo_(arreglo) {}

    // Método para encontrar el número mayor
    int encontrar() const {
        // Utilizamos la función std::max_element de la biblioteca <algorithm> para encontrar el elemento máximo
        auto iteradorMaximo = std::max_element(arreglo_.begin(), arreglo_.end());
        // Devolvemos el valor del elemento máximo
        return *iteradorMaximo;
    }

private:
    std::vector<int> arreglo_;
};

int main() {
    // Arreglo de números enteros
    std::vector<int> numeros = {10, 5, 20, 15, 8};

    // Creamos un objeto de la clase EncontrarMayor pasando el arreglo como argumento
    EncontrarMayor encontrarMayor(numeros);

    // Llamamos al método encontrar y mostramos el resultado
    std::cout << "El número mayor en el arreglo es: " << encontrarMayor.encontrar() << std::endl;

    return 0;
}
