
/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: LAMBDA
AUTOR: Jhoan Salazar
FECHA DE CREACION: 16/05/2024
FECHA DE ULTIMA MODIFICACION:15/05/2024

*/

#include <iostream>

int main() {
    // Definición de la función lambda que encuentra el cuadrado de un número
    auto cuadrado = [](int x) {
        return x * x;
    };

    // Utilizando la función lambda para encontrar el cuadrado de un número
    int numero = 6;
    int resultado = cuadrado(numero);

    // Mostrando el resultado
    std::cout << "El cuadrado de " << numero << " es: " << resultado << std::endl;

    return 0;
}
