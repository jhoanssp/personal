/* UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: LAMBDA
AUTOR: Grupo 5
FECHA DE CREACION: 15/05/2024
FECHA DE ULTIMA MODIFICACION:16/05/2024

*/

#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    std::vector<int> numeros;//declaramos un vector para almacenar los numeros ingresados por el ususario

    // Solicitar al usuario que ingrese 5 números
    std::cout << "Por favor, ingrese 5 números enteros separados por espacios:\n";
    int numero;
    for (int i = 0; i < 5; ++i) {
        std::cin >> numero;
        numeros.push_back(numero);//push permite anadir al final de la coleccion(arreglo) un nuevo dato
    }

    // Función anónima (lambda) para encontrar el número mayor
    auto encontrarMayor = [](const std::vector<int>& arreglo) -> int {//auto:El compilador analiza el tipo de datos de la variable observando su inicialización. 
    // [] captura variables fuera de lambda ()argumento de la funcion {}codigo de la funcion lambda
        // Utilizamos la función std::max_element de la biblioteca <algorithm> para encontrar el elemento máximo
        auto iteradorMaximo = std::max_element(arreglo.begin(), arreglo.end());
        // Devolvemos el valor del elemento máximo
        return *iteradorMaximo;
    };

    // Llamamos a la función anónima y mostramos el resultado
    std::cout << "El número mayor en el arreglo es: " << encontrarMayor(numeros) << std::endl;

    return 0;
}