/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: LAMBDA
AUTOR: Jhoan Salazar
FECHA DE CREACION: 20/05/2024
FECHA DE ULTIMA MODIFICACION:20/05/2024

*/

#include <iostream>
#include <vector>
#include <algorithm>
#include <functional>

void procesarNumeros(const std::vector<int>& numeros, std::function<void(int)> func) {
    for (int n : numeros) {
        func(n);
    }
}

int main() {
    int multiplicador = 2;
    int umbral = 5;
    std::vector<int> numeros = {1, 2, 3, 4, 5};

    auto lambdaProcesar = [multiplicador, &umbral](int n) {
        int resultado = n * multiplicador;
        if (resultado > umbral) {
            std::cout << resultado << " ";
        }
    };

    procesarNumeros(numeros, lambdaProcesar); // Debería imprimir: 6 8 10
    std::cout << std::endl;

    return 0;
}

