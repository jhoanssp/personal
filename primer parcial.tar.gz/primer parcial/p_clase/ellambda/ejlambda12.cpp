
/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: LAMBDA
AUTOR: Jhoan Salazar
FECHA DE CREACION: 20/05/2024
FECHA DE ULTIMA MODIFICACION:20/05/2024

*/
#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    std::vector<int> numeros = {1, 2, 3, 4, 5};

    // Lambda que usa otra lambda para transformar y luego filtrar la colección
    auto transformarYFiltrar = [](std::vector<int>& vec, int factor, int limite) {
        std::transform(vec.begin(), vec.end(), vec.begin(), [factor](int n) {
            return n * factor;
        });

        vec.erase(std::remove_if(vec.begin(), vec.end(), [limite](int n) {
            return n <= limite;
        }), vec.end());
    };

    transformarYFiltrar(numeros, 2, 5);

    for (int n : numeros) {
        std::cout << n << " "; // Debería imprimir: 8 10
    }
    std::cout << std::endl;

    return 0;
}
  
