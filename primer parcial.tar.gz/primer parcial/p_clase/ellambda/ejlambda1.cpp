/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: LAMBDA
AUTOR: Jhoan Salazar
FECHA DE CREACION: 15/05/2024
FECHA DE ULTIMA MODIFICACION:15/05/2024

*/

#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    // Arreglo de números enteros
    std::vector<int> numeros = {10, 5, 20, 15, 8};

    // Función anónima (lambda) para encontrar el número mayor
    auto encontrarMayor = [](const std::vector<int>& arreglo) -> int {
        // Utilizamos la función std::max_element de la biblioteca <algorithm> para encontrar el elemento máximo
        auto iteradorMaximo = std::max_element(arreglo.begin(), arreglo.end());
        // Devolvemos el valor del elemento máximo
        return *iteradorMaximo;
    };

    // Llamamos a la función anónima y mostramos el resultado
    std::cout << "El número mayor en el arreglo es: " << encontrarMayor(numeros) << std::endl;

    return 0;
}
