
/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: LAMBDA
AUTOR: Jhoan Salazar
FECHA DE CREACION: 15/05/2024
FECHA DE ULTIMA MODIFICACION:16/05/2024

*/

#include <iostream>

int main() {
    // Definición de la función lambda que suma dos números
    auto suma = [](int a, int b) {
        return a + b;
    };

    // Utilizando la función lambda para sumar dos números
    int resultado = suma(5, 3);

    // Mostrando el resultado
    std::cout << "El resultado de la suma es: " << resultado << std::endl;

    return 0;
}
