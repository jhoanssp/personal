
/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: LAMBDA
AUTOR: Jhoan Salazar
FECHA DE CREACION: 16/05/2024
FECHA DE ULTIMA MODIFICACION:16/05/2024

*/
#include <iostream>

int main() {
    // Solicitar al usuario que ingrese dos números
    std::cout << "Por favor, ingrese dos números enteros separados por espacio: ";
    int numero1, numero2;
    std::cin >> numero1 >> numero2;

    // Definición de la función lambda que calcula el producto de dos números
    auto producto = [](int x, int y) {
        return x * y;
    };

    // Utilizando la función lambda para encontrar el producto de los números ingresados
    int resultado = producto(numero1, numero2);

    // Mostrando el resultado
    std::cout << "El producto de " << numero1 << " y " << numero2 << " es: " << resultado << std::endl;

    return 0;
}
