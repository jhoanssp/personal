/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: LAMBDA
AUTOR: Jhoan Salazar
FECHA DE CREACION: 20/05/2024
FECHA DE ULTIMA MODIFICACION:20/05/2024

*/
#include <iostream>

int main() {
    auto multiplicar = [](int a, int b) {
        return a * b;
    };
    std::cout << "3 * 4 = " << multiplicar(3, 4) << std::endl; // Debería imprimir 12
    return 0;
}
