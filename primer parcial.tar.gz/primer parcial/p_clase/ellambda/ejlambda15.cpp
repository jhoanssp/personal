/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: LAMBDA
AUTOR: Jhoan Salazar
FECHA DE CREACION: 20/05/2024
FECHA DE ULTIMA MODIFICACION:20/05/2024

*/
#include <iostream>
#include <vector>
#include <algorithm>

class Calculadora {
public:
    int sumar(int a, int b) const {
        return a + b;
    }
    
    int restar(int a, int b) const {
        return a - b;
    }
};

int main() {
    Calculadora calc;
    std::vector<int> numeros = {1, 2, 3, 4, 5};
    int incremento = 2;

    // Lambda que usa métodos de un objeto capturado
    auto aplicarIncremento = [&calc, incremento](int n) {
        return calc.sumar(n, incremento);
    };

    std::transform(numeros.begin(), numeros.end(), numeros.begin(), aplicarIncremento);

    for (int n : numeros) {
        std::cout << n << " "; // Debería imprimir: 3 4 5 6 7
    }
    std::cout << std::endl;

    return 0;
}


