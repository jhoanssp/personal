/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: LAMBDA
AUTOR: Jhoan Salazar
FECHA DE CREACION: 16/05/2024
FECHA DE ULTIMA MODIFICACION:16/05/2024

*/


#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

// Definición de la clase Persona
class Persona {
public:
    Persona(std::string nombre, int edad) : nombre_(nombre), edad_(edad) {}

    // Método para obtener el nombre de la persona
    std::string getNombre() const {
        return nombre_;
    }

    // Método para obtener la edad de la persona
    int getEdad() const {
        return edad_;
    }

private:
    std::string nombre_;
    int edad_;
};

int main() {
    // Vector de personas
    std::vector<Persona> personas;

    // Solicitar al usuario que ingrese los datos de las personas
    std::cout << "Ingrese el nombre y la edad de las personas (Ingrese 'fin' para terminar):\n";
    std::string nombre;
    int edad;
    while (true) {
        std::cout << "Nombre: ";
        std::cin >> nombre;
        if (nombre == "fin") // Si el usuario ingresa "fin", terminamos el bucle
            break;
        std::cout << "Edad: ";
        std::cin >> edad;
        personas.emplace_back(nombre, edad); // Agregar una nueva persona al final del vector
    }

    // Ordenar el vector de personas por edad utilizando una función lambda
    std::sort(personas.begin(), personas.end(), [](const Persona& p1, const Persona& p2) {
        return p1.getEdad() < p2.getEdad();
    });

    // Mostrar las personas ordenadas por edad
    std::cout << "\nPersonas ordenadas por edad de menor a mayor:\n";
    for (const auto& persona : personas) {
        std::cout << "Nombre: " << persona.getNombre() << ", Edad: " << persona.getEdad() << std::endl;
    }

    return 0;
}
