#include <iostream>

class Vector2D {
public:
    float x, y;

    Vector2D(float x = 0, float y = 0) : x(x), y(y) {}

    // Sobrecarga del operador +
    Vector2D operator+(const Vector2D& other) const {
        return Vector2D(this->x + other.x, this->y + other.y);
    }

    // Sobrecarga del operador <<
    friend std::ostream& operator<<(std::ostream& os, const Vector2D& vec) {
        os << "(" << vec.x << ", " << vec.y << ")";
        return os;
    }

    // Sobrecarga del operador >>
    friend std::istream& operator>>(std::istream& is, Vector2D& vec) {
        is >> vec.x >> vec.y;
        return is;
    }
};

int main() {
    Vector2D vec1, vec2;

    std::cout << "Ingrese las componentes del primer vector (x y): ";
    std::cin >> vec1;
    std::cout << "Ingrese las componentes del segundo vector (x y): ";
    std::cin >> vec2;

    Vector2D vec3 = vec1 + vec2;

    std::cout << "vec1: " << vec1 << std::endl;
    std::cout << "vec2: " << vec2 << std::endl;
    std::cout << "vec3 (vec1 + vec2): " << vec3 << std::endl;

    return 0;
}
