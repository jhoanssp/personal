#include <iostream>

class Rectangle {
private:
    double length;
    double width;

public:
    Rectangle(double l, double w) : length(l), width(w) {}

    double getArea() const {
        return length * width;
    }

    double getPerimeter() const {
        return 2 * (length + width);
    }

    friend std::istream& operator>>(std::istream& is, Rectangle& rect) {
        is >> rect.length >> rect.width;
        return is;
    }

    friend std::ostream& operator<<(std::ostream& os, const Rectangle& rect) {
        os << "Rectángulo: largo = " << rect.length << ", ancho = " << rect.width;
        return os;
    }

    friend Rectangle operator+(const Rectangle& r1, const Rectangle& r2) {
        return Rectangle(r1.getArea() + r2.getArea(), r1.getPerimeter() + r2.getPerimeter());
    }

    friend Rectangle operator-(const Rectangle& r1, const Rectangle& r2) {
        return Rectangle(r1.getArea() - r2.getArea(), r1.getPerimeter() - r2.getPerimeter());
    }
};

int main() {
    Rectangle rect1(4, 5);
    Rectangle rect2(3, 6);

    std::cout << "Rectángulo 1: " << rect1 << std::endl;
    std::cout << "Rectángulo 2: " << rect2 << std::endl;

    Rectangle sum = rect1 + rect2;
    Rectangle diff = rect1 - rect2;

    std::cout << "Suma de áreas y perímetros: " << sum << std::endl;
    std::cout << "Diferencia de áreas y perímetros: " << diff << std::endl;

    return 0;
}
