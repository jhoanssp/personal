#include <iostream>

class Fraction {
private:
    int numerator;
    int denominator;

public:
    Fraction(int num = 0, int den = 1) : numerator(num), denominator(den) {}

    // Sobrecarga del operador de suma
    Fraction operator+(const Fraction& other) const {
        int num = numerator * other.denominator + other.numerator * denominator;
        int den = denominator * other.denominator;
        return Fraction(num, den);
    }

    // Sobrecarga del operador de multiplicación
    Fraction operator*(const Fraction& other) const {
        int num = numerator * other.numerator;
        int den = denominator * other.denominator;
        return Fraction(num, den);
    }

    // Sobrecarga del operador de impresión
    friend std::ostream& operator<<(std::ostream& os, const Fraction& fraction) {
        os << fraction.numerator << "/" << fraction.denominator;
        return os;
    }

    // Sobrecarga del operador de entrada
    friend std::istream& operator>>(std::istream& is, Fraction& fraction) {
        is >> fraction.numerator >> fraction.denominator;
        return is;
    }
};

int main() {
    Fraction f1, f2;

    std::cout << "Ingrese la primera fracción (numerador/denominador): ";
    std::cin >> f1;
    std::cout << "Ingrese la segunda fracción (numerador/denominador): ";
    std::cin >> f2;

    Fraction sum = f1 + f2;
    Fraction product = f1 * f2;

    std::cout << "Suma: " << sum << std::endl;
    std::cout << "Producto: " << product << std::endl;

    return 0;
}
