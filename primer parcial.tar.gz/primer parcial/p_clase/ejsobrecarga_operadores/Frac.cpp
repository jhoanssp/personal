#include<iostream>
#include "Frac.h"
using namespace std;
void Frac::in(){
    cout<<"Ingresar el numero: ";
    cin>>a;
    cout<<"Ingresa el denomidador: ";
    cin>>b;

}

//overload the * operator
Frac Frac:: operator*(const Frac &obj){
    Frac temporal;
    temporal.a=a * obj.a;
    temporal.b=b * obj.b;


    return temporal;
}


void Frac::out(){

    cout<<"la multiplicacion de las fraccion es: " << a <<"/"<<b<<endl;
}