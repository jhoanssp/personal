#include<iostream>
#include<string.h>
#include<conio.h>
#include<stdio.h>
void ingreso(char *);
void *ingreso(char *msj);{
    char cad[10],c;
    int i=0;
    printf("%s",*msj);
    while((c=getch())!=13){
        if(c>='0'&& c<='9'){
            cad[i++]=c;
            printf("%c",c);

        }
    }
    cad[i]='\0';
    printf("%s",cad);
    return cad;

}

int main(int argc, char** argv){

    char datos[10];

    strcpy(datos,
    ingreso("Ingresar el valor entero"),10);

    return 0;
}