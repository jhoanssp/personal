#include <iostream>
#include <vector>

class Polynomial {
private:
    std::vector<int> coefficients;

public:
    Polynomial(const std::vector<int>& coeffs) : coefficients(coeffs) {}

    // Sobrecarga del operador de suma
    Polynomial operator+(const Polynomial& other) const {
        int size = std::max(coefficients.size(), other.coefficients.size());
        std::vector<int> result_coeffs(size, 0);

        for (int i = 0; i < size; ++i) {
            if (i < coefficients.size()) result_coeffs[i] += coefficients[i];
            if (i < other.coefficients.size()) result_coeffs[i] += other.coefficients[i];
        }

        return Polynomial(result_coeffs);
    }

    // Sobrecarga del operador de multiplicación
    Polynomial operator*(const Polynomial& other) const {
        int size = coefficients.size() + other.coefficients.size() - 1;
        std::vector<int> result_coeffs(size, 0);

        for (int i = 0; i < coefficients.size(); ++i) {
            for (int j = 0; j < other.coefficients.size(); ++j) {
                result_coeffs[i + j] += coefficients[i] * other.coefficients[j];
            }
        }

        return Polynomial(result_coeffs);
    }

    // Sobrecarga del operador de impresión
    friend std::ostream& operator<<(std::ostream& os, const Polynomial& poly) {
        for (int i = poly.coefficients.size() - 1; i >= 0; --i) {
            os << poly.coefficients[i] << "x^" << i;
            if (i > 0) os << " + ";
        }
        return os;
    }
};

int main() {
    Polynomial poly1({1, 2, 3}); // Representa el polinomio 1 + 2x + 3x^2
    Polynomial poly2({-1, 1});   // Representa el polinomio -1 + x

    Polynomial sum = poly1 + poly2;
    Polynomial product = poly1 * poly2;

    std::cout << "Suma: " << sum << std::endl;
    std::cout << "Producto: " << product << std::endl;

    return 0;
}
