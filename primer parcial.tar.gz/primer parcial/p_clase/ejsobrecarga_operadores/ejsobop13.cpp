#include <iostream>
#include <string>

class Fruit {
private:
    std::string name;
    int quantity;

public:
    Fruit(const std::string& n, int q) : name(n), quantity(q) {}

    Fruit operator+(const Fruit& other) const {
        if (name != other.name) {
            std::cerr << "No se pueden combinar frutas diferentes." << std::endl;
            return *this;
        }
        return Fruit(name, quantity + other.quantity);
    }

    Fruit operator-(const Fruit& other) const {
        if (name != other.name) {
            std::cerr << "No se pueden eliminar frutas diferentes." << std::endl;
            return *this;
        }
        int newQuantity = quantity - other.quantity;
        if (newQuantity < 0) {
            std::cerr << "No se pueden eliminar más frutas de las que hay." << std::endl;
            return *this;
        }
        return Fruit(name, newQuantity);
    }

    friend std::ostream& operator<<(std::ostream& os, const Fruit& fruit) {
        os << fruit.quantity << " " << fruit.name;
        return os;
    }
};

int main() {
    Fruit apple("manzana", 5);
    Fruit banana("plátano", 3);
    Fruit orange("naranja", 2);

    Fruit combined = apple + banana;
    Fruit removed = combined - orange;

    std::cout << "Frutas combinadas: " << combined << std::endl;
    std::cout << "Frutas después de eliminar naranjas: " << removed << std::endl;

    return 0;
}
