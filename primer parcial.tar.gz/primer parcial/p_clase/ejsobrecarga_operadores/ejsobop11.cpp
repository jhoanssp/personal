#include <iostream>
#include <vector>
class Matrix {
private:
    std::vector<std::vector<int>> data;
    int size;

public:
    Matrix(int n) : size(n) {
        data.resize(n, std::vector<int>(n, 0));
    }

    Matrix operator+(const Matrix& other) const {
        Matrix result(size);
        for (int i = 0; i < size; ++i) {
            for (int j = 0; j < size; ++j) {
                result.data[i][j] = data[i][j] + other.data[i][j];
            }
        }
        return result;
    }

    Matrix operator-(const Matrix& other) const {
        Matrix result(size);
        for (int i = 0; i < size; ++i) {
            for (int j = 0; j < size; ++j) {
                result.data[i][j] = data[i][j] - other.data[i][j];
            }
        }
        return result;
    }

    Matrix operator*(const Matrix& other) const {
        Matrix result(size);
        for (int i = 0; i < size; ++i) {
            for (int j = 0; j < size; ++j) {
                for (int k = 0; k < size; ++k) {
                    result.data[i][j] += data[i][k] * other.data[k][j];
                }
            }
        }
        return result;
    }

    friend std::ostream& operator<<(std::ostream& os, const Matrix& mat) {
        for (int i = 0; i < mat.size; ++i) {
            for (int j = 0; j < mat.size; ++j) {
                os << mat.data[i][j] << " ";
            }
            os << std::endl;
        }
        return os;
    }
};

int main() {
    Matrix A(2);
    A.data = {{1, 2}, {3, 4}};
    Matrix B(2);
    B.data = {{5, 6}, {7, 8}};

    Matrix sum = A + B;
    Matrix diff = A - B;
    Matrix prod = A * B;

    std::cout << "Suma:\n" << sum << std::endl;
    std::cout << "Resta:\n" << diff << std::endl;
    std::cout << "Producto:\n" << prod << std::endl;

    return 0;
}
