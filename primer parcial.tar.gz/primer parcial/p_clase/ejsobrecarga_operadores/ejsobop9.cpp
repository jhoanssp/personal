#include <iostream>

class Rectangle {
private:
    double width;
    double height;

public:
    Rectangle(double w = 0, double h = 0) : width(w), height(h) {}

    // Sobrecarga del operador ==
    bool operator==(const Rectangle& other) const {
        return width == other.width && height == other.height;
    }

    // Sobrecarga del operador !=
    bool operator!=(const Rectangle& other) const {
        return !(*this == other);
    }
};

int main() {
    Rectangle r1(3, 4);
    Rectangle r2(5, 2);
    Rectangle r3(3, 4);

    std::cout << "r1 == r2: " << std::boolalpha << (r1 == r2) << std::endl;
    std::cout << "r1 == r3: " << std::boolalpha << (r1 == r3) << std::endl;
    std::cout << "r1 != r2: " << std::boolalpha << (r1 != r2) << std::endl;
    std::cout << "r1 != r3: " << std::boolalpha << (r1 != r3) << std::endl;

    return 0;
}
