#include<iostream>
#include "Cir.h"
#include <math.h>

using namespace std;
void Cir::in(){
    cout<<"Ingresar el numero: ";
    cin>>longitud;


}

//overload the * operator
Cir Cir:: operator+(const Cir &obj){
    Cir temporal;
    //temporal.radio=radio * M_PI*2;
    temporal.longitud=sqrt((longitud*longitud + obj.longitud*obj.longitud)/2)*2*M_PI;
    


    return temporal;
}


void Cir::out(){

    cout<<"El perimetro es: " << longitud <<"cm"<<endl;
}