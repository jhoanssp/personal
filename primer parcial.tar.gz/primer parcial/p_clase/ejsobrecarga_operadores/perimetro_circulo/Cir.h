#include <iostream>
using namespace std;

class Cir{//clase elipse

    private:
        float longitud=0.0;//longitud x ^ y de la elipse
        
    public:
        Cir() : longitud(0.0){}//constructor por defecto
        void in();
        Cir operator+(const Cir &obj);
        void out();


};
