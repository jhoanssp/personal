#include <iostream>
#include "Cir.cpp"


using namespace std;

int main(){
    Cir F1,F2, result;

    system("cls");

    cout<<"Insetar longitud eje mayor: "<< endl;
    F1.in();
    cout<<"cInsetar longitud eje menor: "<< endl;
    F2.in();

    result =F1 + F2;
    result.out();


    return 0;
}