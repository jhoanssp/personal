#include <iostream>

class Matrix {
public:
    int a11, a12, a21, a22;

    Matrix(int a11 = 0, int a12 = 0, int a21 = 0, int a22 = 0) 
        : a11(a11), a12(a12), a21(a21), a22(a22) {}

    // Sobrecarga del operador *
    Matrix operator*(const Matrix& other) const {
        return Matrix(
            a11 * other.a11 + a12 * other.a21, a11 * other.a12 + a12 * other.a22,
            a21 * other.a11 + a22 * other.a21, a21 * other.a12 + a22 * other.a22
        );
    }

    // Sobrecarga del operador <<
    friend std::ostream& operator<<(std::ostream& os, const Matrix& mat) {
        os << "[" << mat.a11 << " " << mat.a12 << "]\n"
           << "[" << mat.a21 << " " << mat.a22 << "]";
        return os;
    }

    // Sobrecarga del operador >>
    friend std::istream& operator>>(std::istream& is, Matrix& mat) {
        is >> mat.a11 >> mat.a12 >> mat.a21 >> mat.a22;
        return is;
    }
};

int main() {
    Matrix m1, m2;

    std::cout << "Ingrese los elementos de la primera matriz (a11 a12 a21 a22): ";
    std::cin >> m1;
    std::cout << "Ingrese los elementos de la segunda matriz (a11 a12 a21 a22): ";
    std::cin >> m2;

    Matrix m3 = m1 * m2;

    std::cout << "m1:\n" << m1 << std::endl;
    std::cout << "m2:\n" << m2 << std::endl;
    std::cout << "m3 (m1 * m2):\n" << m3 << std::endl;

    return 0;
}
