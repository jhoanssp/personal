#include <iostream>

class Rectangle {
private:
    double length;
    double width;

public:
    Rectangle(double l = 0, double w = 0) : length(l), width(w) {}

    double getArea() const {
        return length * width;
    }

    double getPerimeter() const {
        return 2 * (length + width);
    }

    friend std::istream& operator>>(std::istream& is, Rectangle& rect) {
        std::cout << "Ingrese el largo del rectángulo: ";
        is >> rect.length;
        std::cout << "Ingrese el ancho del rectángulo: ";
        is >> rect.width;
        return is;
    }

    friend std::ostream& operator<<(std::ostream& os, const Rectangle& rect) {
        os << "Rectángulo: largo = " << rect.length << ", ancho = " << rect.width;
        return os;
    }

    friend Rectangle operator+(const Rectangle& r1, const Rectangle& r2) {
        return Rectangle(r1.length + r2.length, r1.width + r2.width);
    }

    friend Rectangle operator-(const Rectangle& r1, const Rectangle& r2) {
        return Rectangle(r1.length - r2.length, r1.width - r2.width);
    }
};

int main() {
    Rectangle rect1, rect2;

    std::cout << "Ingrese los datos del primer rectángulo:\n";
    std::cin >> rect1;

    std::cout << "Ingrese los datos del segundo rectángulo:\n";
    std::cin >> rect2;

    std::cout << "Rectángulo 1: " << rect1 << std::endl;
    std::cout << "Rectángulo 2: " << rect2 << std::endl;

    Rectangle sum = rect1 + rect2;
    Rectangle diff = rect1 - rect2;

    std::cout << "Suma de áreas y perímetros: " << sum << std::endl;
    std::cout << "Diferencia de áreas y perímetros: " << diff << std::endl;

    return 0;
}
