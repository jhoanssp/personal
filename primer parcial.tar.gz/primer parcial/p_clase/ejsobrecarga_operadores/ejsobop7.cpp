#include <iostream>

class Vector {
private:
    double x;
    double y;
    double z;

public:
    Vector(double x = 0, double y = 0, double z = 0) : x(x), y(y), z(z) {}

    // Sobrecarga del operador de suma
    Vector operator+(const Vector& other) const {
        return Vector(x + other.x, y + other.y, z + other.z);
    }

    // Sobrecarga del operador de resta
    Vector operator-(const Vector& other) const {
        return Vector(x - other.x, y - other.y, z - other.z);
    }

    // Sobrecarga del operador de impresión
    friend std::ostream& operator<<(std::ostream& os, const Vector& vec) {
        os << "(" << vec.x << ", " << vec.y << ", " << vec.z << ")";
        return os;
    }

    // Sobrecarga del operador de entrada
    friend std::istream& operator>>(std::istream& is, Vector& vec) {
        is >> vec.x >> vec.y >> vec.z;
        return is;
    }
};

int main() {
    Vector v1, v2;

    std::cout << "Ingrese las componentes del primer vector (x y z): ";
    std::cin >> v1;
    std::cout << "Ingrese las componentes del segundo vector (x y z): ";
    std::cin >> v2;

    Vector sum = v1 + v2;
    Vector difference = v1 - v2;

    std::cout << "Suma: " << sum << std::endl;
    std::cout << "Diferencia: " << difference << std::endl;

    return 0;
}
