#include <iostream>
#include <cstring>

class String {
private:
    char* str;

public:
    // Constructor
    String(const char* s = "") {
        str = new char[std::strlen(s) + 1];
        std::strcpy(str, s);
    }

    // Destructor
    ~String() {
        delete[] str;
    }

    // Sobrecarga del operador de concatenación
    String operator+(const String& other) const {
        int len = std::strlen(str) + std::strlen(other.str) + 1;
        char* result = new char[len];
        std::strcpy(result, str);
        std::strcat(result, other.str);
        return String(result);
    }

    // Sobrecarga del operador de impresión
    friend std::ostream& operator<<(std::ostream& os, const String& s) {
        return os << s.str;
    }
};

int main() {
    String s1 = "Hello, ";
    String s2 = "world!";
    String s3 = s1 + s2;

    std::cout << "s1: " << s1 << std::endl;
    std::cout << "s2: " << s2 << std::endl;
    std::cout << "s3 (s1 + s2): " << s3 << std::endl;

    return 0;
}
