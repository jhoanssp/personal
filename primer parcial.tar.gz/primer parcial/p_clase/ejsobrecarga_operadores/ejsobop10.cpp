#include <iostream>

class Currency {
private:
    double amount;
    std::string currency;

public:
    Currency(double amount = 0, const std::string& currency = "USD") : amount(amount), currency(currency) {}

    // Sobrecarga del operador +
    Currency operator+(const Currency& other) const {
        if (currency != other.currency) {
            std::cerr << "No se pueden sumar cantidades en diferentes monedas." << std::endl;
            return *this;
        }
        return Currency(amount + other.amount, currency);
    }

    // Sobrecarga del operador -
    Currency operator-(const Currency& other) const {
        if (currency != other.currency) {
            std::cerr << "No se pueden restar cantidades en diferentes monedas." << std::endl;
            return *this;
        }
        return Currency(amount - other.amount, currency);
    }

    // Sobrecarga del operador *
    Currency operator*(double scalar) const {
        return Currency(amount * scalar, currency);
    }

    // Sobrecarga del operador /
    Currency operator/(double divisor) const {
        if (divisor == 0) {
            std::cerr << "Error: División por cero." << std::endl;
            return *this;
        }
        return Currency(amount / divisor, currency);
    }

    // Sobrecarga del operador de impresión
    friend std::ostream& operator<<(std::ostream& os, const Currency& c) {
        os << c.amount << " " << c.currency;
        return os;
    }
};

int main() {
    Currency usd1(100, "USD");
    Currency usd2(50, "USD");
    Currency eur1(80, "EUR");

    std::cout << "USD 1: " << usd1 << std::endl;
    std::cout << "USD 2: " << usd2 << std::endl;
    std::cout << "EUR 1: " << eur1 << std::endl;

    Currency sum_usd = usd1 + usd2;
    Currency diff_usd = usd1 - usd2;
    Currency scaled_usd = usd1 * 2.5;
    Currency divided_usd = usd1 / 4;

    std::cout << "Suma en USD: " << sum_usd << std::endl;
    std::cout << "Diferencia en USD: " << diff_usd << std::endl;
    std::cout << "Multiplicación por escalar: " << scaled_usd << std::endl;
    std::cout << "División por escalar: " << divided_usd << std::endl;

    return 0;
}
