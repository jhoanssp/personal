#include <iostream>

class Complex {
public:
    double real, imag;

    Complex(double real = 0, double imag = 0) : real(real), imag(imag) {}

    // Sobrecarga del operador *
    Complex operator*(const Complex& other) const {
        return Complex(
            (this->real * other.real) - (this->imag * other.imag),
            (this->real * other.imag) + (this->imag * other.real)
        );
    }

    // Sobrecarga del operador <<
    friend std::ostream& operator<<(std::ostream& os, const Complex& c) {
        os << c.real << " + " << c.imag << "i";
        return os;
    }

    // Sobrecarga del operador >>
    friend std::istream& operator>>(std::istream& is, Complex& c) {
        is >> c.real >> c.imag;
        return is;
    }
};

int main() {
    Complex c1, c2;

    std::cout << "Ingrese la parte real e imaginaria del primer número complejo (real imag): ";
    std::cin >> c1;
    std::cout << "Ingrese la parte real e imaginaria del segundo número complejo (real imag): ";
    std::cin >> c2;

    Complex c3 = c1 * c2;

    std::cout << "c1: " << c1 << std::endl;
    std::cout << "c2: " << c2 << std::endl;
    std::cout << "c3 (c1 * c2): " << c3 << std::endl;

    return 0;
}
