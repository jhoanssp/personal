#include <iostream>

class Date {
private:
    int day;
    int month;
    int year;

public:
    Date(int d, int m, int y) : day(d), month(m), year(y) {}

    bool operator==(const Date& other) const {
        return (day == other.day) && (month == other.month) && (year == other.year);
    }

    friend std::ostream& operator<<(std::ostream& os, const Date& date) {
        os << date.day << "/" << date.month << "/" << date.year;
        return os;
    }
};

int main() {
    Date d1(12, 5, 2023);
    Date d2(12, 5, 2023);
    Date d3(15, 5, 2023);

    std::cout << "d1: " << d1 << std::endl;
    std::cout << "d2: " << d2 << std::endl;
    std::cout << "d3: " << d3 << std::endl;

    std::cout << "d1 == d2: " << std::boolalpha << (d1 == d2) << std::endl;
    std::cout << "d1 == d3: " << std::boolalpha << (d1 == d3) << std::endl;

    return 0;
}
