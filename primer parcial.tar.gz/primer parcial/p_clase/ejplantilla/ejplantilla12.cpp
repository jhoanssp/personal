/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: Plantilla
AUTOR: Jhoan Salazar
FECHA DE CREACION: 20/05/2024
FECHA DE ULTIMA MODIFICACION:21/05/2024

*/
#include <iostream>

int factorialAux(int n, int acumulador) {
    if (n == 0) {
        return acumulador;  // Caso base
    } else {
        return factorialAux(n - 1, n * acumulador);  // Llamada recursiva en cola
    }
}

int factorial(int n) {
    return factorialAux(n, 1);
}

int main() {
    int numero = 5;
    std::cout << "El factorial de " << numero << " es: " << factorial(numero) << std::endl;  // Imprime 120
    return 0;
}


