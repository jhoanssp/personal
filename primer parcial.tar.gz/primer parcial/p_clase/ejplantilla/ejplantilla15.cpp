/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: Plantilla
AUTOR: Jhoan Salazar
FECHA DE CREACION: 21/05/2024
FECHA DE ULTIMA MODIFICACION:21/05/2024

*/

#include <iostream>
#include <cstring>

template <typename T>
class Comparador {
public:
    static bool esIgual(T a, T b) {
        return a == b;
    }
};

// Especialización para char*
template <>
class Comparador<char*> {
public:
    static bool esIgual(const char* a, const char* b) {
        return std::strcmp(a, b) == 0;
    }
};

int main() {
    int a = 5, b = 5;
    const char* str1 = "Hola";
    const char* str2 = "Hola";

    std::cout << "5 y 5 son iguales: " << Comparador<int>::esIgual(a, b) << std::endl;  // Imprime 1 (true)
    std::cout << "\"Hola\" y \"Hola\" son iguales: " << Comparador<char*>::esIgual(str1, str2) << std::endl; // Imprime 1 (true)

    return 0;
}
