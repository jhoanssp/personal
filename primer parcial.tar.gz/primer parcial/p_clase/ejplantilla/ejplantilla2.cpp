/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: LAMBDA
AUTOR: Jhoan Salazar
FECHA DE CREACION: 13/05/2024
FECHA DE ULTIMA MODIFICACION:13/05/2024

*/



#include <iostream>
using namespace std;
// Plantilla de función para encontrar el mínimo entre dos valores de tipo T
template<typename T>
T encontrarMinimo(T a, T b) {
    return (a < b) ? a : b;
}

int main() {
    // Ejemplo de uso con números enteros
    int num1 = 10;
    int num2 = 5;
    cout<<"Ingrese el primer numero: ";
    cin>>num1;
    cout<<"Ingrese el segundo numero"; 
    cin>>num2;

    std::cout << "El mínimo entre " << num1 << " y " << num2 << " es: " << encontrarMinimo(num1, num2) << std::endl;

    // Ejemplo de uso con números de punto flotante
    double decimal1 = 3.14;
    double decimal2 = 2.71;
    std::cout << "El mínimo entre " << decimal1 << " y " << decimal2 << " es: " << encontrarMinimo(decimal1, decimal2) << std::endl;

    return 0;
}
