/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: LAMBDA
AUTOR: Jhoan Salazar
FECHA DE CREACION: 14/05/2024
FECHA DE ULTIMA MODIFICACION:15/05/2024

*/



#include <iostream>
#include <vector>
#include <limits>

// Plantilla de clase para una colección genérica de elementos
template<typename T>
class Coleccion {
private:
    std::vector<T> elementos;

public:
    // Método para agregar un elemento a la colección
    void agregarElemento(const T& elemento) {
        elementos.push_back(elemento);
    }

    // Método para eliminar un elemento de la colección
    void eliminarElemento(const T& elemento) {
        for (auto it = elementos.begin(); it != elementos.end(); ++it) {
            if (*it == elemento) {
                elementos.erase(it);
                return;
            }
        }
    }

    // Método para obtener el tamaño de la colección
    int obtenerTamano() const {
        return elementos.size();
    }
};

int main() {
    // Ejemplo de uso con enteros
    Coleccion<int> coleccionEnteros;
    int numEntero;
    std::cout << "Ingrese los números enteros (ingrese -1 para finalizar): ";
    while (std::cin >> numEntero && numEntero != -1) {
        coleccionEnteros.agregarElemento(numEntero);
    }
    std::cout << "Tamaño de la colección de enteros: " << coleccionEnteros.obtenerTamano() << std::endl;

    // Limpiar el buffer de entrada
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

    // Ejemplo de uso con caracteres
    Coleccion<char> coleccionCaracteres;
    char caracter;
    std::cout << "Ingrese los caracteres (ingrese '!' para finalizar): ";
    while (std::cin >> caracter && caracter != '!') {
        coleccionCaracteres.agregarElemento(caracter);
    }
    std::cout << "Tamaño de la colección de caracteres: " << coleccionCaracteres.obtenerTamano() << std::endl;

    return 0;
}
