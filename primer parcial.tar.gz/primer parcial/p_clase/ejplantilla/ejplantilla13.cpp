
/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: Plantilla
AUTOR: Jhoan Salazar
FECHA DE CREACION: 21/05/2024
FECHA DE ULTIMA MODIFICACION:21/05/2024

*/
#include <iostream>

int fibonacci(int n) {
    if (n <= 1) {
        return n;  // Casos base
    } else {
        return fibonacci(n - 1) + fibonacci(n - 2);  // Llamada recursiva
    }
}

int main() {
    int numero = 10;
    std::cout << "El " << numero << "º número de Fibonacci es: " << fibonacci(numero) << std::endl;  // Imprime 55
    return 0;
}




