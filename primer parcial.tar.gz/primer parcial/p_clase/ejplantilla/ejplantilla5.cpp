/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: LAMBDA
AUTOR: Jhoan Salazar
FECHA DE CREACION: 13/05/2024
FECHA DE ULTIMA MODIFICACION:13/05/2024

*/


#include <iostream>

// Plantilla de función para intercambiar dos valores de tipo T
template<typename T>
void intercambiar(T &a, T &b) {
    T temp = a;
    a = b;
    b = temp;
}

int main() {
    // Ejemplo de uso con números enteros
    int num1 = 5;
    int num2 = 10;
    std::cout << "Antes del intercambio: num1 = " << num1 << ", num2 = " << num2 << std::endl;
    intercambiar(num1, num2);
    std::cout << "Después del intercambio: num1 = " << num1 << ", num2 = " << num2 << std::endl;

    // Ejemplo de uso con caracteres
    char char1 = 'a';
    char char2 = 'b';
    std::cout << "Antes del intercambio: char1 = " << char1 << ", char2 = " << char2 << std::endl;
    intercambiar(char1, char2);
    std::cout << "Después del intercambio: char1 = " << char1 << ", char2 = " << char2 << std::endl;

    return 0;
}
