/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: plantilla
AUTOR: Jhoan Salazar
FECHA DE CREACION: 13/05/2024
FECHA DE ULTIMA MODIFICACION:13/05/2024

*/


#include<iostream>
using namespace std;

template <class TD>
void sum(TD numero);

int main(){
    int num1=0;
    int num2=0;
    cout<<"ingrese el numerador";
    cin>>num1;
    cout<<"ingresar el denominador";
    cin>>num2;
    sum(num1);
    sum(num2);
    

    return 0;
}

template<class TD>
void sum(TD numero){

int numero1;
numero + numero=numero1;
cout<<"la respuesta es"

}