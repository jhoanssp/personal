/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: LAMBDA
AUTOR: Jhoan Salazar
FECHA DE CREACION: 13/05/2024
FECHA DE ULTIMA MODIFICACION:13/05/2024

*/



#include <iostream>

// Plantilla de función para encontrar el máximo entre dos valores de tipo T
template<typename T>
T encontrarMaximo(T a, T b) {
    return (a > b) ? a : b;
}

int main() {
    // Ejemplo de uso con números enteros
    int num1 = 10;
    int num2 = 5;
    std::cout << "El máximo entre " << num1 << " y " << num2 << " es: " << encontrarMaximo(num1, num2) << std::endl;

    // Ejemplo de uso con caracteres
    char char1 = 'a';
    char char2 = 'c';
    std::cout << "El máximo entre '" << char1 << "' y '" << char2 << "' es: " << encontrarMaximo(char1, char2) << std::endl;

    // Ejemplo de uso con números de punto flotante
    double decimal1 = 3.14;
    double decimal2 = 2.71;
    std::cout << "El máximo entre " << decimal1 << " y " << decimal2 << " es: " << encontrarMaximo(decimal1, decimal2) << std::endl;

    return 0;
}
