/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: LAMBDA
AUTOR: Jhoan Salazar
FECHA DE CREACION: 14/05/2024
FECHA DE ULTIMA MODIFICACION:14/05/2024

*/



#include <iostream>
#include <vector>
#include <limits>

// Plantilla de función para calcular el promedio de un conjunto de valores de tipo T
template<typename T>
T calcularPromedio(const std::vector<T>& vec) {
    T suma = 0;
    for (const auto& elem : vec) {
        suma += elem;
    }
    return suma / vec.size();
}

int main() {
    // Ejemplo de uso con números enteros
    std::vector<int> enteros;
    int numEnteros;
    std::cout << "Ingrese los números enteros (ingrese -1 para finalizar): ";
    while (std::cin >> numEnteros && numEnteros != -1) {
        enteros.push_back(numEnteros);
    }
    std::cout << "Promedio de los enteros: " << calcularPromedio(enteros) << std::endl;

    // Limpiar el buffer de entrada
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

    // Ejemplo de uso con números de punto flotante
    std::vector<double> flotantes;
    double numFlotante;
    std::cout << "Ingrese los números de punto flotante (ingrese -1 para finalizar): ";
    while (std::cin >> numFlotante && numFlotante != -1) {
        flotantes.push_back(numFlotante);
    }
    std::cout << "Promedio de los números de punto flotante: " << calcularPromedio(flotantes) << std::endl;

    return 0;
}
