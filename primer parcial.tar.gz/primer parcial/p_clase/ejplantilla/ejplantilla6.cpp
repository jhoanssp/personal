/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: LAMBDA
AUTOR: Jhoan Salazar
FECHA DE CREACION: 13/05/2024
FECHA DE ULTIMA MODIFICACION:14/05/2024

*/


#include <iostream>

// Plantilla de función para intercambiar dos valores de tipo T
template<typename T>
void intercambiar(T &a, T &b) {
    T temp = a;
    a = b;
    b = temp;
}

int main() {
    // Ejemplo de intercambio con números enteros
    int num1, num2;
    std::cout << "Ingrese el primer número entero: ";
    std::cin >> num1;
    std::cout << "Ingrese el segundo número entero: ";
    std::cin >> num2;
    std::cout << "Antes del intercambio: num1 = " << num1 << ", num2 = " << num2 << std::endl;
    intercambiar(num1, num2);
    std::cout << "Después del intercambio: num1 = " << num1 << ", num2 = " << num2 << std::endl;

    // Ejemplo de intercambio con caracteres
    char char1, char2;
    std::cout << "Ingrese el primer caracter: ";
    std::cin >> char1;
    std::cout << "Ingrese el segundo caracter: ";
    std::cin >> char2;
    std::cout << "Antes del intercambio: char1 = " << char1 << ", char2 = " << char2 << std::endl;
    intercambiar(char1, char2);
    std::cout << "Después del intercambio: char1 = " << char1 << ", char2 = " << char2 << std::endl;

    return 0;
}
