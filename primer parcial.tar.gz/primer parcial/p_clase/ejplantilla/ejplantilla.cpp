//plantilla de una funcion 

#include <iostream>
//#include <conio.h>
using namespace std;

// prototipo de funcion 

template <class TIPOD>
void mostrarAbs(TIPOD numero);

int main(){

    int num1 = -4;
    float num4 = 56.3;
    double num3 = 123.3445;
    mostrarAbs(num1);
    mostrarAbs(num4);
    mostrarAbs(num3);

   // getch();
    return 0;

}

template <class TIPOD>
void mostrarAbs(TIPOD numero){
    if(numero<0){


        numero = numero * -1;
    }
    cout<<"el valor absoluto del nuero es: "<<numero<<"\n";

}

