/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: LAMBDA
AUTOR: Jhoan Salazar
FECHA DE CREACION: 14/05/2024
FECHA DE ULTIMA MODIFICACION:14/05/2024

*/


#include <iostream>

// Plantilla de función para calcular el promedio de un conjunto de valores de tipo T
template<typename T>
T calcularPromedio(const T arr[], int size) {
    T suma = 0;
    for (int i = 0; i < size; ++i) {
        suma += arr[i];
    }
    return suma / size;
}

int main() {
    // Ejemplo de uso con números enteros
    int enteros[] = {1, 2, 3, 4, 5};
    int sizeEnteros = sizeof(enteros) / sizeof(enteros[0]);
    std::cout << "Promedio de los enteros: " << calcularPromedio(enteros, sizeEnteros) << std::endl;

    // Ejemplo de uso con números de punto flotante
    double flotantes[] = {1.5, 2.5, 3.5, 4.5, 5.5};
    int sizeFlotantes = sizeof(flotantes) / sizeof(flotantes[0]);
    std::cout << "Promedio de los números de punto flotante: " << calcularPromedio(flotantes, sizeFlotantes) << std::endl;

    return 0;
}
