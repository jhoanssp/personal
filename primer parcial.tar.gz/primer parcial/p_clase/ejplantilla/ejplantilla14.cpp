/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: Plantilla
AUTOR: Jhoan Salazar
FECHA DE CREACION: 21/05/2024
FECHA DE ULTIMA MODIFICACION:21/05/2024

*/
#include <iostream>

int factorial(int n) {
    if (n == 0) {
        return 1;  // Caso base
    } else {
        return n * factorial(n - 1);  // Llamada recursiva
    }
}

int main() {
    int numero = 5;
    std::cout << "El factorial de " << numero << " es: " << factorial(numero) << std::endl;  // Imprime 120
    return 0;
}

