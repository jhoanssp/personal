/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: Plantilla
AUTOR: Jhoan Salazar
FECHA DE CREACION: 20/05/2024
FECHA DE ULTIMA MODIFICACION:21/05/2024

*/

#include <iostream>
#include <vector>

std::vector<int> memo;

int fibonacci(int n) {
    if (n <= 1) {
        return n;
    }
    if (memo[n] != -1) {
        return memo[n];
    }
    memo[n] = fibonacci(n - 1) + fibonacci(n - 2);
    return memo[n];
}

int main() {
    int numero = 10;
    memo.resize(numero + 1, -1);
    std::cout << "El " << numero << "º número de Fibonacci es: " << fibonacci(numero) << std::endl;  // Imprime 55
    return 0;
}

