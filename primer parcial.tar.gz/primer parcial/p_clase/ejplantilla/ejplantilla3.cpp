/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: LAMBDA
AUTOR: Jhoan Salazar
FECHA DE CREACION: 13/05/2024
FECHA DE ULTIMA MODIFICACION:13/05/2024

*/



#include <iostream>

// Plantilla de función para dividir dos valores de tipo T
template<typename T>
T dividir(T a, T b) {
    if (b == 0) {
        std::cerr << "Error: No se puede dividir por cero." << std::endl;
        return static_cast<T>(0); // Devolver un valor por defecto si b es cero
    }
    return a / b;
}

int main() {
    // Solicitar al usuario dos números
    std::cout << "Introduce el primer número: ";
    double num1;
    std::cin >> num1;

    std::cout << "Introduce el segundo número: ";
    double num2;
    std::cin >> num2;

    // Calcular la división utilizando la plantilla
    std::cout << "El resultado de dividir " << num1 << " entre " << num2 << " es: " << dividir(num1, num2) << std::endl;

    return 0;
}