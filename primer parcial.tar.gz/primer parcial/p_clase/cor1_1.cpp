#include <iostream>
#include <vector>
#include <stdexcept>

using namespace std;

typedef vector<vector<int>> Matriz;

// Función para multiplicar dos matrices de diferentes tamaños
Matriz multiplicar(const Matriz& A, const Matriz& B) {
    int filasA = A.size();
    int columnasA = A[0].size();
    int columnasB = B[0].size();
    Matriz C(filasA, vector<int>(columnasB, 0));
    for (int i = 0; i < filasA; ++i) {
        for (int j = 0; j < columnasB; ++j) {
            for (int k = 0; k < columnasA; ++k) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
    return C;
}

// Función para elevar una matriz cuadrada a una potencia usando exponenciación rápida
Matriz potencia(const Matriz& A, int p) {
    if (A.size() != A[0].size()) {
        throw invalid_argument("La matriz debe ser cuadrada para la exponenciación.");
    }
    int n = A.size();
    if (p == 1) return A;
    if (p % 2 == 0) {
        Matriz X = potencia(A, p / 2);
        return multiplicar(X, X);
    } else {
        return multiplicar(A, potencia(A, p - 1));
    }
}

// Función para imprimir una matriz
void imprimirMatriz(const Matriz& A) {
    for (const auto& fila : A) {
        for (int valor : fila) {
            cout << valor << " ";
        }
        cout << endl;
    }
}

// Función recursiva que recibe dos matrices y un entero
Matriz operacionMatricialRecursiva(const Matriz& A, int expA, const Matriz& B, int expB, int n) {
    if (n == 0) return A;  // Caso base
    if (n == 1) return multiplicar(potencia(A, expA), potencia(B, expB));  // Caso base
    Matriz C = multiplicar(potencia(A, expA), potencia(B, expB));
    Matriz D = C;
    if (C.size() == C[0].size()) {  // Solo eleva si la matriz es cuadrada
        D = potencia(C, n);
    }
    return operacionMatricialRecursiva(C, expA, D, expB, n - 1);
}

// Función para solicitar al usuario los datos de una matriz
Matriz solicitarMatriz(int filas, int columnas) {
    Matriz matriz(filas, vector<int>(columnas));
    cout << "Ingrese los elementos de la matriz:" << endl;
    for (int i = 0; i < filas; ++i) {
        cout << "Fila " << i + 1 << ": ";
        for (int j = 0; j < columnas; ++j) {
            cin >> matriz[i][j];
        }
    }
    return matriz;
}

int main() {
    int filasA, columnasA, filasB, columnasB, expA, expB, exponente;

    // Solicitar al usuario las dimensiones de las matrices y los exponentes
    cout << "Ingrese el número de filas y columnas de la matriz A: ";
    cin >> filasA >> columnasA;
    cout << "Ingrese el exponente para la matriz A: ";
    cin >> expA;
    cout << "Ingrese el número de filas y columnas de la matriz B: ";
    cin >> filasB >> columnasB;
    cout << "Ingrese el exponente para la matriz B: ";
    cin >> expB;
    cout << "Ingrese el exponente para la operación matricial recursiva: ";
    cin >> exponente;

    // Verificar que las matrices sean compatibles para la multiplicación
    if (columnasA != filasB) {
        cerr << "Error: Las matrices no son compatibles para la multiplicación." << endl;
        return 1;
    }

    // Solicitar al usuario los elementos de las matrices
    Matriz A = solicitarMatriz(filasA, columnasA);
    Matriz B = solicitarMatriz(filasB, columnasB);

    try {
        Matriz resultado = operacionMatricialRecursiva(A, expA, B, expB, exponente);
        cout << "Resultado de la operación recursiva:\n";
        imprimirMatriz(resultado);
    } catch (const exception& e) {
        cerr << "Error: " << e.what() << endl;
    }

    return 0;
}
