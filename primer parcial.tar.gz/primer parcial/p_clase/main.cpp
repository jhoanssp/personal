#include "Calculo.cpp"
#include <iostream>

 


//codigo
int main(){
    float a,b;
    printf("Calculadora para numeros mayores a cero \n\n");
    do{

    printf("Ingresar un numero a: ");
    scanf("%f",&a);
    printf("Ingresar un numero b: ");
    scanf("%f",&b);
    if(a <= 0 || b <= 0){

    printf("El numero ingresado no es valido, ingrese un numero mayor a cero")


    }
    }while(a <= 0 || b <= 0);
    //crea un objeto de la clase calculo tipo float
    Calculo<float> intCalculo(a,b);

    float resultadoSuma = intCalculo.suma();
    float resultadoResta = intCalculo.resta();
    float resultadoMultiplicacion = intCalculo.multiplicacion();

    print("La suma es: %f\n", resultadoSuma);
    print("La resta es: %f\n", resultadoResta);
    print("La multiplicacion es: %f\n", resultadoMultiplicacion);
    //retorna 0
    return 0;
}