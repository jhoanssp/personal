#include <iostream>
#include <stack>

int main() {
    std::stack<int> pila;

    // Añadir elementos a la pila
    pila.push(10);
    pila.push(20);
    pila.push(30);

    // Mostrar y retirar elementos de la pila
    while (!pila.empty()) {
        std::cout << ' ' << pila.top();
        pila.pop();
    }

    return 0;
}
