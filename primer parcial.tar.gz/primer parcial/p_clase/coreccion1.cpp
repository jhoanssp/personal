
#include <iostream>
#include <vector>

using namespace std;

typedef vector<vector<int>> Matrix;

// Función para multiplicar dos matrices
Matrix multiply(const Matrix& A, const Matrix& B) {
    int n = A.size();
    Matrix C(n, vector<int>(n, 0));
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            for (int k = 0; k < n; ++k) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
    return C;
}

// Función para elevar una matriz a una potencia usando exponenciación rápida
Matrix power(const Matrix& A, int p) {
    int n = A.size();
    if (p == 1) return A;
    if (p % 2 == 0) {
        Matrix X = power(A, p / 2);
        return multiply(X, X);
    } else {
        return multiply(A, power(A, p - 1));
    }
}

// Función para imprimir una matriz
void printMatrix(const Matrix& A) {
    for (const auto& row : A) {
        for (int val : row) {
            cout << val << " ";
        }
        cout << endl;
    }
}

// Función recursiva que recibe dos matrices y un entero
Matrix recursiveMatrixOperation(const Matrix& A, const Matrix& B, int n) {
    if (n == 0) return A;  // Caso base
    if (n == 1) return multiply(A, B);  // Caso base
    Matrix C = multiply(A, B);
    Matrix D = power(C, n);
    return recursiveMatrixOperation(C, D, n - 1);
}

int main() {
    // Ejemplo de matrices
    Matrix A = {{1, 2}, {3, 4}};
    Matrix B = {{5, 6}, {7, 8}};
    int n = 2;

    Matrix result = recursiveMatrixOperation(A, B, n);

    cout << "Resultado de la operación recursiva:\n";
    printMatrix(result);

    return 0;
}

