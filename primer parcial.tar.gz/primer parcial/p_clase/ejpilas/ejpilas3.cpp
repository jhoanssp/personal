
#include <iostream>
#include <stack>
#include <string>

std::string decimalToBinary(int decimal) {
    std::stack<int> stack;  // Pila para almacenar los restos de la división
    while (decimal > 0) {
        int remainder = decimal % 2;  // Calcular el resto de la división por 2
        stack.push(remainder);  // Añadir el resto a la pila
        decimal /= 2;  // Dividir el número decimal por 2
    }

    std::string binary;
    while (!stack.empty()) {
        // Construir la cadena binaria a partir de los restos almacenados en la pila
        binary += std::to_string(stack.top());
        stack.pop();
    }
    return binary;  // Devolver la representación binaria del número
}

int main() {
    std::cout << decimalToBinary(233) << std::endl;  // Output: 11101001
    return 0;
}

