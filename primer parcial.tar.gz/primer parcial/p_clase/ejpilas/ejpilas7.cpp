
#include <iostream>
#include <stack>
#include <string>

int maxDepth(const std::string& expression) {
    std::stack<char> stack;
    int max_depth = 0;
    int current_depth = 0;

    for (char c : expression) {
        if (c == '(') {
            stack.push(c);
            current_depth++;
            if (current_depth > max_depth) {
                max_depth = current_depth;
            }
        } else if (c == ')') {
            if (!stack.empty() && stack.top() == '(') {
                stack.pop();
                current_depth--;
            } else {
                return -1; // Paréntesis desbalanceados
            }
        }
    }

    return stack.empty() ? max_depth : -1; // Verificar si todos los paréntesis están balanceados
}

int main() {
    std::string expression = "((1+(2*3))+((8)/4))+1";
    std::cout << maxDepth(expression) << std::endl;  // Output: 3

    expression = "((1)+((2))+(((3))))";
    std::cout << maxDepth(expression) << std::endl;  // Output: 4
    return 0;
}

