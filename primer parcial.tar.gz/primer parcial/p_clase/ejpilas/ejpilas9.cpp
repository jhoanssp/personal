
#include <iostream>
#include <stack>

void moveDisks(int n, std::stack<int>& source, std::stack<int>& target, std::stack<int>& auxiliary, int& moveCount) {
    if (n == 1) {
        target.push(source.top());
        source.pop();
        moveCount++;
        return;
    }

    moveDisks(n - 1, source, auxiliary, target, moveCount);
    target.push(source.top());
    source.pop();
    moveCount++;
    moveDisks(n - 1, auxiliary, target, source, moveCount);
}

int main() {
    std::stack<int> source, target, auxiliary;
    int n = 3; // Número de discos
    for (int i = n; i >= 1; --i) {
        source.push(i);
    }

    int moveCount = 0;
    moveDisks(n, source, target, auxiliary, moveCount);

    std::cout << "Total moves: " << moveCount << std::endl;  // Output: 7 for n=3
    return 0;
}

