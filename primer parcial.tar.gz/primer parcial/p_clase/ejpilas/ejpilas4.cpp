
#include <iostream>
#include <stack>
#include <string>

std::string reverseString(const std::string& str) {
    std::stack<char> stack;  // Pila para almacenar los caracteres de la cadena
    for (char c : str) {
        stack.push(c);  // Añadir cada carácter de la cadena a la pila
    }

    std::string reversed;
    while (!stack.empty()) {
        // Construir la cadena invertida a partir de los caracteres almacenados en la pila
        reversed += stack.top();
        stack.pop();
    }
    return reversed;  // Devolver la cadena invertida
}

int main() {
    std::cout << reverseString("Hello") << std::endl;  // Output: olleH
    return 0;
}

