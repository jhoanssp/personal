
#include <iostream>
#include <stack>
#include <vector>

bool isPalindrome(const std::vector<int>& sequence) {
    std::stack<int> stack;
    int n = sequence.size();

    // Insertar la primera mitad de la secuencia en la pila
    for (int i = 0; i < n / 2; ++i) {
        stack.push(sequence[i]);
    }

    // Determinar el punto de inicio para la segunda mitad
    int start = (n % 2 == 0) ? n / 2 : n / 2 + 1;

    // Comparar la segunda mitad de la secuencia con los elementos de la pila
    for (int i = start; i < n; ++i) {
        if (stack.top() != sequence[i]) {
            return false;
        }
        stack.pop();
    }

    return true;
}

int main() {
    std::vector<int> sequence = {1, 2, 3, 2, 1};
    std::cout << isPalindrome(sequence) << std::endl;  // Output: 1 (true)

    sequence = {1, 2, 3, 4, 5};
    std::cout << isPalindrome(sequence) << std::endl;  // Output: 0 (false)
    return 0;
}

