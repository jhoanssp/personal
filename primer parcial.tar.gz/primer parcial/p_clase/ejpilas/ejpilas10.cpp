
#include <iostream>
#include <stack>
#include <sstream>

int performOperation(int a, int b, char op) {
    switch (op) {
        case '+': return a + b;
        case '-': return a - b;
        case '*': return a * b;
        case '/': return a / b;
        default: throw std::invalid_argument("Invalid operator");
    }
}

int evaluateExpression(const std::string& expression) {
    std::stack<int> values;
    std::stack<char> operators;

    std::istringstream iss(expression);
    std::string token;

    while (iss >> token) {
        if (isdigit(token[0])) {
            values.push(std::stoi(token));
        } else {
            while (!operators.empty() && 
                   (operators.top() == '*' || operators.top() == '/' || 
                   (operators.top() == '+' || operators.top() == '-') && (token[0] == '+' || token[0] == '-'))) {
                int b = values.top(); values.pop();
                int a = values.top(); values.pop();
                char op = operators.top(); operators.pop();
                values.push(performOperation(a, b, op));
            }
            operators.push(token[0]);
        }
    }

    while (!operators.empty()) {
        int b = values.top(); values.pop();
        int a = values.top(); values.pop();
        char op = operators.top(); operators.pop();
        values.push(performOperation(a, b, op));
    }

    return values.top();
}

int main() {
    std::string expression = "3 + 5 * 2 - 8 / 4";
    std::cout << evaluateExpression(expression) << std::endl; // Output: 10
    return 0;
}

