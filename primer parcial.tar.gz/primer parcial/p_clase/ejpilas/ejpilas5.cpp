
#include <iostream>
#include <stack>
#include <string>
#include <cctype>

int evaluatePostfix(const std::string& expression) {
    std::stack<int> stack;  // Pila para almacenar los operandos
    for (char c : expression) {
        if (std::isdigit(c)) {
            // Si el carácter es un dígito, convertirlo a entero y añadirlo a la pila
            stack.push(c - '0');
        } else {
            // Si el carácter es un operador, sacar los dos operandos de la pila
            int b = stack.top();
            stack.pop();
            int a = stack.top();
            stack.pop();
            // Realizar la operación correspondiente y añadir el resultado a la pila
            switch (c) {
                case '+': stack.push(a + b); break;
                case '-': stack.push(a - b); break;
                case '*': stack.push(a * b); break;
                case '/': stack.push(a / b); break;
            }
        }
    }
    return stack.top();  // Devolver el resultado final de la expresión
}

int main() {
    std::cout << evaluatePostfix("231*+9-") << std::endl;  // Output: -4
    return 0;
}
