
#include <iostream>
#include <stack>
#include <string>

bool isBalanced(const std::string& expression) {
    std::stack<char> stack;  // Pila para almacenar los paréntesis abiertos
    for (char c : expression) {
        if (c == '(' || c == '{' || c == '[') {
            // Si el carácter es un paréntesis de apertura, se añade a la pila
            stack.push(c);
        } else if (c == ')' || c == '}' || c == ']') {
            // Si el carácter es un paréntesis de cierre
            if (stack.empty()) return false;  // Si la pila está vacía, los paréntesis no están balanceados
            char top = stack.top();  // Obtener el paréntesis de apertura de la cima de la pila
            stack.pop();  // Eliminar el paréntesis de la pila
            // Verificar si el paréntesis de cierre corresponde al de apertura
            if ((c == ')' && top != '(') || 
                (c == '}' && top != '{') || 
                (c == ']' && top != '[')) {
                return false;
            }
        }
    }
    // Si la pila está vacía al final, los paréntesis están balanceados
    return stack.empty();
}

int main() {
    std::cout << isBalanced("((2 + 3) * (5/2))") << std::endl;  // Output: 1 (true)
    std::cout << isBalanced("[2 + 3] * (5/2))") << std::endl;   // Output: 0 (false)
    return 0;
}

