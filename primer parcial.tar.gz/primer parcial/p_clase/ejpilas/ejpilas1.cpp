#include <iostream>
#include <vector>

class Stack {
private:
    std::vector<int> items;  // Vector para almacenar los elementos de la pila

public:
    bool isEmpty() {
        // Devuelve true si la pila está vacía, de lo contrario false
        return items.empty();
    }

    void push(int item) {
        // Añade un elemento a la parte superior de la pila
        items.push_back(item);
    }

    int pop() {
        // Elimina y devuelve el elemento superior de la pila
        if (isEmpty()) throw std::out_of_range("Stack is empty");
        int top = items.back();
        items.pop_back();
        return top;
    }

    int peek() {
        // Devuelve el elemento superior de la pila sin eliminarlo
        if (isEmpty()) throw std::out_of_range("Stack is empty");
        return items.back();
    }

    int size() {
        // Devuelve el número de elementos en la pila
        return items.size();
    }
};

int main() {
    Stack stack;  // Crear una instancia de la pila
    stack.push(1);  // Agregar elemento 1 a la pila
    stack.push(2);  // Agregar elemento 2 a la pila
    std::cout << stack.pop() << std::endl;  // Eliminar y mostrar el elemento superior de la pila (2)
    std::cout << stack.peek() << std::endl; // Mostrar el elemento superior de la pila (1)
    std::cout << stack.size() << std::endl; // Mostrar el tamaño de la pila (1)
    return 0;
}

