#include <stdlib.h>
#include <iostream>
using namespace std;


int main(){

    char cad[]="123.34";
    float i;
    cout<<"escriba un numero: ";
    cin>>cad;

    i=atof(cad);
    cout<<i<<endl;

}
