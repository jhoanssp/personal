
#include <iostream>

// Función recursiva de Ackermann
int ackermann(int m, int n) {
    if (m == 0) {
        return n + 1; // Caso base
    } else if (m > 0 && n == 0) {
        return ackermann(m - 1, 1); // Llamada recursiva
    } else {
        return ackermann(m - 1, ackermann(m, n - 1)); // Llamada recursiva
    }
}

int main() {
    int m, n;
    std::cout << "Introduce dos números no negativos m y n: ";
    std::cin >> m >> n;

    int result = ackermann(m, n);
    std::cout << "Ackermann(" << m << ", " << n << ") = " << result << std::endl;

    return 0;
}

