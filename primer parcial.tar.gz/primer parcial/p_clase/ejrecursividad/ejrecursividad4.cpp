
#include <iostream>

// Función recursiva para resolver las Torres de Hanoi
void hanoi(int n, char from_rod, char to_rod, char aux_rod) {
    if (n == 1) {
        std::cout << "Mover disco 1 de la torre " << from_rod << " a la torre " << to_rod << std::endl;
        return;
    }
    hanoi(n - 1, from_rod, aux_rod, to_rod);
    std::cout << "Mover disco " << n << " de la torre " << from_rod << " a la torre " << to_rod << std::endl;
    hanoi(n - 1, aux_rod, to_rod, from_rod);
}

int main() {
    int n;
    std::cout << "Introduce el número de discos: ";
    std::cin >> n;
    hanoi(n, 'A', 'C', 'B'); // A, B y C son los nombres de las torres
    return 0;
}

