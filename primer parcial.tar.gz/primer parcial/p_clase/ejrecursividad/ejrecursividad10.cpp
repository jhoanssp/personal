#include <iostream>
#include <vector>
#include <functional>

// Función recursiva para encontrar el máximo elemento en un arreglo
template<typename T>
T findMax(const std::vector<T>& arr, int n, std::function<bool(const T&, const T&)> comp) {
    if (n == 1) {
        return arr[0]; // Caso base: si solo hay un elemento, es el máximo
    } else {
        // Encuentra el máximo del resto del arreglo
        T maxRest = findMax(arr, n - 1, comp);

        // Utiliza el lambda para comparar el último elemento con el máximo del resto
        if (comp(arr[n - 1], maxRest)) {
            return arr[n - 1];
        } else {
            return maxRest;
        }
    }
}

int main() {
    std::vector<int> intArr = {3, 1, 4, 1, 5, 9, 2, 6, 5};
    std::vector<double> doubleArr = {3.1, 2.2, 5.5, 1.1, 4.4, 2.9};

    // Lambda para comparar dos elementos (mayor que)
    auto compare = [](const auto& a, const auto& b) {
        return a > b;
    };

    int maxInt = findMax(intArr, static_cast<int>(intArr.size()), compare);
    double maxDouble = findMax(doubleArr, static_cast<int>(doubleArr.size()), compare);

    std::cout << "El máximo elemento en el arreglo de enteros es: " << maxInt << std::endl;
    std::cout << "El máximo elemento en el arreglo de dobles es: " << maxDouble << std::endl;

    return 0;
}
