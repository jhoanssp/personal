
#include <iostream>

// Función recursiva para calcular la potencia de un número
double power(double base, int exponent) {
    if (exponent == 0) {
        return 1; // Caso base: cualquier número elevado a 0 es 1
    } else if (exponent > 0) {
        return base * power(base, exponent - 1); // Llamada recursiva para exponentes positivos
    } else {
        return 1 / power(base, -exponent); // Llamada recursiva para exponentes negativos
    }
}

int main() {
    double base;
    int exponent;

    std::cout << "Introduce la base: ";
    std::cin >> base;
    std::cout << "Introduce el exponente: ";
    std::cin >> exponent;

    double result = power(base, exponent);
    std::cout << base << " elevado a " << exponent << " es " << result << std::endl;

    return 0;
}
