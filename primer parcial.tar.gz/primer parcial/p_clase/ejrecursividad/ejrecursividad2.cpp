
#include <iostream>

// Función recursiva para calcular el n-ésimo número de Fibonacci
int fibonacci(int n) {
    if (n <= 0) {
        return 0; // Caso base: fib(0) = 0
    } else if (n == 1) {
        return 1; // Caso base: fib(1) = 1
    } else {
        return fibonacci(n - 1) + fibonacci(n - 2); // Llamada recursiva
    }
}

int main() {
    int num;
    std::cout << "Introduce un número para calcular su término en la secuencia de Fibonacci: ";
    std::cin >> num;

    if (num < 0) {
        std::cout << "La secuencia de Fibonacci no está definida para números negativos." << std::endl;
    } else {
        int result = fibonacci(num);
        std::cout << "El término " << num << " de la secuencia de Fibonacci es " << result << std::endl;
    }

    return 0;
}