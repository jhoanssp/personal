
#include <iostream>
#include <string>

// Función recursiva para invertir una cadena de caracteres
std::string reverseString(const std::string &str) {
    if (str.empty()) {
        return ""; // Caso base: cadena vacía
    } else {
        return reverseString(str.substr(1)) + str[0]; // Llamada recursiva
    }
}

int main() {
    std::string input;
    std::cout << "Introduce una cadena: ";
    std::cin >> input;

    std::string reversed = reverseString(input);
    std::cout << "La cadena invertida es: " << reversed << std::endl;

    return 0;
}
