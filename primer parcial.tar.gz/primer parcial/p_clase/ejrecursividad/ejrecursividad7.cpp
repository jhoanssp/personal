
#include <iostream>
#include <string>

// Función recursiva para determinar si una cadena es un palíndromo
bool isPalindrome(const std::string &str, int start, int end) {
    if (start >= end) {
        return true; // Caso base
    }
    if (str[start] != str[end]) {
        return false;
    }
    return isPalindrome(str, start + 1, end - 1); // Llamada recursiva
}

int main() {
    std::string str;
    std::cout << "Introduce una cadena: ";
    std::cin >> str;

    if (isPalindrome(str, 0, str.length() - 1)) {
        std::cout << "La cadena es un palíndromo." << std::endl;
    } else {
        std::cout << "La cadena no es un palíndromo." << std::endl;
    }

    return 0;
}
