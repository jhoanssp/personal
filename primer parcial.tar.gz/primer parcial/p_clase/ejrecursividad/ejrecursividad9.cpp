
#include <iostream>
#include <string>

// Función recursiva para generar permutaciones
void permute(std::string str, int l, int r) {
    if (l == r) {
        std::cout << str << std::endl; // Caso base: se encontró una permutación
    } else {
        for (int i = l; i <= r; i++) {
            std::swap(str[l], str[i]); // Intercambiar caracteres
            permute(str, l + 1, r); // Llamada recursiva
            std::swap(str[l], str[i]); // Volver a intercambiar para backtracking
        }
    }
}

int main() {
    std::string str;
    std::cout << "Introduce una cadena: ";
    std::cin >> str;

    std::cout << "Las permutaciones de la cadena son: " << std::endl;
    permute(str, 0, str.length() - 1);

    return 0;
}
