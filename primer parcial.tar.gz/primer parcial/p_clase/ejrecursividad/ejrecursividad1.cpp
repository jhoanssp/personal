#include <iostream>

// Función recursiva para calcular el factorial de un número
unsigned long long factorial(int n) {
    if (n <= 1) {
        return 1; // Caso base: el factorial de 0 o 1 es 1
    } else {
        return n * factorial(n - 1); // Llamada recursiva
    }
}

int main() {
    int num;
    std::cout << "Introduce un número para calcular su factorial: ";
    std::cin >> num;

    if (num < 0) {
        std::cout << "El factorial no está definido para números negativos." << std::endl;
    } else {
        unsigned long long result = factorial(num);
        std::cout << "El factorial de " << num << " es " << result << std::endl;
    }

    return 0;
}

