/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: listas
AUTOR: Jhoan Salazar
FECHA DE CREACION: 31/05/2024
FECHA DE ULTIMA MODIFICACION:31/05/2024

*/
#include <iostream>
#include <queue>
#include <string>

class TaskManager {
private:
    std::queue<std::string> pendingTasks;

public:
    void addTask(const std::string& task) {
        pendingTasks.push(task);
        std::cout << "Tarea '" << task << "' agregada a la lista de pendientes." << std::endl;
    }

    void processTasks() {
        while (!pendingTasks.empty()) {
            std::cout << "Procesando tarea '" << pendingTasks.front() << "'..." << std::endl;
            pendingTasks.pop();
        }
        std::cout << "Todas las tareas han sido procesadas." << std::endl;
    }
};

int main() {
    TaskManager manager;

    manager.addTask("Revisar correo electrónico");
    manager.addTask("Preparar informe mensual");
    manager.addTask("Realizar llamadas de seguimiento");

    manager.processTasks();

    return 0;
}
