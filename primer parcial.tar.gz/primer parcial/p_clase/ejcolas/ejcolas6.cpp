/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: listas
AUTOR: Jhoan Salazar
FECHA DE CREACION: 30/05/2024
FECHA DE ULTIMA MODIFICACION:30/05/2024

*/
#include <iostream>
#include <queue>
#include <string>

class Truck {
private:
    std::string cargo;
public:
    Truck(const std::string& c) : cargo(c) {}

    std::string getCargo() const {
        return cargo;
    }
};

class LoadingDock {
private:
    std::queue<Truck> dockQueue;
public:
    void enqueueTruck(const Truck& truck) {
        dockQueue.push(truck);
        std::cout << "Camión con carga '" << truck.getCargo() << "' encolado." << std::endl;
    }

    void processTrucks() {
        while (!dockQueue.empty()) {
            std::cout << "Descargando camión con carga '" << dockQueue.front().getCargo() << "'." << std::endl;
            dockQueue.pop();
        }
    }
};

int main() {
    LoadingDock dock;

    dock.enqueueTruck(Truck("Frutas"));
    dock.enqueueTruck(Truck("Electrodomésticos"));
    dock.enqueueTruck(Truck("Ropa"));

    dock.processTrucks();

    return 0;
}

