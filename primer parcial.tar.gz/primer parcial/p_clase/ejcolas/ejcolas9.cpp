/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: listas
AUTOR: Jhoan Salazar
FECHA DE CREACION: 31/05/2024
FECHA DE ULTIMA MODIFICACION:31/05/2024

*/
#include <iostream>
#include <queue>
#include <string>

class Customer {
private:
    std::string name;
    int accountNumber;

public:
    Customer(const std::string& n, int accNum) : name(n), accountNumber(accNum) {}

    std::string getName() const {
        return name;
    }

    int getAccountNumber() const {
        return accountNumber;
    }
};

class BankQueue {
private:
    std::queue<Customer> customerQueue;

public:
    // Agrega un nuevo cliente a la cola del banco
    void enqueueCustomer(const Customer& customer) {
        customerQueue.push(customer);
        std::cout << "Cliente " << customer.getName() << " agregado a la cola del banco." << std::endl;
    }

    // Atiende al próximo cliente en la cola y lo elimina
    Customer dequeueCustomer() {
        if (!customerQueue.empty()) {
            Customer nextCustomer = customerQueue.front();
            customerQueue.pop();
            std::cout << "Atendiendo a " << nextCustomer.getName() << ", número de cuenta: " << nextCustomer.getAccountNumber() << std::endl;
            return nextCustomer;
        } else {
            std::cout << "No hay clientes en espera." << std::endl;
            return Customer("", -1); // Retornar un cliente "vacio" si la cola está vacía
        }
    }

    // Devuelve la cantidad de clientes en espera
    int getQueueSize() const {
        return customerQueue.size();
    }
};
