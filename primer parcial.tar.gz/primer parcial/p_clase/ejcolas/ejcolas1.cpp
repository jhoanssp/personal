/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: listas
AUTOR: Jhoan Salazar
FECHA DE CREACION: 29/05/2024
FECHA DE ULTIMA MODIFICACION:30/05/2024

*/
#include <iostream>
#include <queue>

int main() {
    std::queue<int> cola; // Crear una cola vacía de enteros

    // Añadir elementos a la cola
    cola.push(1);
    cola.push(2);
    cola.push(3);

    // Mostrar el frente de la cola (el primer elemento)
    std::cout << "Frente de la cola: " << cola.front() << std::endl; // Output: 1

    // Eliminar el frente de la cola
    cola.pop();

    // Mostrar el nuevo frente de la cola después de eliminar el primer elemento
    std::cout << "Nuevo frente de la cola: " << cola.front() << std::endl; // Output: 2

    // Mostrar el tamaño de la cola
    std::cout << "Tamaño de la cola: " << cola.size() << std::endl; // Output: 2

    // Verificar si la cola está vacía
    std::cout << "La cola está vacía: " << (cola.empty() ? "Sí" : "No") << std::endl; // Output: No

    return 0;
}
  