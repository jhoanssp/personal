/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: listas
AUTOR: Jhoan Salazar
FECHA DE CREACION: 31/05/2024
FECHA DE ULTIMA MODIFICACION:31/05/2024

*/
#include <iostream>
#include <queue>
#include <string>

class InboxManager {
private:
    std::queue<std::string> inbox;

public:
    void receiveMessage(const std::string& message) {
        inbox.push(message);
        std::cout << "Mensaje recibido: " << message << std::endl;
    }

    void processMessages() {
        while (!inbox.empty()) {
            std::cout << "Procesando mensaje: " << inbox.front() << std::endl;
            inbox.pop();
        }
        std::cout << "Bandeja de entrada vacía." << std::endl;
    }
};

int main() {
    InboxManager inbox;

    inbox.receiveMessage("Hola, ¿cómo estás?");
    inbox.receiveMessage("Recuerda la reunión a las 10:00 AM");
    inbox.receiveMessage("Adjunto encontrarás el informe solicitado");

    inbox.processMessages();

    return 0;
}
