
/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: listas
AUTOR: Jhoan Salazar
FECHA DE CREACION: 30/05/2024
FECHA DE ULTIMA MODIFICACION:30/05/2024

*/
#include <iostream>
#include <queue>
#include <string>

class TurnManagementSystem {
private:
    std::queue<std::string> turnQueue;

public:
    // Agrega un nuevo turno a la cola
    void addTurn(const std::string& turn) {
        turnQueue.push(turn);
    }

    // Atiende al próximo turno en la cola y lo elimina
    std::string getNextTurn() {
        if (!turnQueue.empty()) {
            std::string nextTurn = turnQueue.front();
            turnQueue.pop();
            return nextTurn;
        } else {
            return "No hay turnos en espera";
        }
    }

    // Muestra el turno que se está atendiendo actualmente
    std::string getCurrentTurn() {
        if (!turnQueue.empty()) {
            return turnQueue.front();
        } else {
            return "No hay turnos en espera";
        }
    }

    // Muestra la cantidad de turnos en espera
    int getQueueSize() {
        return turnQueue.size();
    }
};

int main() {
    TurnManagementSystem turnSystem;

    turnSystem.addTurn("Turno 1");
    turnSystem.addTurn("Turno 2");
    turnSystem.addTurn("Turno 3");

    std::cout << "Atendiendo a: " << turnSystem.getNextTurn() << std::endl; // Output: Atendiendo a: Turno 1
    std::cout << "Turno actual: " << turnSystem.getCurrentTurn() << std::endl; // Output: Turno actual: Turno 2
    std::cout << "Cantidad de turnos en espera: " << turnSystem.getQueueSize() << std::endl; // Output: Cantidad de turnos en espera: 2

    return 0;
}

