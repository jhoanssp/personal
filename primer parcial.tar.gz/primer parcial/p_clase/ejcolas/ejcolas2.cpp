/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: listas
AUTOR: Jhoan Salazar
FECHA DE CREACION: 29/05/2024
FECHA DE ULTIMA MODIFICACION:30/05/2024

*/
#include <iostream>
#include <queue>

int main() {
    std::priority_queue<int> colaDePrioridad; // Crear una cola de prioridad vacía

    // Añadir elementos a la cola de prioridad
    colaDePrioridad.push(30);
    colaDePrioridad.push(10);
    colaDePrioridad.push(50);
    colaDePrioridad.push(20);

    // Mostrar el frente de la cola de prioridad (el elemento con mayor prioridad)
    std::cout << "Frente de la cola de prioridad: " << colaDePrioridad.top() << std::endl; // Output: 50

    // Eliminar el frente de la cola de prioridad
    colaDePrioridad.pop();

    // Mostrar el nuevo frente de la cola de prioridad después de eliminar el primer elemento
    std::cout << "Nuevo frente de la cola de prioridad: " << colaDePrioridad.top() << std::endl; // Output: 30

    return 0;
}

