
/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: listas
AUTOR: Jhoan Salazar
FECHA DE CREACION: 30/05/2024
FECHA DE ULTIMA MODIFICACION:30/05/2024

*/
#include <iostream>
#include <vector>
#include <climits>

class CircularQueue {
private:
    std::vector<int> elements;
    int front;
    int rear;
    int capacity;

public:
    CircularQueue(int size) : capacity(size), front(-1), rear(-1) {
        elements.resize(size);
    }

    bool isFull() {
        return (front == 0 && rear == capacity - 1) || (rear == front - 1);
    }

    bool isEmpty() {
        return front == -1;
    }

    void enqueue(int element) {
        if (isFull()) {
            std::cout << "La cola está llena" << std::endl;
            return;
        }
        if (front == -1) front = 0;
        rear = (rear + 1) % capacity;
        elements[rear] = element;
    }

    int dequeue() {
        if (isEmpty()) {
            std::cout << "La cola está vacía" << std::endl;
            return INT_MIN;
        }
        int removedElement = elements[front];
        if (front == rear) {
            front = -1;
            rear = -1;
        } else {
            front = (front + 1) % capacity;
        }
        return removedElement;
    }
};

int main() {
    CircularQueue colaCircular(5); // Crear una cola circular de tamaño 5

    colaCircular.enqueue(1);
    colaCircular.enqueue(2);
    colaCircular.enqueue(3);
    colaCircular.enqueue(4);
    colaCircular.enqueue(5);

    std::cout << "Elemento eliminado: " << colaCircular.dequeue() << std::endl; // Output: 1
    std::cout << "Elemento eliminado: " << colaCircular.dequeue() << std::endl; // Output: 2

    colaCircular.enqueue(6);
    colaCircular.enqueue(7);

    std::cout << "Elemento eliminado: " << colaCircular.dequeue() << std::endl; // Output: 3

    return 0;
}

