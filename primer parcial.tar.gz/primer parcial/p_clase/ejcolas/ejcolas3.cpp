/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: listas
AUTOR: Jhoan Salazar
FECHA DE CREACION: 30/05/2024
FECHA DE ULTIMA MODIFICACION:30/05/2024

*/
#include <iostream>
#include <queue>

int main() {
    std::queue<std::string> colaDeImpresion; // Crear una cola de impresión vacía

    // Agregar trabajos a la cola de impresión
    colaDeImpresion.push("Documento1.pdf");
    colaDeImpresion.push("Documento2.docx");
    colaDeImpresion.push("Documento3.txt");

    // Procesar los trabajos de impresión en orden FIFO
    while (!colaDeImpresion.empty()) {
        std::cout << "Imprimiendo: " << colaDeImpresion.front() << std::endl;
        colaDeImpresion.pop();
    }

    return 0;
}



