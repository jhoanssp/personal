#include <iostream>
#include <cstdlib>
#include <ctime>

#define MAX 3

using namespace std;

// Plantilla para la suma recursiva de matrices
template <typename Func>
void sumaRecursivaMatrices(int** mat1, int** mat2, int** matR, int f, int c, Func func) {
    if ((f >= 0) && (c >= 0)) {
        func(mat1, mat2, matR, f, c);
        sumaRecursivaMatrices(mat1, mat2, matR, f - 1, c, func);
        sumaRecursivaMatrices(mat1, mat2, matR, f, c - 1, func);
    }
}

int main(int argc, char** argv) {
    int** mat1 = (int**)malloc(MAX * sizeof(int*));
    int** mat2 = (int**)malloc(MAX * sizeof(int*));
    int** matR = (int**)malloc(MAX * sizeof(int*));
    
    for (int j = 0; j < MAX; j++) {
        *(mat1 + j) = (int*)malloc(MAX * sizeof(int));
        *(mat2 + j) = (int*)malloc(MAX * sizeof(int));
        *(matR + j) = (int*)malloc(MAX * sizeof(int));
    }

    srand(time(NULL));

    // Lambda para inicializar matrices
    auto inicializarMatrices = [](int** mat1, int** mat2, int** matR) {
        for (int i = 0; i < MAX; i++) {
            for (int j = 0; j < MAX; j++) {
                *(*(mat1 + i) + j) = rand() ;//% 1000;
                *(*(mat2 + i) + j) = rand() ;//% 1000;
                *(*(matR + i) + j) = 0;
            }
        }
    };

    // Inicializar matrices
    inicializarMatrices(mat1, mat2, matR);

    // Lambda para imprimir matrices
    auto imprimirMatriz = [](int** mat, const char* nombre) {
        cout << "\nLa " << nombre << " es:\n";
        for (int i = 0; i < MAX; i++) {
            for (int j = 0; j < MAX; j++) {
                printf("%d", *(*(mat + i) + j));
                printf("%*s", j + 5, "");
            }
            cout << "\n";
        }
    };

    // Imprimir matrices iniciales
    imprimirMatriz(mat1, "matriz 1");
    imprimirMatriz(mat2, "matriz 2");

    // Lambda para la operación de suma de matrices
    auto sumaLambda = [](int** mat1, int** mat2, int** matR, int f, int c) {
        *(*(matR + f) + c) = *(*(mat1 + f) + c) + *(*(mat2 + f) + c);
    };

    // Suma recursiva de matrices
    sumaRecursivaMatrices(mat1, mat2, matR, MAX - 1, MAX - 1, sumaLambda);

    // Imprimir matriz resultante
    imprimirMatriz(matR, "matriz R");

    // Liberar memoria
    for (int j = 0; j < MAX; j++) {
        free(*(mat1 + j));
        free(*(mat2 + j));
        free(*(matR + j));
    }
    free(mat1);
    free(mat2);
    free(matR);

    return 0;
}
