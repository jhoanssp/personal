#include <iostream>
#include <cstdlib>
#include <ctime>
#define MAX 3

using namespace std;

// Plantilla para la suma recursiva de matrices
template <typename Func>
int sumaRecursivaMatrices(int mat1[MAX][MAX], int mat2[MAX][MAX], int f, int c, Func func) {
    if ((f == 0) && (c == 0)) {
        return func(mat1, mat2, f, c);
    } else {
        if (f > -1) {
            c--;
            if (c >= -1) {
                return func(mat1, mat2, f, c + 1) + sumaRecursivaMatrices(mat1, mat2, f, c, func);
            }
            return sumaRecursivaMatrices(mat1, mat2, f - 1, MAX - 1, func);
        }
    }
    return 0; // Esta línea asegura que siempre haya un valor de retorno
}

int main(int argc, char** argv) {
    int mat1[MAX][MAX], mat2[MAX][MAX];

    srand(time(NULL));

    // Lambda para inicializar matrices
    auto inicializarMatrices = [](int mat[MAX][MAX]) {
        for (int i = 0; i < MAX; i++) {
            for (int j = 0; j < MAX; j++) {
                mat[i][j] = rand() % 10;
            }
        }
    };

    // Inicializar matrices
    inicializarMatrices(mat1);
    inicializarMatrices(mat2);

    // Lambda para imprimir matrices
    auto imprimirMatriz = [](int mat[MAX][MAX], const char* nombre) {
        cout << "\nLa " << nombre << " es:\n";
        for (int i = 0; i < MAX; i++) {
            for (int j = 0; j < MAX; j++) {
                cout << mat[i][j] << "\t";
            }
            cout << endl;
        }
    };

    // Imprimir matrices iniciales
    imprimirMatriz(mat1, "matriz 1");
    imprimirMatriz(mat2, "matriz 2");

    // Lambda para la operación de suma de matrices
    auto sumaLambda = [](int mat1[MAX][MAX], int mat2[MAX][MAX], int f, int c) {
        return mat1[f][c] + mat2[f][c];
    };

    // Suma recursiva de matrices
    int resultado = sumaRecursivaMatrices(mat1, mat2, MAX - 1, MAX - 1, sumaLambda);

    // Imprimir resultado de la suma
    cout << "Suma de Matrices es: " << resultado << endl;

    return 0;
}
