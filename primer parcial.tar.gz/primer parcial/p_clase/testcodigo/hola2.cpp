#include <iostream>
#include <functional>
using namespace std;
typedef int entero;

template <typename Func>
void ingreso(entero* p, int t, Func func) {
    for (int i = 0; i < t; ++i) {
        func(p + i);
    }
}

template <typename Func>
void impresion(entero* p, int t, Func func) {
    cout << "{ ";
    for (int i = 0; i < t; ++i) {
        func(p + i);
    }
    cout << " }" << std::endl;
}

template <typename Func>
void proceso(entero* p, int t, Func func) {
    for (int i = 0; i < t; ++i) {
        func(p + i);
    }
}

int main() {
    int t;
    cout << "Ingrese el tamaño " << std::endl;
    cin >> t;

    entero* ptr = new entero[t];

    auto ingresoLambda = [](entero* elem) {
        std::cin >> *elem;
    };

    ingreso(ptr, t, ingresoLambda);

    auto impresionLambda = [](const entero* elem) {
        cout << *elem << " ";
    };

    impresion(ptr, t, impresionLambda);

    int e;
    cout << "\nIngrese el escalar ";
    cin >> e;

    auto procesoLambda = [e](entero* elem) {
        *elem *= e;
    };

    proceso(ptr, t, procesoLambda);

    impresion(ptr, t, impresionLambda);

    delete[] ptr;

    return 0;
}
