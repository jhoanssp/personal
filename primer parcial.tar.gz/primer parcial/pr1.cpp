#include <iostream>
#include <functional>

// Definición de la estructura del nodo de la lista enlazada
struct Nodo {
    int dato;        // Dato almacenado en el nodo
    Nodo* siguiente; // Puntero al siguiente nodo
    
    // Constructor para inicializar el nodo
    Nodo(int val) : dato(val), siguiente(nullptr) {}
};

// Función para agregar un nodo al final de la lista
void agregar(Nodo*& cabeza, int val) {
    if (cabeza == nullptr) {
        // Si la lista está vacía, crear el primer nodo
        cabeza = new Nodo(val);
        return;
    }
    
    // Si la lista no está vacía, recorrer hasta el último nodo
    Nodo* temp = cabeza;
    while (temp->siguiente != nullptr) {
        temp = temp->siguiente;
    }
    // Agregar el nuevo nodo al final de la lista
    temp->siguiente = new Nodo(val);
}

// Función para imprimir la lista enlazada
void imprimirLista(Nodo* cabeza) {
    Nodo* temp = cabeza;
    while (temp != nullptr) {
        // Imprimir el valor del nodo actual
        std::cout << temp->dato << " -> ";
        // Moverse al siguiente nodo
        temp = temp->siguiente;
    }
    // Indicar el final de la lista
    std::cout << "nullptr" << std::endl;
}

// Función para sumar los dígitos de un número
int sumaDeDigitos(int num) {
    int suma = 0;
    while (num != 0) {
        // Sumar el último dígito del número a la suma
        suma += num % 10;
        // Eliminar el último dígito del número
        num /= 10;
    }
    return suma;
}

int main() {
    // Crear una lista enlazada con algunos números
    Nodo* cabeza = nullptr;
    agregar(cabeza, 23);  // 2 + 3 = 5
    agregar(cabeza, 5);   // 5
    agregar(cabeza, 89);  // 8 + 9 = 17
    agregar(cabeza, 12);  // 1 + 2 = 3
    agregar(cabeza, 7);   // 7
    
    // Imprimir la lista enlazada
    std::cout << "Lista enlazada: ";
    imprimirLista(cabeza);
    
    // Función lambda recursiva para sumar los dígitos de los números en la lista
    std::function<int(Nodo*)> sumarDigitos = [&](Nodo* nodo) -> int {
        if (nodo == nullptr) {
            // Caso base: si el nodo es nullptr, retornar 0
            return 0;
        }
        // Calcular la suma de los dígitos del valor actual del nodo
        int suma_actual = sumaDeDigitos(nodo->dato);
        // Imprimir la suma de los dígitos del valor actual
        std::cout << "Suma de los dígitos de " << nodo->dato << " es: " << suma_actual << std::endl;
        // Llamada recursiva sumando los dígitos del valor actual y del resto de la lista
        return suma_actual + sumarDigitos(nodo->siguiente);
    };
    
    // Calcular la suma total de los dígitos
    int sumaTotal = sumarDigitos(cabeza);
    
    // Imprimir la suma total de los dígitos
    std::cout << "Suma total de los dígitos: " << sumaTotal << std::endl;
    
    // Liberar la memoria asignada a los nodos de la lista (opcional pero recomendado)
    while (cabeza != nullptr) {
        Nodo* temp = cabeza; // Almacenar la referencia al nodo actual
        cabeza = cabeza->siguiente; // Mover la cabeza al siguiente nodo
        delete temp; // Eliminar el nodo actual
    }

    return 0;
}
