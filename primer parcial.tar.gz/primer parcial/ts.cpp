#include <iostream>
#include <sstream>
#include <limits> // Para std::numeric_limits

using namespace std;

// Función para verificar si los lados forman un triángulo válido
bool esTrianguloValido(double a, double b, double c) {
    return (a + b > c) && (a + c > b) && (b + c > a);
}

// Función para identificar el tipo de triángulo
string tipoDeTriangulo(double a, double b, double c) {
    if (a == b && b == c) {
        return "Equilátero";
    } else if (a == b || b == c || a == c) {
        return "Isósceles";
    } else {
        return "Escaleno";
    }
}

// Función para convertir comas a puntos en una cadena
string convertirComasAPuntos(const string& input) {
    string output = input;
    for (char& ch : output) {
        if (ch == ',') {
            ch = '.';
        }
    }
    return output;
}

// Función para leer un número positivo
double leerNumeroPositivo(const string& mensaje) {
    string input;
    double num;
    while (true) {
        cout << mensaje;
        getline(cin, input);

        // Convertir comas a puntos
        input = convertirComasAPuntos(input);

        stringstream ss(input);

        // Intentar convertir la entrada a un número
        if (ss >> num && ss.eof() && num > 0) {
            return num;
        } else {
            cout << "Entrada no válida. Por favor, ingrese un número positivo." << endl;
        }
    }
}

int main() {
    double a, b, c;

    // Solicitar las longitudes de los lados
    cout << "Ingrese las longitudes de los tres lados del triángulo:" << endl;

    while (true) {
        a = leerNumeroPositivo("Lado a: ");
        b = leerNumeroPositivo("Lado b: ");
        c = leerNumeroPositivo("Lado c: ");

        // Verificar si las longitudes forman un triángulo válido
        if (!esTrianguloValido(a, b, c)) {
            cout << "Las longitudes ingresadas no forman un triángulo válido. Intente de nuevo." << endl;
        } else {
            break;
        }
    }

    // Determinar el tipo de triángulo
    string tipo = tipoDeTriangulo(a, b, c);
    cout << "El triángulo es: " << tipo << endl;

    return 0;
}

