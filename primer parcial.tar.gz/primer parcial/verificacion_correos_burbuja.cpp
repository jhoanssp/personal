#include <iostream>
#include <sstream>
#include <algorithm>
#include <map>
#include <set>
#include <fstream>
#include <cctype>
#include <iomanip> // para setw y setfill
#include <limits>  // para numeric_limits
#include <cstring>
#include <vector>

using namespace std;

class Clave {
public:
    string clave;

    Clave(string clave) {
        this->clave = clave;
    }
};

class Trabajo {
public:
    string nombre;
    double sueldo;

    Trabajo(string nombre, double sueldo) {
        this->nombre = nombre;
        this->sueldo = sueldo;
    }
};

class Persona {
public:
    string cedula;
    string nombre1;
    string nombre2;
    string apellido;
    string correo;

    Persona(string cedula, string nombre1, string nombre2, string apellido, string correo) {
        this->cedula = cedula;
        this->nombre1 = nombre1;
        this->nombre2 = nombre2;
        this->apellido = apellido;
        this->correo = correo;
    }
};

class Empleado : public Persona {
public:
    string idEmpleado;
    Clave clave;
    string claveCifrada;
    vector<Trabajo> trabajos;

    Empleado(string idEmpleado, string cedula, string nombre1, string nombre2, string apellido, string correo, string clave, string claveCifrada)
        : Persona(cedula, nombre1, nombre2, apellido, correo), clave(clave), claveCifrada(claveCifrada) {
        this->idEmpleado = idEmpleado;
    }

    void agregarTrabajo(string nombre, double sueldo) {
        trabajos.push_back(Trabajo(nombre, sueldo));
    }

    void ordenarSueldos() {
        for (size_t i = 0; i < trabajos.size(); i++) {
            for (size_t j = 0; j < trabajos.size() - i - 1; j++) {
                if (trabajos[j].sueldo > trabajos[j + 1].sueldo) {
                    swap(trabajos[j], trabajos[j + 1]);
                }
            }
        }
    }
};

class Node {
public:
    Empleado* empleado;
    Node* next;
    Node* prev;

    Node(Empleado* empleado) : empleado(empleado), next(nullptr), prev(nullptr) {}
};

class DoublyLinkedList {
public:
    Node* head;
    Node* tail;

    DoublyLinkedList() : head(nullptr), tail(nullptr) {}

    void append(Empleado* empleado) {
        Node* newNode = new Node(empleado);
        if (!head) {
            head = tail = newNode;
        } else {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
    }

    Empleado* findByCedula(const string& cedula) {
        Node* current = head;
        while (current) {
            if (current->empleado->cedula == cedula) {
                return current->empleado;
            }
            current = current->next;
        }
        return nullptr;
    }

    void saveToFile(const string& filePath) {
        ofstream archivo(filePath, ios::trunc); // Modo de apertura para sobrescribir
        if (archivo.is_open()) {
            Node* current = head;
            while (current) {
                Empleado* empleado = current->empleado;
                archivo << empleado->idEmpleado << endl;
                archivo << empleado->nombre1 << " " << empleado->nombre2 << " " << empleado->apellido << endl;
                archivo << empleado->cedula << endl;
                archivo << empleado->correo << endl;
                archivo << empleado->clave.clave << endl;
                archivo << empleado->claveCifrada << endl;
                for (const auto& trabajo : empleado->trabajos) {
                    archivo << trabajo.nombre << ": " << fixed << setprecision(2) << trabajo.sueldo << endl;
                }
                archivo << "END" << endl;
                current = current->next;
            }
            archivo.close();
            cout << "Los datos han sido guardados y actualizados en '" << filePath << "'." << endl;
        } else {
            cout << "No se pudo abrir el archivo para escribir." << endl;
        }
    }
};

void cargarDatosExistentes(string filePath, map<string, int>& correosExistentes, map<string, int>& contrasenasExistentes, set<string>& cedulasExistentes, DoublyLinkedList& empleados, int& ultimoID) {
    ifstream archivo(filePath);
    if (archivo.is_open()) {
        string linea;
        while (getline(archivo, linea)) {
            string idEmpleado;
            string nombreCompleto;
            string cedula;
            string correo;
            string contrasena;
            string contrasenaCifrada;

            idEmpleado = linea;

            getline(archivo, nombreCompleto);
            getline(archivo, cedula);
            getline(archivo, correo);
            getline(archivo, contrasena);
            getline(archivo, contrasenaCifrada);

            Empleado* empleado = new Empleado(idEmpleado, cedula, nombreCompleto, "", "", correo, contrasena, contrasenaCifrada);

            while (getline(archivo, linea) && linea != "END") {
                stringstream ss(linea);
                string nombreTrabajo;
                double sueldo;
                ss >> nombreTrabajo;
                ss.ignore(2); // Ignorar el ": "
                ss >> sueldo;
                empleado->agregarTrabajo(nombreTrabajo, sueldo);
            }

            empleados.append(empleado);
            cedulasExistentes.insert(cedula);

            // Verificar y procesar el correo para manejar los números al final
            size_t atPos = correo.find('@');
            if (atPos != string::npos) {
                string correoBase = correo.substr(0, atPos);
                size_t numPos = correoBase.find_last_not_of("0123456789");

                if (numPos != string::npos) {
                    string base = correoBase.substr(0, numPos + 1);
                    string numStr = correoBase.substr(numPos + 1);
                    int num = numStr.empty() ? 0 : stoi(numStr);
                    correosExistentes[base] = max(correosExistentes[base], num + 1);
                }
            }

            // Verificar y procesar la contraseña para manejar los números al final
            size_t numPos = contrasena.find_last_not_of("0123456789");
            if (numPos != string::npos) {
                string base = contrasena.substr(0, numPos + 1);
                string numStr = contrasena.substr(numPos + 1);
                int num = numStr.empty() ? 0 : stoi(numStr);
                contrasenasExistentes[base] = max(contrasenasExistentes[base], num + 1);
            }


            // Obtener el último ID
            if (idEmpleado.length() > 5) {
                try {
                    int idNum = stoi(idEmpleado.substr(5));
                    ultimoID = max(ultimoID, idNum);
                } catch (const std::invalid_argument& e) {
                    cerr << "Error al convertir ID de empleado a entero: " << e.what() << endl;
                }
            }
        }
        archivo.close();
    } else {
        cout << "No se pudo abrir el archivo para leer." << endl;
    }
}

bool validarCedula(const string& cedula) {
    return cedula.length() == 10 && all_of(cedula.begin(), cedula.end(), ::isdigit);
}

bool validarNombreApellido(const string& nombre) {
    if (nombre.length() < 2) {
        return false;
    }
    return all_of(nombre.begin(), nombre.end(), ::isalpha);
}

string cifrarContrasena(const string& contrasena) {
    string cifrada;
    for (char c : contrasena) {
        if (isalpha(c)) {
            if (islower(c)) {
                cifrada += (c - 'a' + 2) % 26 + 'a';
            } else {
                cifrada += (c - 'A' + 2) % 26 + 'A';
            }
        } else if (isdigit(c)) {
            cifrada += (c - '0' + 2) % 10 + '0';
        }
    }

    // Si no hay números en la contraseña original, agregar un '3' al final de la cifrada
    if (cifrada.find_first_of("0123456789") == string::npos) {
        cifrada += '3';
    }

    return cifrada;
}

string descifrarContrasena(const string& cifrada) {
    string contrasena;
    string cifrada_sin_3 = cifrada;

    // Si el último carácter es '3' y no hay números en la parte anterior de la cadena, eliminarlo
    if (cifrada.back() == '3' && cifrada.find_first_of("0123456789") == cifrada.size() - 1) {
        cifrada_sin_3.pop_back();
    }

    for (char c : cifrada_sin_3) {
        if (isalpha(c)) {
            if (islower(c)) {
                contrasena += (c - 'a' - 4 + 26) % 26 + 'a';
            } else {
                contrasena += (c - 'A' - 4 + 26) % 26 + 'A';
            }
        } else if (isdigit(c)) {
            contrasena += (c - '0' - 2 + 10) % 10 + '0';
        }
    }

    return contrasena;
}

string generarCorreo(map<string, int>& correosExistentes, const string& nombre1, const string& nombre2, const string& apellido) {
    string correoBase;
    correoBase += tolower(nombre1[0]); // Primera letra del primer nombre
    if (!nombre2.empty()) { // Comprobar si hay segundo nombre
        correoBase += tolower(nombre2[0]); // Primera letra del segundo nombre
    }

    // Convertir el apellido a minúsculas
    string apellidoMin = apellido;
    transform(apellidoMin.begin(), apellidoMin.end(), apellidoMin.begin(), ::tolower);

    correoBase += apellidoMin; // Apellido en minúsculas

    // Generar un correo único con números incrementales
    string correo = correoBase;
    if (correosExistentes[correoBase] > 0) {
        correo += to_string(correosExistentes[correoBase]);
    }
    correosExistentes[correoBase]++;

    correo += "@espe.edu.ec"; // Dominio

    return correo;
}

string generarContrasena(map<string, int>& contrasenasExistentes, const string& nombre1, const string& nombre2, const string& apellido) {
    string claveBase;
    claveBase += tolower(nombre1[0]); // Primera letra del primer nombre
    if (!nombre2.empty()) { // Comprobar si hay segundo nombre
        claveBase += tolower(nombre2[0]); // Primera letra del segundo nombre
    }

    string apellidoMin = apellido;
    transform(apellidoMin.begin(), apellidoMin.end(), apellidoMin.begin(), ::tolower);

    claveBase += apellidoMin; // Apellido en minúsculas

    // Generar una clave única con números incrementales
    string clave = claveBase;
    if (contrasenasExistentes[claveBase] > 0) {
        clave += to_string(contrasenasExistentes[claveBase]);
    }
    contrasenasExistentes[claveBase]++;

    return clave;
}

string generarIDEmpleado(int& ultimoID) {
    ultimoID++;
    ostringstream oss;
    oss << "emp_" << setw(4) << setfill('0') << ultimoID;
    return oss.str();
}

bool validarSueldo(const string& sueldoStr) {
    for (char c : sueldoStr) {
        if (!isdigit(c) && c != '.') {
            return false;
        }
    }
    try {
        stod(sueldoStr); // Intentar convertir a double
    } catch (const invalid_argument&) {
        return false;
    } catch (const out_of_range&) {
        return false;
    }
    return true;
}

double pedirSueldo() {
    string sueldoStr;
    while (true) {
        cout << "Ingrese el sueldo: ";
        cin >> sueldoStr;
        if (validarSueldo(sueldoStr)) {
            return stod(sueldoStr);
        } else {
            cout << "Sueldo inválido. Ingrese un número válido." << endl;
        }
    }
}

void agregarEmpleado(DoublyLinkedList& empleados, map<string, int>& correosExistentes, map<string, int>& contrasenasExistentes, set<string>& cedulasExistentes, int& ultimoID) {
    string cedula, nombre1, nombre2, apellido, correo, clave, claveCifrada;
    double sueldo;
    string nombreTrabajo;

    cout << "Ingrese la cédula: ";
    cin >> cedula;

    if (!validarCedula(cedula) || cedulasExistentes.find(cedula) != cedulasExistentes.end()) {
        cout << "Cédula inválida o ya existe." << endl;
        return;
    }

    cout << "Ingrese el primer nombre: ";
    cin >> nombre1;
    if (!validarNombreApellido(nombre1)) {
        cout << "Nombre inválido." << endl;
        return;
    }

    cout << "Ingrese el segundo nombre (opcional): ";
    cin >> nombre2;

    cout << "Ingrese el apellido: ";
    cin >> apellido;
    if (!validarNombreApellido(apellido)) {
        cout << "Apellido inválido." << endl;
        return;
    }

    correo = generarCorreo(correosExistentes, nombre1, nombre2, apellido);
    clave = generarContrasena(contrasenasExistentes, nombre1, nombre2, apellido);
    claveCifrada = cifrarContrasena(clave);
    string idEmpleado = generarIDEmpleado(ultimoID);

    Empleado* nuevoEmpleado = new Empleado(idEmpleado, cedula, nombre1, nombre2, apellido, correo, clave, claveCifrada);

    cout << "Ingrese el nombre del trabajo: ";
    cin >> nombreTrabajo;
    sueldo = pedirSueldo();
    nuevoEmpleado->agregarTrabajo(nombreTrabajo, sueldo);

    empleados.append(nuevoEmpleado);
    cedulasExistentes.insert(cedula);

    cout << "Empleado agregado exitosamente." << endl;
}

void buscarEmpleadoPorCedula(DoublyLinkedList& empleados) {
    string cedula;
    cout << "Ingrese la cédula del empleado a buscar: ";
    cin >> cedula;

    Empleado* empleado = empleados.findByCedula(cedula);
    if (!empleado) {
        cout << "Empleado no encontrado." << endl;
        return;
    }

    cout << "Empleado encontrado: " << empleado->nombre1 << " " << empleado->apellido << endl;
    cout << "Trabajos y sueldos actuales:" << endl;
    for (const auto& trabajo : empleado->trabajos) {
        cout << trabajo.nombre << ": " << fixed << setprecision(2) << trabajo.sueldo << endl;
    }

    string nombreTrabajo;
    double nuevoSueldo;
    cout << "Ingrese el nombre del nuevo trabajo: ";
    cin >> nombreTrabajo;
    nuevoSueldo = pedirSueldo();
    empleado->agregarTrabajo(nombreTrabajo, nuevoSueldo);

    empleado->ordenarSueldos();
    cout << "Sueldo actualizado y trabajos ordenados:" << endl;
    for (const auto& trabajo : empleado->trabajos) {
        cout << trabajo.nombre << ": " << fixed << setprecision(2) << trabajo.sueldo << endl;
    }
}

void mostrarMenu() {
    DoublyLinkedList empleados;
    map<string, int> correosExistentes;
    map<string, int> contrasenasExistentes;
    set<string> cedulasExistentes;
    int ultimoID = 0;

    string filePath = "empleados.txt";
    cargarDatosExistentes(filePath, correosExistentes, contrasenasExistentes, cedulasExistentes, empleados, ultimoID);

    int opcion;
    do {
        cout << "1. Agregar nuevo empleado" << endl;
        cout << "2. Buscar empleado por cédula y actualizar sueldo" << endl;
        cout << "3. Salir" << endl;
        cout << "Seleccione una opción: ";
        cin >> opcion;

        switch (opcion) {
            case 1:
                agregarEmpleado(empleados, correosExistentes, contrasenasExistentes, cedulasExistentes, ultimoID);
                empleados.saveToFile(filePath);
                break;
            case 2:
                buscarEmpleadoPorCedula(empleados);
                empleados.saveToFile(filePath);
                break;
            case 3:
                cout << "Saliendo del programa." << endl;
                break;
            default:
                cout << "Opción inválida. Intente nuevamente." << endl;
                break;
        }
    } while (opcion != 3);
}

int main() {
    mostrarMenu();
    return 0;
}
