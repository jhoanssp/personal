#include <iostream>
#include "Cedula.h"

int main() {
    std::string nombre, fechaNacimiento, diaVencimiento, otrosParametros;
    std::cout << "Ingrese el nombre: ";
    std::getline(std::cin, nombre);
    std::cout << "Ingrese la fecha de nacimiento: ";
    std::getline(std::cin, fechaNacimiento);
    std::cout << "Ingrese el día de vencimiento: ";
    std::getline(std::cin, diaVencimiento);
    std::cout << "Ingrese otros parámetros: ";
    std::getline(std::cin, otrosParametros);

    Cedula cedula(nombre, fechaNacimiento, diaVencimiento, otrosParametros);
    std::cout << "\nDatos de la cédula:\n";
    cedula.imprimirDatos();

    return 0;
}