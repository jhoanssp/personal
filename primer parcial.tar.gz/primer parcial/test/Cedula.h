#ifndef CEDULA_H
#define CEDULA_H

#include <string>

class Cedula {
public:
    Cedula(); // Constructor
    Cedula(std::string nombre, std::string fechaNacimiento, std::string diaVencimiento, std::string otrosParametros); // Constructor con parámetros
    void imprimirDatos(); // Función para imprimir los datos de la cédula
private:
    std::string nombre;
    std::string fechaNacimiento;
    std::string diaVencimiento;
    std::string otrosParametros;
};

#endif