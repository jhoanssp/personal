#include "Cedula.h"
#include <iostream>

Cedula::Cedula() {
    nombre = "";
    fechaNacimiento = "";
    diaVencimiento = "";
    otrosParametros = "";
}

Cedula::Cedula(std::string nombre, std::string fechaNacimiento, std::string diaVencimiento, std::string otrosParametros) {
    this->nombre = nombre;
    this->fechaNacimiento = fechaNacimiento;
    this->diaVencimiento = diaVencimiento;
    this->otrosParametros = otrosParametros;
}

void Cedula::imprimirDatos() {
    std::cout << "Nombre: " << nombre << std::endl;
    std::cout << "Fecha de nacimiento: " << fechaNacimiento << std::endl;
    std::cout << "Día de vencimiento: " << diaVencimiento << std::endl;
    std::cout << "Otros parámetros: " << otrosParametros << std::endl;
}