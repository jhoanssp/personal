#include <iostream>
#include <sstream>
#include <fstream>
#include <algorithm>
#include <map>
#include <set>
#include <vector>
#include <iomanip>
#include <limits>
#include <cstring>
#include <stdexcept>

using namespace std;

class Persona {
public:
    string cedula;
    string nombre1;
    string nombre2;
    string apellido;
    string correo;
};

class Clave {
public:
    string clave;
    string claveCifrada;
};

class Empleado : public Persona {
public:
    string idEmpleado;
    double sueldo;
    Clave clave;
};

class Nodo {
public:
    Empleado empleado;
    Nodo* siguiente;
    Nodo* anterior;

    Nodo(Empleado empleado) {
        this->empleado = empleado;
        this->siguiente = nullptr;
        this->anterior = nullptr;
    }
};

class ListaDobleEnlazada {
private:
    Nodo* cabeza;
public:
    ListaDobleEnlazada() {
        cabeza = nullptr;
    }

    void anexar(Empleado empleado) {
        Nodo* nuevoNodo = new Nodo(empleado);
        if (!cabeza) {
            cabeza = nuevoNodo;
            return;
        }
        Nodo* temp = cabeza;
        while (temp->siguiente) {
            temp = temp->siguiente;
        }
        temp->siguiente = nuevoNodo;
        nuevoNodo->anterior = temp;
    }

    Empleado* buscarPorCedula(const string& cedula) {
        Nodo* temp = cabeza;
        while (temp) {
            if (temp->empleado.cedula == cedula) {
                return &temp->empleado;
            }
            temp = temp->siguiente;
        }
        return nullptr;
    }

    void guardarEnArchivo(const string& filePath) {
        ofstream archivo(filePath);
        if (archivo.is_open()) {
            Nodo* temp = cabeza;
            while (temp) {
                archivo << temp->empleado.idEmpleado << endl;
                archivo << temp->empleado.cedula << endl;
                archivo << temp->empleado.nombre1 << endl;
                archivo << temp->empleado.nombre2 << endl;
                archivo << temp->empleado.apellido << endl;
                archivo << temp->empleado.correo << endl;
                archivo << temp->empleado.clave.clave << endl;
                archivo << temp->empleado.clave.claveCifrada << endl;
                archivo << fixed << setprecision(2) << temp->empleado.sueldo << endl;
                temp = temp->siguiente;
            }
            archivo.close();
        } else {
            cout << "No se pudo abrir el archivo para escribir." << endl;
        }
    }

    void cargarDatosExistentes(const string& filePath, map<string, int>& correosExistentes, map<string, int>& contrasenasExistentes, set<string>& cedulasRegistradas, int& ultimoID) {
        ifstream archivo(filePath);
        if (archivo.is_open()) {
            string linea;
            while (getline(archivo, linea)) {
                Empleado empleado;
                empleado.idEmpleado = linea;

                getline(archivo, empleado.cedula);
                cedulasRegistradas.insert(empleado.cedula);

                getline(archivo, empleado.nombre1);
                getline(archivo, empleado.nombre2);
                getline(archivo, empleado.apellido);

                getline(archivo, empleado.correo);
                correosExistentes[empleado.correo.substr(0, empleado.correo.find('@'))]++;

                getline(archivo, empleado.clave.clave);
                getline(archivo, empleado.clave.claveCifrada);
                contrasenasExistentes[empleado.clave.clave]++;

                getline(archivo, linea);
                empleado.sueldo = stod(linea);

                anexar(empleado);

                stringstream ss(empleado.idEmpleado.substr(5));
                int id;
                ss >> id;
                ultimoID = max(ultimoID, id);
            }
            archivo.close();
        } else {
            cout << "No se pudo abrir el archivo para leer." << endl;
        }
    }
};

// Función para validar nombres y apellidos
bool validarNombreApellido(const string& nombre) {
    if (nombre.length() < 2) return false;
    for (char c : nombre) {
        if (!isalpha(c)) return false;
    }
    return true;
}

// Función para validar la cédula (debe ser numérica y de 10 dígitos)
bool validarCedula(const string& cedula) {
    if (cedula.length() != 10) return false;
    for (char c : cedula) {
        if (!isdigit(c)) return false;
    }
    return true;
}

// Función para cifrar la contraseña
string cifrarContrasena(const string& contrasena) {
    string cifrada;
    bool tieneNumeros = false;
    for (char c : contrasena) {
        if (isalpha(c)) {
            char base = islower(c) ? 'a' : 'A';
            cifrada += base + (c - base + 3) % 26;
        } else if (isdigit(c)) {
            cifrada += '0' + (c - '0' + 3) % 10;
            tieneNumeros = true;
        } else {
            cifrada += c;
        }
    }
    if (!tieneNumeros) cifrada += '3';
    return cifrada;
}

// Función para descifrar la contraseña
string descifrarContrasena(const string& contrasenaCifrada) {
    string descifrada;
    for (size_t i = 0; i < contrasenaCifrada.length(); ++i) {
        char c = contrasenaCifrada[i];
        if (isalpha(c)) {
            char base = islower(c) ? 'a' : 'A';
            descifrada += base + (c - base - 3 + 26) % 26;
        } else if (isdigit(c)) {
            descifrada += '0' + (c - '0' - 3 + 10) % 10;
        } else {
            descifrada += c;
        }
    }
    if (descifrada.back() == '3') descifrada.pop_back();
    return descifrada;
}

// Función para generar un correo único
string generarCorreo(map<string, int>& correosExistentes, const string& nombre1, const string& nombre2, const string& apellido) {
    string correoBase;
    correoBase += tolower(nombre1[0]);
    if (!nombre2.empty()) correoBase += tolower(nombre2[0]);
    correoBase += apellido;

    if (correosExistentes[correoBase] > 0) {
        correoBase += to_string(correosExistentes[correoBase]);
    }
    correosExistentes[correoBase]++;

    return correoBase + "@espe.edu.ec";
}

// Función para generar una contraseña única
string generarContrasena(map<string, int>& contrasenasExistentes, const string& nombre1, const string& nombre2, const string& apellido) {
    string contrasenaBase;
    contrasenaBase += apellido.back();
    if (!nombre2.empty()) contrasenaBase += nombre2[0];
    contrasenaBase += nombre1[0];
    string apellidoReversed = apellido.substr(0, apellido.length() - 1);
    reverse(apellidoReversed.begin(), apellidoReversed.end());
    contrasenaBase += apellidoReversed;

    if (contrasenasExistentes[contrasenaBase] > 0) {
        contrasenaBase += to_string(contrasenasExistentes[contrasenaBase]);
    }
    contrasenasExistentes[contrasenaBase]++;

    return contrasenaBase;
}

// Función para generar un ID de empleado único
string generarIDEmpleado(int& ultimoID) {
    ultimoID++;
    stringstream ss;
    ss << "espe-" << setw(3) << setfill('0') << ultimoID;
    return ss.str();
}

// Función para validar el sueldo ingresado
bool validarSueldo(const string& sueldo) {
    bool puntoEncontrado = false;
    bool comaEncontrada = false;
    for (char c : sueldo) {
        if (isdigit(c)) {
            continue;
        } else if (c == '.') {
            if (puntoEncontrado || comaEncontrada) {
                return false;
            }
            puntoEncontrado = true;
        } else if (c == ',') {
            if (comaEncontrada || puntoEncontrado) {
                return false;
            }
            comaEncontrada = true;
        } else {
            return false;
        }
    }
    return true;
}

// Función para solicitar el sueldo al usuario y validarlo
double pedirSueldo() {
    string sueldoStr;
    do {
        cout << "Ingrese el sueldo (solo números, y un punto o una coma como separador decimal): ";
        cin >> sueldoStr;
        if (!validarSueldo(sueldoStr)) {
            cout << "Sueldo no válido. Intente nuevamente." << endl;
        }
    } while (!validarSueldo(sueldoStr));
    replace(sueldoStr.begin(), sueldoStr.end(), ',', '.');
    return stod(sueldoStr);
}

int main() {
    ListaDobleEnlazada lista;
    map<string, int> correosExistentes;
    map<string, int> contrasenasExistentes;
    set<string> cedulasRegistradas;
    int ultimoID = 0;

    lista.cargarDatosExistentes("empleados.txt", correosExistentes, contrasenasExistentes, cedulasRegistradas, ultimoID);

    string opcion;
    do {
        cout << "Seleccione una opción:" << endl;
        cout << "1. Registrar nuevo empleado" << endl;
        cout << "2. Buscar empleado por cédula" << endl;
        cout << "3. Salir" << endl;
        cin >> opcion;

        if (opcion == "1") {
            Empleado nuevoEmpleado;

            // Solicitar y validar datos personales
            do {
                cout << "Ingrese la cédula (10 dígitos numéricos): ";
                cin >> nuevoEmpleado.cedula;
                if (!validarCedula(nuevoEmpleado.cedula) || cedulasRegistradas.count(nuevoEmpleado.cedula)) {
                    cout << "Cédula no válida o ya registrada. Intente nuevamente." << endl;
                }
            } while (!validarCedula(nuevoEmpleado.cedula) || cedulasRegistradas.count(nuevoEmpleado.cedula));
            cedulasRegistradas.insert(nuevoEmpleado.cedula);

            do {
                cout << "Ingrese el primer nombre: ";
                cin >> nuevoEmpleado.nombre1;
                if (!validarNombreApellido(nuevoEmpleado.nombre1)) {
                    cout << "Nombre no válido. Intente nuevamente." << endl;
                }
            } while (!validarNombreApellido(nuevoEmpleado.nombre1));

            cout << "Ingrese el segundo nombre (opcional): ";
            cin.ignore();
            getline(cin, nuevoEmpleado.nombre2);
            if (!nuevoEmpleado.nombre2.empty() && !validarNombreApellido(nuevoEmpleado.nombre2)) {
                cout << "Segundo nombre no válido. Se ignorará." << endl;
                nuevoEmpleado.nombre2.clear();
            }

            do {
                cout << "Ingrese el apellido: ";
                cin >> nuevoEmpleado.apellido;
                if (!validarNombreApellido(nuevoEmpleado.apellido)) {
                    cout << "Apellido no válido. Intente nuevamente." << endl;
                }
            } while (!validarNombreApellido(nuevoEmpleado.apellido));

            // Generar correo y contraseña únicos
            nuevoEmpleado.correo = generarCorreo(correosExistentes, nuevoEmpleado.nombre1, nuevoEmpleado.nombre2, nuevoEmpleado.apellido);
            nuevoEmpleado.clave.clave = generarContrasena(contrasenasExistentes, nuevoEmpleado.nombre1, nuevoEmpleado.nombre2, nuevoEmpleado.apellido);
            nuevoEmpleado.clave.claveCifrada = cifrarContrasena(nuevoEmpleado.clave.clave);

            // Solicitar y validar sueldo
            nuevoEmpleado.sueldo = pedirSueldo();

            // Generar ID único
            nuevoEmpleado.idEmpleado = generarIDEmpleado(ultimoID);

            // Añadir empleado a la lista
            lista.anexar(nuevoEmpleado);

            // Guardar los datos actualizados en el archivo
            lista.guardarEnArchivo("empleados.txt");

            cout << "Empleado registrado exitosamente." << endl;

        } else if (opcion == "2") {
            string cedula;
            cout << "Ingrese la cédula del empleado a buscar: ";
            cin >> cedula;
            Empleado* empleado = lista.buscarPorCedula(cedula);
            if (empleado) {
                cout << "Empleado encontrado:" << endl;
                cout << "ID: " << empleado->idEmpleado << endl;
                cout << "Nombre: " << empleado->nombre1 << " " << empleado->nombre2 << " " << empleado->apellido << endl;
                cout << "Correo: " << empleado->correo << endl;
                cout << "Sueldo: $" << fixed << setprecision(2) << empleado->sueldo << endl;
                cout << "Contraseña Cifrada: " << empleado->clave.claveCifrada << endl;
                cout << "Contraseña Descifrada: " << descifrarContrasena(empleado->clave.claveCifrada) << endl;
            } else {
                cout << "Empleado no encontrado." << endl;
            }
        }

    } while (opcion != "3");

    return 0;
}
