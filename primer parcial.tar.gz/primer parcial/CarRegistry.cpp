

#include "CarRegistry.h"
#include <iostream>
#include <fstream>

CarNode::CarNode(std::string n, int e, std::string p, std::string c) 
    : nombre(n), edad(e), placa(p), cedula(c), siguiente(nullptr), anterior(nullptr) {}

CarRegistry::CarRegistry() : cabeza(nullptr) {}

CarRegistry::~CarRegistry() {
    if (!cabeza) return;

    CarNode* actual = cabeza;
    do {
        CarNode* siguienteNodo = actual->siguiente;
        delete actual;
        actual = siguienteNodo;
    } while (actual != cabeza);
}

void CarRegistry::insertar(std::string nombre, int edad, std::string placa, std::string cedula) {
    CarNode* nuevoNodo = new CarNode(nombre, edad, placa, cedula);
    if (!cabeza) {
        cabeza = nuevoNodo;
        cabeza->siguiente = cabeza;
        cabeza->anterior = cabeza;
    } else {
        CarNode* cola = cabeza->anterior;
        cola->siguiente = nuevoNodo;
        nuevoNodo->anterior = cola;
        nuevoNodo->siguiente = cabeza;
        cabeza->anterior = nuevoNodo;
    }

    // Guardar automáticamente después de insertar un nuevo registro
    guardarEnArchivo("/home/" + std::string(getenv("USER")) + "/Downloads/proyecto_P1/car_registry.txt");
}

void CarRegistry::eliminar(std::string cedula, std::string placa) {
    if (!cabeza) return;

    CarNode* actual = cabeza;
    do {
        if (actual->cedula == cedula && actual->placa == placa) {
            if (actual == cabeza && actual->siguiente == cabeza) {
                delete actual;
                cabeza = nullptr;
                return;
            }

            if (actual == cabeza) {
                cabeza = actual->siguiente;
            }

            CarNode* nodoAnterior = actual->anterior;
            CarNode* nodoSiguiente = actual->siguiente;

            nodoAnterior->siguiente = nodoSiguiente;
            nodoSiguiente->anterior = nodoAnterior;

            delete actual;
            return;
        }
        actual = actual->siguiente;
    } while (actual != cabeza);
}

CarNode* CarRegistry::buscar(std::string cedula, std::string placa) {
    if (!cabeza) return nullptr;

    CarNode* actual = cabeza;
    do {
        if (actual->cedula == cedula && actual->placa == placa) {
            return actual;
        }
        actual = actual->siguiente;
    } while (actual != cabeza);

    return nullptr;
}

void CarRegistry::buscarPorCedula(std::string cedula) {
    if (!cabeza) return;

    CarNode* actual = cabeza;
    bool encontrado = false;
    do {
        if (actual->cedula == cedula) {
            std::cout << "Nombre: " << actual->nombre << ", Edad: " << actual->edad << ", Placa: " << actual->placa << std::endl;
            encontrado = true;
        }
        actual = actual->siguiente;
    } while (actual != cabeza);

    if (!encontrado) {
        std::cout << "No se encontraron vehículos para la cédula: " << cedula << std::endl;
    }
}

void CarRegistry::mostrar() {
    if (!cabeza) return;

    CarNode* actual = cabeza;
    do {
        std::cout << "Nombre: " << actual->nombre << ", Edad: " << actual->edad << ", Placa: " << actual->placa << ", Cédula: " << actual->cedula << std::endl;
        actual = actual->siguiente;
    } while (actual != cabeza);
}

void CarRegistry::guardarEnArchivo(const std::string& filename) {
    std::ofstream archivo(filename);
    if (!archivo.is_open()) {
        std::cerr << "No se pudo abrir el archivo para guardar." << std::endl;
        return;
    }

    if (!cabeza) {
        archivo.close();
        return;
    }

    CarNode* actual = cabeza;
    do {
        archivo << "Nombre: " << actual->nombre << ", Edad: " << actual->edad << ", Placa: " << actual->placa << ", Cédula: " << actual->cedula << std::endl;
        actual = actual->siguiente;
    } while (actual != cabeza);

    archivo.close();
}

