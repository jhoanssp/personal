/**********************
*                Universidad de las Fuerzas Armadas - ESPE
*                    Proyecto Final Primer Parcial
*
*Autores:    Samantha Martinez
*            Jhoan Salazar
*            Alexander Diaz
*
*Fecha de creacion: 2024-06-15
*Fecha de modificacion: 2024-06-25
*Nivel: Tercero                                 NRC: 16426
*
***********************/
#include "Usuario.h"
#include <algorithm>//Define las funciones de plantilla contenedor de la biblioteca estándar de C++ que realizan algoritmos
#include <cctype>// Incluye el encabezado <ctype.h> de la biblioteca estándar de C y agrega los nombres asociados al espacio de nombres std .
#include <unordered_map>//Referencia de API para la clase de contenedor de la biblioteca estándar de C++

Usuario::Usuario(const std::string& n, const std::string& sn, const std::string& a, const std::string& c, const std::string& p, std::unordered_map<std::string, int>& correosExistentes)
    : nombre(n), segundoNombre(sn), apellido(a), cedula(c), provincia(p), carros(nullptr) {
    correo = generarCorreo(correosExistentes);
    contrasena = generarContrasena();
}

std::string Usuario::generarCorreo(std::unordered_map<std::string, int>& correosExistentes) {
    std::string baseCorreo = nombre.substr(0, 1) + (segundoNombre.empty() ? "" : segundoNombre.substr(0, 1)) + apellido;
    std::transform(baseCorreo.begin(), baseCorreo.end(), baseCorreo.begin(), ::tolower);

    if (correosExistentes.find(baseCorreo) != correosExistentes.end()) {
        baseCorreo += std::to_string(correosExistentes[baseCorreo]++);
    } else {
        correosExistentes[baseCorreo] = 1;
    }

    return baseCorreo + "@espe.edu.ec";
}

std::string Usuario::generarContrasena() {
    std::string baseContrasena = apellido.back() + (segundoNombre.empty() ? "" : segundoNombre.substr(0, 1)) + nombre.substr(0, 1);
    std::string reversedApellido = apellido;
    std::reverse(reversedApellido.begin(), reversedApellido.end());
    baseContrasena += reversedApellido;

    return baseContrasena;
}

void Usuario::agregarCarro(const Carro& carro) {
    NodoCarro* nuevo = new NodoCarro(carro);
    if (!carros) {
        carros = nuevo;
        carros->siguiente = carros;
        carros->anterior = carros;
    } else {
        NodoCarro* ultimo = carros->anterior;
        ultimo->siguiente = nuevo;
        nuevo->anterior = ultimo;
        nuevo->siguiente = carros;
        carros->anterior = nuevo;
    }
}

void Usuario::eliminarCarro(const std::string& placa) {
    if (!carros) return;

    NodoCarro* actual = carros;
    do {
        if (actual->carro.getPlaca() == placa) {
            if (actual == carros && actual->siguiente == carros) {
                delete actual;
                carros = nullptr;
            } else {
                actual->anterior->siguiente = actual->siguiente;
                actual->siguiente->anterior = actual->anterior;
                if (actual == carros) {
                    carros = actual->siguiente;
                }
                delete actual;
            }
            return;
        }
        actual = actual->siguiente;
    } while (actual != carros);
}

