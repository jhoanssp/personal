/**********************
*                Universidad de las Fuerzas Armadas - ESPE
*                    Proyecto Final Primer Parcial
*
*Autores:    Samantha Martinez
*            Jhoan Salazar
*            Alexander Diaz
*
*Fecha de creacion: 2024-06-15
*Fecha de modificacion: 2024-06-25
*Nivel: Tercero                                 NRC: 16426
*
***********************/

#ifndef FECHA_H
#define FECHA_H

#include <string>

class Fecha {
private:
    int dia;
    int mes;
    int anio;

    bool esBisiesto(int anio) const;

public:
    Fecha();
    Fecha(int d, int m, int a);

    bool esValida() const;
    std::string toString() const;
    bool operator==(const Fecha& otra) const;

    static Fecha fromString(const std::string& fechaStr);
    static Fecha fechaActual();
};

#endif




