
/**********************
*                Universidad de las Fuerzas Armadas - ESPE
*                    Proyecto Final Primer Parcial
*
*Autores:    Samantha Martinez
*            Jhoan Salazar
*            Alexander Diaz
*
*Fecha de creacion: 2024-06-15
*Fecha de modificacion: 2024-06-25
*Nivel: Tercero                                 NRC: 16426
*
***********************/
#ifndef REGISTROCARRO_H
#define REGISTROCARRO_H

#include <string>
#include <unordered_map>//Referencia de API para la clase de contenedor de la biblioteca estándar de C++
#include "Usuario.h"
#include "Fecha.h"
#include "NodoUsuario.h"

class RegistroCarro {
public:
    NodoUsuario* usuarios;
    std::string filename;
    std::unordered_map<std::string, int> placa;
    std::unordered_map<std::string, int> correosExistentes;

    void inicializarUltimasPlacas();
    Usuario* buscarUsuario(const std::string& cedula);

public:
    RegistroCarro(const std::string& filename);
    ~RegistroCarro();

    void insertarUsuario(const Usuario& usuario);
    void mostrar();
    void buscarPorCedula(const std::string& cedula);
    void buscarPorFecha(const Fecha& fecha);
    void guardarDatos();
    void cargarDatos();
    std::string generarPlaca(const std::string& provincia);
    bool cedulaExiste(const std::string& cedula);
};

#endif



