/**********************
*                Universidad de las Fuerzas Armadas - ESPE
*                    Proyecto Final Primer Parcial
*
*Autores:    Samantha Martinez
*            Jhoan Salazar
*            Alexander Diaz
*
*Fecha de creacion: 2024-06-15
*Fecha de modificacion: 2024-06-25
*Nivel: Tercero                                 NRC: 16426
*
***********************/

#include <iostream>
#include <string>
#include <cctype>
#include <limits>//Contiene parámetros de entorno, información sobre limitaciones y rangos para tipos enteros.
#include "RegistroCarro.h"

bool esAlfa(const std::string& str) {
    for (char c : str) {
        if (!std::isalpha(c)) return false;
    }
    return true;
}

bool validarProvincia(const std::string& provincia) {
    return provincia.length() == 1 && 
           (provincia == "A" || provincia == "B" || provincia == "U" || provincia == "C" || provincia == "X" ||
            provincia == "H" || provincia == "O" || provincia == "E" || provincia == "W" || provincia == "G" ||
            provincia == "I" || provincia == "L" || provincia == "R" || provincia == "M" || provincia == "V" ||
            provincia == "N" || provincia == "S" || provincia == "P" || provincia == "Q" || provincia == "K" ||
            provincia == "T" || provincia == "Z" || provincia == "Y" || provincia == "J");
}

bool validarCedula(const std::string& cedula) {
    if (cedula.length() != 10) {
        return false;
    }
    for (char c : cedula) {
        if (!std::isdigit(c)) {
            return false;
        }
    }
    return true;
}

int obtenerOpcionMenu() {
    int opcion;
    while (true) {
        std::cout << "Seleccione una opción: ";
        std::cin >> opcion;
        if (std::cin.fail() || opcion < 1 || opcion > 7) {
            std::cin.clear(); // Clear the error flag
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Discard invalid input
            std::cout << "Opción no válida. Por favor, intente de nuevo.\n";
        } else {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Discard remaining input
            return opcion;
        }
    }
}

std::string obtenerCedula() {
    std::string cedula;
    while (true) {
        std::cout << "Ingrese la cédula: ";
        std::cin >> cedula;
        if (validarCedula(cedula)) {
            return cedula;
        } else {
            std::cout << "La cédula debe contener solo números y tener exactamente 10 dígitos.\n";
        }
    }
}

std::string obtenerNombre(const std::string& prompt) {
    std::string nombre;
    while (true) {
        std::cout << prompt;
        std::cin >> nombre;
        if (esAlfa(nombre)) {
            return nombre;
        } else {
            std::cout << "El nombre debe contener solo letras.\n";
        }
    }
}

std::string obtenerProvincia() {
    std::string provincia;
    while (true) {
        std::cout << "Ingrese la provincia del usuario: \n";
       
            std::cout << "(A – Azuay, B – Bolívar, U – Cañar, C – Carchi, X – Cotopaxi)\n";
            std::cout << "(H – Chimborazo, O – El Oro, E – Esmeraldas, W – Galápagos, G – Guayas)\n";
            std::cout << "(I – Imbabura, L – Loja, R – Los Ríos, M – Manabí, V – Morona Santiago)\n";
            std::cout << "(N – Napo, S – Pastaza, P – Pichincha, Q – Orellana, K – Sucumbíos)\n";
            std::cout << "(T – Tungurahua, Z – Zamora Chinchipe, Y – Santa Elena, J – Santo Domingo)\n";
            std::cout<<"Provincia: ";
            
        std::cin >> provincia;
        if (validarProvincia(provincia)) {
            return provincia;
        } else {
            std::cout << "Provincia no válida. Debe ser una de las siguientes letras:\n";
            std::cout << "(A – Azuay, B – Bolívar, U – Cañar, C – Carchi, X – Cotopaxi)\n";
            std::cout << "(H – Chimborazo, O – El Oro, E – Esmeraldas, W – Galápagos, G – Guayas)\n";
            std::cout << "(I – Imbabura, L – Loja, R – Los Ríos, M – Manabí, V – Morona Santiago)\n";
            std::cout << "(N – Napo, S – Pastaza, P – Pichincha, Q – Orellana, K – Sucumbíos)\n";
            std::cout << "(T – Tungurahua, Z – Zamora Chinchipe, Y – Santa Elena, J – Santo Domingo)\n";
        }
    }
}

bool validarTipo(const std::string& tipo) {
    return tipo.length() == 1 && (tipo == "A" || tipo == "M"|| tipo=="C");
}

std::string obtenerTipo() {
    std::string tipo;
    while (true) {
        std::cout << "Ingrese el tipo de carro (A – Automóvil, M – Motocicleta,C-Camion): ";
        std::cin >> tipo;
        if (validarTipo(tipo)) {
            return tipo;
        } else {
            std::cout << "Tipo no válido. Debe ser 'A' para Automóvil ,'M' para Motocicleta o 'C' para Camion.\n";
        }
    }
}

void obtenerFecha(int &dia, int &mes, int &anio) {
    while (true) {
        std::cout << "Ingrese la fecha (dd mm aaaa): ";
        std::cin >> dia >> mes >> anio;
        if (std::cin.fail() || dia < 1 || dia > 31 || mes < 1 || mes > 12 || anio < 1900 || anio > 2100) {
            std::cin.clear(); // Clear the error flag
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Discard invalid input
            std::cout << "Fecha no válida. Por favor, intente de nuevo.\n";
        } else {
            return;
        }
    }
}

int main() {
    RegistroCarro registro("registros.txt");
    int opcion;

    do {
        std::cout<<"****************BIENVENIDO********************\n";
        std::cout << "\nMenú:\n";
        std::cout << "1. Registrar usuario\n";
        std::cout << "2. Registrar carro\n";
        std::cout << "3. Eliminar carro\n";
        std::cout << "4. Buscar carros por cédula\n";
        std::cout << "5. Buscar carros por fecha\n";
        std::cout << "6. Mostrar todos los registros\n";
        std::cout << "7. Salir\n";
        
        opcion = obtenerOpcionMenu();

        if (opcion == 1) {
            std::string cedula = obtenerCedula();
            
            if (registro.cedulaExiste(cedula)) {
                std::cout << "La cédula ya está registrada.\n";
                continue;
            }

            std::string nombre = obtenerNombre("Ingrese el nombre: ");
            std::string segundoNombre;
            std::cout << "Ingrese el segundo nombre (opcional): ";
            std::cin.ignore();
            std::getline(std::cin, segundoNombre);
            if (!segundoNombre.empty() && !esAlfa(segundoNombre)) {
                std::cout << "El segundo nombre debe contener solo letras.\n";
                continue;
            }
            std::string apellido = obtenerNombre("Ingrese el apellido: ");
            std::string provincia = obtenerProvincia();

            Usuario nuevoUsuario(nombre, segundoNombre, apellido, cedula, provincia, registro.correosExistentes);
            registro.insertarUsuario(nuevoUsuario);
            registro.guardarDatos();
            std::cout << "Usuario registrado exitosamente.\n";
        } else if (opcion == 2) {
            std::string cedula = obtenerCedula();

            Usuario* usuario = registro.buscarUsuario(cedula);
            if (!usuario) {
                std::cout << "No se encontró el usuario con cédula: " << cedula << "\n";
                continue;
            }

            std::string modelo, marca, tipo;
            std::cout << "Ingrese el modelo del carro: ";
            std::cin.ignore();
            std::getline(std::cin, modelo);
            if (!esAlfa(modelo)) {
                std::cout << "El modelo debe contener solo letras.\n";
                continue;
            }

            std::cout << "Ingrese la marca del carro: ";
            std::getline(std::cin, marca);
            if (!esAlfa(marca)) {
                std::cout << "La marca debe contener solo letras.\n";
                continue;
            }

            tipo=obtenerTipo();

            std::string placa = registro.generarPlaca(usuario->getProvincia());
            Carro nuevoCarro(placa, modelo, marca, tipo, Fecha::fechaActual());
            usuario->agregarCarro(nuevoCarro);
            registro.guardarDatos();
            std::cout << "Carro registrado exitosamente.\n";
        } else if (opcion == 3) {
            std::string cedula = obtenerCedula();

            Usuario* usuario = registro.buscarUsuario(cedula);
            if (!usuario) {
                std::cout << "No se encontró el usuario con cédula: " << cedula << "\n";
                continue;
            }

            std::string placa;
            std::cout << "Ingrese la placa del carro a eliminar: ";
            std::cin >> placa;

            usuario->eliminarCarro(placa);
            registro.guardarDatos();
            std::cout << "Carro eliminado o no encontrado.\n";
        } else if (opcion == 4) {
            std::string cedula = obtenerCedula();
            registro.buscarPorCedula(cedula);
        } else if (opcion == 5) {
            int dia, mes, anio;
            obtenerFecha(dia, mes, anio);
            Fecha fechaBusqueda(dia, mes, anio);

            if (!fechaBusqueda.esValida()) {
                std::cout << "Fecha no válida.\n";
                continue;
            }

            registro.buscarPorFecha(fechaBusqueda);
        } else if (opcion == 6) {
            registro.mostrar();
        }
    } while (opcion != 7);

    return 0;
}
