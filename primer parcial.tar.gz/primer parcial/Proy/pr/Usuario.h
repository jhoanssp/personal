
/**********************
*                Universidad de las Fuerzas Armadas - ESPE
*                    Proyecto Final Primer Parcial
*
*Autores:    Samantha Martinez
*            Jhoan Salazar
*            Alexander Diaz
*
*Fecha de creacion: 2024-06-15
*Fecha de modificacion: 2024-06-25
*Nivel: Tercero                                 NRC: 16426
*
***********************/
#ifndef USUARIO_H
#define USUARIO_H

#include <string>
#include <unordered_map>//Referencia de API para la clase de contenedor de la biblioteca estándar de C++
#include "NodoCarro.h"

class Usuario {
private:
    std::string nombre;
    std::string segundoNombre;
    std::string apellido;
    std::string cedula;
    std::string provincia;
    std::string correo;
    std::string contrasena;
    NodoCarro* carros;

    std::string generarCorreo(std::unordered_map<std::string, int>& correosExistentes);
    std::string generarContrasena();

public:
    Usuario(const std::string& n, const std::string& sn, const std::string& a, const std::string& c, const std::string& p, std::unordered_map<std::string, int>& correosExistentes);

    std::string getNombre() const { return nombre; }
    std::string getSegundoNombre() const { return segundoNombre; }
    std::string getApellido() const { return apellido; }
    std::string getCedula() const { return cedula; }
    std::string getProvincia() const { return provincia; }
    std::string getCorreo() const { return correo; }
    std::string getContrasena() const { return contrasena; }
    NodoCarro* getCarros() const { return carros; }

    void agregarCarro(const Carro& carro);
    void eliminarCarro(const std::string& placa);
    
};

#endif


