/**********************
*                Universidad de las Fuerzas Armadas - ESPE
*                    Proyecto Final Primer Parcial
*
*Autores:    Samantha Martinez
*            Jhoan Salazar
*            Alexander Diaz
*
*Fecha de creacion: 2024-06-15
*Fecha de modificacion: 2024-06-25
*Nivel: Tercero                                 NRC: 16426
*
***********************/


#include "Carro.h"

Carro::Carro(const std::string& p, const std::string& m, const std::string& ma,const std::string& t, const Fecha& f)
    : placa(p), modelo(m), marca(ma),tipo(t), fechaCreacion(f) {}

std::string Carro::getPlaca() const {
    return placa;
}

std::string Carro::getModelo() const {
    return modelo;
}

std::string Carro::getMarca() const {
    return marca;
}
std::string Carro::getTipo() const {

    return tipo;
}

Fecha Carro::getFechaCreacion() const {
    return fechaCreacion;
}

void Carro::setPlaca(const std::string& p) {
    placa = p;
}

void Carro::setTipo(const std::string& t) {
    tipo = t;
}