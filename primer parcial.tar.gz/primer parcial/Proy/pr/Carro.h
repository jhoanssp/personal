/**********************
*                Universidad de las Fuerzas Armadas - ESPE
*                    Proyecto Final Primer Parcial
*
*Autores:    Samantha Martinez
*            Jhoan Salazar
*            Alexander Diaz
*
*Fecha de creacion: 2024-06-15
*Fecha de modificacion: 2024-06-25
*Nivel: Tercero                                 NRC: 16426
*
***********************/
#ifndef CARRO_H
#define CARRO_H

#include <string>
#include "Fecha.h"

class Carro {
private:
    std::string placa;
    std::string modelo;
    std::string marca;
    std::string tipo;
    Fecha fechaCreacion;

public:
    Carro(const std::string& p, const std::string& m, const std::string& ma,const std::string& t,const Fecha& f);

    std::string getPlaca() const;
    std::string getModelo() const;
    std::string getMarca() const;
    std::string getTipo() const;
    Fecha getFechaCreacion() const;

    void setPlaca(const std::string& p);
    void serColor(const std::string& c);
    void setTipo(const std::string& t);
};

#endif









