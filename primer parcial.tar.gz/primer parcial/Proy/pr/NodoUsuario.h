/**********************
*                Universidad de las Fuerzas Armadas - ESPE
*                    Proyecto Final Primer Parcial
*
*Autores:    Samantha Martinez
*            Jhoan Salazar
*            Alexander Diaz
*
*Fecha de creacion: 2024-06-15
*Fecha de modificacion: 2024-06-25
*Nivel: Tercero                                 NRC: 16426
*
***********************/
#ifndef NODOUSUARIO_H
#define NODOUSUARIO_H

#include "Usuario.h"

class NodoUsuario {
public:
    Usuario usuario;
    NodoUsuario* siguiente;
    NodoUsuario* anterior;

    NodoUsuario(const Usuario& usuario)
        : usuario(usuario), siguiente(nullptr), anterior(nullptr) {}
};

#endif
