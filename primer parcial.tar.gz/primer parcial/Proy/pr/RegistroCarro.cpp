/**********************
*                Universidad de las Fuerzas Armadas - ESPE
*                    Proyecto Final Primer Parcial
*
*Autores:    Samantha Martinez
*            Jhoan Salazar
*            Alexander Diaz
*
*Fecha de creacion: 2024-06-15
*Fecha de modificacion: 2024-06-25
*Nivel: Tercero                                 NRC: 16426
*
***********************/
#include "RegistroCarro.h"
#include <iostream>
#include <fstream>//ifstream ( input file stream), clase orientada para la lectura · ofstream (output file stream). clase orientada para la escritura
#include <sstream>//define un tipo llamado stringstream que nos permite tratar un string como un stream,
#include <algorithm>//Define las funciones de plantilla contenedor de la biblioteca estándar de C++ que realizan algoritmos

RegistroCarro::RegistroCarro(const std::string& filename) : usuarios(nullptr), filename(filename) {
    cargarDatos();
    inicializarUltimasPlacas();
}

RegistroCarro::~RegistroCarro() {
    NodoUsuario* actual = usuarios;
    if (actual) {
        do {
            NodoUsuario* siguiente = actual->siguiente;
            delete actual;
            actual = siguiente;
        } while (actual != usuarios);
    }
}

Usuario* RegistroCarro::buscarUsuario(const std::string& cedula) {
    if (!usuarios) return nullptr;

    NodoUsuario* actual = usuarios;
    do {
        if (actual->usuario.getCedula() == cedula) {
            return &actual->usuario;
        }
        actual = actual->siguiente;
    } while (actual != usuarios);

    return nullptr;
}

void RegistroCarro::insertarUsuario(const Usuario& usuario) {
    NodoUsuario* nuevo = new NodoUsuario(usuario);
    if (!usuarios) {
        usuarios = nuevo;
        usuarios->siguiente = usuarios;
        usuarios->anterior = usuarios;
    } else {
        NodoUsuario* ultimo = usuarios->anterior;
        ultimo->siguiente = nuevo;
        nuevo->anterior = ultimo;
        nuevo->siguiente = usuarios;
        usuarios->anterior = nuevo;
    }
    correosExistentes[usuario.getCorreo()] = 1;
}

void RegistroCarro::mostrar() {
    if (!usuarios) {
        std::cout << "No hay registros.\n";
        return;
    }

    NodoUsuario* actual = usuarios;
    do {
        std::cout << "Usuario: " << actual->usuario.getNombre() << " " << actual->usuario.getSegundoNombre() << " " << actual->usuario.getApellido() << ", Cédula: " << actual->usuario.getCedula() << ", Provincia: " << actual->usuario.getProvincia() << ", Correo: " << actual->usuario.getCorreo() << ", Contraseña: " << actual->usuario.getContrasena() << "\n";
        NodoCarro* carroActual = actual->usuario.getCarros();
        if (carroActual) {
            do {
                std::cout << "   Carro: Placa: " << carroActual->carro.getPlaca() << ", Modelo: " << carroActual->carro.getModelo() << ", Marca: " << carroActual->carro.getMarca() << ", Tipo: " << carroActual->carro.getTipo() << ", Fecha Creación: " << carroActual->carro.getFechaCreacion().toString() << "\n";
                carroActual = carroActual->siguiente;
            } while (carroActual != actual->usuario.getCarros());
        }
        actual = actual->siguiente;
    } while (actual != usuarios);
}

void RegistroCarro::buscarPorCedula(const std::string& cedula) {
    Usuario* usuario = buscarUsuario(cedula);
    if (!usuario) {
        std::cout << "No se encontró el usuario con cédula: " << cedula << "\n";
        return;
    }

    std::cout << "Usuario: " << usuario->getNombre() << " " << usuario->getSegundoNombre() << " " << usuario->getApellido() << ", Cédula: " << usuario->getCedula() << ", Correo: " << usuario->getCorreo() << ", Contraseña: " << usuario->getContrasena() << "\n";
    NodoCarro* carroActual = usuario->getCarros();
    if (carroActual) {
        do {
            std::cout << "   Carro: Placa: " << carroActual->carro.getPlaca() << ", Modelo: " << carroActual->carro.getModelo() << ", Marca: " << carroActual->carro.getMarca() << ", Fecha Creación: " << carroActual->carro.getFechaCreacion().toString() << "\n";
            carroActual = carroActual->siguiente;
        } while (carroActual != usuario->getCarros());
    }
}

void RegistroCarro::buscarPorFecha(const Fecha& fecha) {
    if (!usuarios) {
        std::cout << "No hay registros.\n";
        return;
    }

    NodoUsuario* actual = usuarios;
    bool encontrado = false;
    do {
        NodoCarro* carroActual = actual->usuario.getCarros();
        if (carroActual) {
            do {
                if (carroActual->carro.getFechaCreacion() == fecha) {
                    std::cout << "Usuario: " << actual->usuario.getNombre() << " " << actual->usuario.getSegundoNombre() << " " << actual->usuario.getApellido() << ", Cédula: " << actual->usuario.getCedula() << ", Correo: " << actual->usuario.getCorreo() << ", Contraseña: " << actual->usuario.getContrasena() << "\n";
                    std::cout << "   Carro: Placa: " << carroActual->carro.getPlaca() << ", Modelo: " << carroActual->carro.getModelo() << ", Marca: " << carroActual->carro.getMarca() << ", Fecha Creación: " << carroActual->carro.getFechaCreacion().toString() << "\n";
                    encontrado = true;
                }
                carroActual = carroActual->siguiente;
            } while (carroActual != actual->usuario.getCarros());
        }
        actual = actual->siguiente;
    } while (actual != usuarios);

    if (!encontrado) {
        std::cout << "No se encontraron vehículos en la fecha especificada.\n";
    }
}

void RegistroCarro::guardarDatos() {
    std::ofstream archivo(filename);

    NodoUsuario* actual = usuarios;
    if (actual) {
        do {
            archivo << actual->usuario.getCedula() << "," << actual->usuario.getNombre() << "," << actual->usuario.getSegundoNombre() << "," << actual->usuario.getApellido() << "," << actual->usuario.getProvincia() << "," << actual->usuario.getCorreo() << "," << actual->usuario.getContrasena() << "\n";
            NodoCarro* carroActual = actual->usuario.getCarros();
            if (carroActual) {
                do {
                    archivo << "   " << carroActual->carro.getPlaca() << "," << carroActual->carro.getModelo() << "," << carroActual->carro.getMarca() << "," << carroActual->carro.getTipo() << "," << carroActual->carro.getFechaCreacion().toString() << "\n";
                    carroActual = carroActual->siguiente;
                } while (carroActual != actual->usuario.getCarros());
            }
            actual = actual->siguiente;
        } while (actual != usuarios);
    }

    archivo.close();
}

void RegistroCarro::cargarDatos() {
    std::ifstream archivo(filename);
    std::string linea;

    while (std::getline(archivo, linea)) {
        if (linea[0] != ' ') {
            std::istringstream iss(linea);
            std::string cedula, nombre, segundoNombre, apellido, provincia, correo, contrasena;

            std::getline(iss, cedula, ',');
            std::getline(iss, nombre, ',');
            std::getline(iss, segundoNombre, ',');
            std::getline(iss, apellido, ',');
            std::getline(iss, provincia, ',');
            std::getline(iss, correo, ',');
            std::getline(iss, contrasena, ',');

            Usuario usuario(nombre, segundoNombre, apellido, cedula, provincia, correosExistentes);
            insertarUsuario(usuario);
        } else {
            std::istringstream iss(linea);
            std::string placa, modelo, marca,tipo, fechaStr;

            iss.ignore(3);
            std::getline(iss, placa, ',');
            std::getline(iss, modelo, ',');
            std::getline(iss, marca, ',');
            std::getline(iss, tipo, ',');
            std::getline(iss, fechaStr, ',');

            Fecha fechaCreacion = Fecha::fromString(fechaStr);
            Carro carro(placa, modelo, marca,tipo, fechaCreacion);

            NodoUsuario* usuarioActual = usuarios->anterior;
            usuarioActual->usuario.agregarCarro(carro);
        }
    }

    archivo.close();
}

std::string RegistroCarro::generarPlaca(const std::string& provincia) {
    std::string seriePlaca = provincia + "AA";
    if (placa.find(provincia) == placa.end()) {
        placa[provincia] = 1;
    } else {
        placa[provincia]++;
    }

    std::string numeroPlaca = std::to_string(placa[provincia]);
    while (numeroPlaca.length() < 4) {
        numeroPlaca = "0" + numeroPlaca;
    }

    if (placa[provincia] > 9999) {
        char primeraLetra = seriePlaca[1];
        char segundaLetra = seriePlaca[2];
        if (segundaLetra < 'Z') {
            segundaLetra++;
        } else {
            segundaLetra = 'A';
            primeraLetra++;
        }
        seriePlaca = std::string(1, provincia[0]) + primeraLetra + segundaLetra;
        placa[provincia] = 1;
    }

    return seriePlaca + "-" + numeroPlaca;
}

bool RegistroCarro::cedulaExiste(const std::string& cedula) {
    return buscarUsuario(cedula) != nullptr;
}

void RegistroCarro::inicializarUltimasPlacas() {
    if (!usuarios) return;

    NodoUsuario* actual = usuarios;
    do {
        NodoCarro* carroActual = actual->usuario.getCarros();
        if (carroActual) {
            do {
                std::string placaActual = carroActual->carro.getPlaca();
                std::string provincia = placaActual.substr(0, 1);
                int numeroPlaca = std::stoi(placaActual.substr(4));
                if (placa.find(provincia) == placa.end() || placa[provincia] < numeroPlaca) {
                    placa[provincia] = numeroPlaca;
                }
                carroActual = carroActual->siguiente;
            } while (carroActual != actual->usuario.getCarros());
        }
        actual = actual->siguiente;
    } while (actual != usuarios);
}





