/**********************
*                Universidad de las Fuerzas Armadas - ESPE
*                    Proyecto Final Primer Parcial
*
*Autores:    Samantha Martinez
*            Jhoan Salazar
*            Alexander Diaz
*
*Fecha de creacion: 2024-06-15
*Fecha de modificacion: 2024-06-25
*Nivel: Tercero                                 NRC: 16426
*
***********************/

#include "Fecha.h"
#include <ctime>
#include <sstream>

Fecha::Fecha() : dia(1), mes(1), anio(2001) {}

Fecha::Fecha(int d, int m, int a) : dia(d), mes(m), anio(a) {}

bool Fecha::esBisiesto(int anio) const {
    return (anio % 4 == 0 && anio % 100 != 0) || (anio % 400 == 0);
}

bool Fecha::esValida() const {
    if (anio < 2001 || anio > Fecha::fechaActual().anio) return false;
    if (mes < 1 || mes > 12) return false;
    if (dia < 1) return false;

    int diasPorMes[] = { 31, esBisiesto(anio) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    if (dia > diasPorMes[mes - 1]) return false;

    return true;
}

std::string Fecha::toString() const {
    std::ostringstream oss;
    oss << (dia < 10 ? "0" : "") << dia << "/" << (mes < 10 ? "0" : "") << mes << "/" << anio;
    return oss.str();
}

bool Fecha::operator==(const Fecha& otra) const {
    return dia == otra.dia && mes == otra.mes && anio == otra.anio;
}

Fecha Fecha::fromString(const std::string& fechaStr) {
    int d, m, a;
    char sep;
    std::istringstream iss(fechaStr);
    iss >> d >> sep >> m >> sep >> a;
    return Fecha(d, m, a);
}

Fecha Fecha::fechaActual() {
    time_t t = time(nullptr);
    tm* timePtr = localtime(&t);
    return Fecha(timePtr->tm_mday, timePtr->tm_mon + 1, timePtr->tm_year + 1900);
}


