/**********************
*                Universidad de las Fuerzas Armadas - ESPE
*                    Proyecto Final Primer Parcial
*
*Autores:    Samantha Martinez
*            Jhoan Salazar
*            Alexander Diaz
*
*Fecha de creacion: 2024-06-15
*Fecha de modificacion: 2024-06-25
*Nivel: Tercero                                 NRC: 16426
*
***********************/
#ifndef NODOCARRO_H
#define NODOCARRO_H

#include "Carro.h"

class NodoCarro {
public:
    Carro carro;
    NodoCarro* siguiente;
    NodoCarro* anterior;

    NodoCarro(const Carro& carro)
        : carro(carro), siguiente(nullptr), anterior(nullptr) {}
};

#endif
