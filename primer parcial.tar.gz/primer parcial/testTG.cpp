
#include <iostream>
#include <sstream>
#include <algorithm>
#include <map>
#include <vector>
#include <fstream>
#include <set>
#include <cctype>
#include <unistd.h>

using namespace std;

class Nodo {
public:
    string dato;
    Nodo* siguiente;
    Nodo* anterior;

    Nodo(string dato) {
        this->dato = dato;
        this->siguiente = nullptr;
        this->anterior = nullptr;
    }
};

class ListaDoblementeEnlazada {
private:
    Nodo* cabeza;
    Nodo* cola;

public:
    ListaDoblementeEnlazada() {
        cabeza = nullptr;
        cola = nullptr;
    }

    void agregarAlFinal(string dato) {
        Nodo* nuevoNodo = new Nodo(dato);
        if (!cabeza) {
            cabeza = nuevoNodo;
            cola = nuevoNodo;
            return;
        }
        cola->siguiente = nuevoNodo;
        nuevoNodo->anterior = cola;
        cola = nuevoNodo;
    }

    void imprimirLista() {
        Nodo* temp = cabeza;
        while (temp) {
            cout << temp->dato << " ";
            temp = temp->siguiente;
        }
        cout << endl;
    }

    string generarCorreo(map<string, int>& correosExistentes) {
        if (!cabeza || !cabeza->siguiente || !cabeza->siguiente->siguiente) {
            return "Entrada inválida.";
        }

        string correoBase;
        correoBase += tolower(cabeza->dato[0]); // Primera letra del primer nombre
        correoBase += tolower(cabeza->siguiente->dato[0]); // Primera letra del segundo nombre
        
        // Convertir el apellido a minúsculas
        string apellido = cabeza->siguiente->siguiente->dato;
        transform(apellido.begin(), apellido.end(), apellido.begin(), ::tolower);

        correoBase += apellido; // Apellido en minúsculas

        // Generar un correo único con números incrementales
        string correo = correoBase;
        if (correosExistentes[correoBase] > 0) {
            correo += to_string(correosExistentes[correoBase]);
        }
        correosExistentes[correoBase]++;
        correo += "@";

        return correo;
    }
};

void cargarCorreosExistente(string filePath, map<string, int>& correosExistentes, set<string>& cedulasExistentes) {
    ifstream archivo(filePath);
    if (archivo.is_open()) {
        string linea;
        while (getline(archivo, linea)) {
            string nombre, cedula, correo;
            
            // Leer el nombre
            getline(archivo, nombre);
            
            // Leer la cédula
            getline(archivo, cedula);
            cedulasExistentes.insert(cedula);

            // Leer el correo
            getline(archivo, correo);
            
            // Verificar y procesar el correo para manejar los números al final
            size_t atPos = correo.find('@');
            if (atPos != string::npos) {
                string correoBase = correo.substr(0, atPos);
                size_t numPos = correoBase.find_last_not_of("0123456789");

                if (numPos != string::npos) {
                    string base = correoBase.substr(0, numPos + 1);
                    string numStr = correoBase.substr(numPos + 1);
                    int num = numStr.empty() ? 0 : stoi(numStr);
                    correosExistentes[base] = max(correosExistentes[base], num + 1);
                }
            }
        }
        archivo.close();
    } else {
        cout << "No se pudo abrir el archivo para leer." << endl;
    }
}

void guardarCorreos(string filePath, const vector<string>& nombresIngresados, const vector<string>& cedulasIngresadas, const vector<string>& correosGenerados) {
    ofstream archivo(filePath, ios::app); // Modo de apertura para agregar al final
    if (archivo.is_open()) {
        for (size_t i = 0; i < correosGenerados.size(); ++i) {
            archivo << nombresIngresados[i] << endl;
            archivo << cedulasIngresadas[i] << endl;
            archivo << correosGenerados[i] << endl;
        }
        archivo.close();
        cout << "Los datos han sido guardados y actualizados en '" << filePath << "'." << endl;
    } else {
        cout << "No se pudo abrir el archivo para escribir." << endl;
    }
}

bool validarCedula(const string& cedula) {
    return cedula.length() == 10 && all_of(cedula.begin(), cedula.end(), ::isdigit);
}

int main() {
    ListaDoblementeEnlazada lista;
    map<string, int> correosExistentes;
    set<string> cedulasExistentes;
    vector<string> correosGenerados;
    vector<string> nombresIngresados;
    vector<string> cedulasIngresadas;

    string homePath = getenv("HOME"); // Obtener el directorio home del usuario
    string filePath = homePath + "/Downloads/correosTG.txt";
    
    cargarCorreosExistente(filePath, correosExistentes, cedulasExistentes); // Cargar correos y cédulas existentes del archivo

    string nombreCompleto;
    string cedula;
    char continuar;

    do {
        cout << "¿Desea ingresar otro usuario? (s/n): ";
        cin >> continuar;
        cin.ignore(); // Limpiar el buffer de entrada

        continuar = tolower(continuar); // Convertir a minúscula

        while (continuar != 's' && continuar != 'n') {
            cout << "Por favor, ingrese 's' para sí o 'n' para no: ";
            cin >> continuar;
            cin.ignore(); // Limpiar el buffer de entrada
            continuar = tolower(continuar); // Convertir a minúscula
        }

        if (continuar == 's') {
            cout << "Ingrese nombres y apellidos separados por espacios: ";
            getline(cin, nombreCompleto);

            cout << "Ingrese la cédula (exactamente 10 dígitos): ";
            getline(cin, cedula);

            while (!validarCedula(cedula)) {
                if (cedulasExistentes.count(cedula)) {
                    cout << "La cédula ya existe. No se puede crear un nuevo usuario con esta cédula." << endl;
                    cout << "Ingrese la cédula (exactamente 10 dígitos): ";
                } else {
                    cout << "La cédula debe contener exactamente 10 números. Ingrese nuevamente la cédula: ";
                }
                getline(cin, cedula);
            }

            if (cedulasExistentes.count(cedula)) {
                cout << "La cédula ya existe. No se puede crear un nuevo usuario con esta cédula." << endl;
                continue;
            }

            stringstream ss(nombreCompleto);
            string palabra;
            while (ss >> palabra) {
                lista.agregarAlFinal(palabra);
            }

            cout << "Lista de nombres y apellidos: ";
            lista.imprimirLista();

            string correo = lista.generarCorreo(correosExistentes);
            correosGenerados.push_back(correo);
            nombresIngresados.push_back(nombreCompleto);
            cedulasIngresadas.push_back(cedula);
            cout << "Correo generado: " << correo << endl;

            // Añadir la cédula al conjunto de cédulas existentes
            cedulasExistentes.insert(cedula);

            // Limpiar la lista para el próximo usuario
            lista = ListaDoblementeEnlazada();
        }
    } while (continuar == 's');

    guardarCorreos(filePath, nombresIngresados, cedulasIngresadas, correosGenerados); // Guardar y actualizar correos en el archivo

    return 0;
}
