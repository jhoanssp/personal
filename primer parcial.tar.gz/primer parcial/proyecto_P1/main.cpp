
#include <iostream>
#include <algorithm>
#include <cctype>
#include <string>
#include "RegistroCarro.h"
#include "Fecha.h"
#include "Usuario.h"
#include "Carro.h"


// Funciones de validación
bool validarCedula(const std::string& cedula);
bool validarProvincia(const std::string& provincia);
bool validarTipo(const std::string& marca);
//bool validarChasis(const std::string& chasis);
bool validarAnio(const std::string& anio);
//bool validarCilindraje(const std::string& cilindraje_str);
bool validarTexto(const std::string& texto);
Fecha solicitarFecha();

// Main
int main() {
    RegistroCarro registro("/home/kali/Downloads/proyecto_P1/registro.txt");
    Fecha fechaActual = solicitarFecha();

    int opcion;
    do {
        std::cout << "1. Registrar usuario\n"
                  << "2. Agregar carro\n"
                  << "3. Eliminar carro\n"
                  << "4. Buscar carros por cédula\n"
                  << "5. Buscar carros por fecha\n"
                  << "6. Mostrar todos los registros\n"
                  << "7. Salir\n"
                  << "Seleccione una opción: ";
        std::cin >> opcion;
        std::cin.ignore();

        if (opcion == 1) {
            std::string nombre,segundonombre,apellido,cedula, provincia;

            
            do {
                std::cout << "Ingrese el nombre del usuario: ";
                std::getline(std::cin, nombre);
                if (!validarTexto(nombre)) {
                    std::cout << "Nombre inválido. Debe contener solo letras y no estar vacío.\n";
                }
            } while (!validarTexto(nombre));
            do {
                std::cout << "Ingrese el segundo nombre del usuario: ";
                std::getline(std::cin, segundonombre);
                if (!validarTexto(segundonombre)) {
                    std::cout << "Nombre inválido. Debe contener solo letras y no estar vacío.\n";
                }
            } while (!validarTexto(segundonombre));
            do {
                std::cout << "Ingrese el apellido del usuario: ";
                std::getline(std::cin, apellido);
                if (!validarTexto(apellido)) {
                    std::cout << "Apellido inválido. Debe contener solo letras y no estar vacío.\n";
                }
            } while (!validarTexto(apellido));
            do {
                std::cout << "Ingrese la cédula del usuario: ";
                std::getline(std::cin, cedula);
                if (!validarCedula(cedula)) {
                    std::cout << "Cédula inválida. Debe tener exactamente 10 dígitos.\n";
                } else if (registro.buscarUsuario(cedula)) {
                    std::cout << "La cédula ya está registrada. Ingrese una cédula diferente.\n";
                }
            } while (!validarCedula(cedula) || registro.buscarUsuario(cedula));

            
            do {
                std::cout << "Provincia del usuario : "<<"\n"<<"(A – Azuay, B – Bolívar, U – Cañar, C – Carchi, X – Cotopaxi)"<<"\n"
                <<"(H – Chimborazo, O – El Oro, E – Esmeraldas, W – Galapagos, G – Guayas)"<<"\n"<<"(I – Imbabura, L – Loja, R – Los Rios, M – Manabi, V – Morona Santiago)"<<"\n"
                <<"(N – Napo, S – Pastaza, P – Pichincha, Q – Orellana, K – Sucumbios)"<<"\n"<<"(T – Tungurahua, Z – Zamora Chinchipe, Y – Santa Elena, J – Santo Domingo)"<<"\n";
                std::cout << "Ingrese la provincia del usuario : ";

                std::getline(std::cin, provincia);
                if (!validarProvincia(provincia)) {
                    std::cout << "Provincia inválida. Debe ser una de las especificadas.\n";
                }
            } while (!validarProvincia(provincia));

            Usuario usuario(nombre,segundonombre,apellido,cedula, provincia);
            registro.insertarUsuario(usuario);

        } else if (opcion == 2) {
            std::string cedula, modelo, marca,color,tipo, anio;
            float cilindraje;

            std::cout << "Ingrese la cédula del usuario: ";
            std::cin >> cedula;
            Usuario* usuario = registro.buscarUsuario(cedula);

            if (usuario) {
                std::cin.ignore();


                do {
                    std::cout << "Ingrese el modelo del carro: ";
                    std::getline(std::cin, modelo);
                    if (!validarTexto(modelo)) {
                        std::cout << "Modelo inválido. Debe contener solo letras y no estar vacío.\n";
                    }
                } while (!validarTexto(modelo));

                do {
                    std::cout << "Ingrese la marca del carro: ";
                    std::getline(std::cin, marca);
                    if (!validarTexto(marca)) {
                        std::cout << "Marca inválida. Debe contener solo letras y no estar vacío.\n";
                    }
                } while (!validarTexto(marca));
                do {
                    std::cout << "Ingrese el color del carro: ";
                    std::getline(std::cin, color);
                    if (!validarTexto(color)) {
                        std::cout << "Color inválida. Debe contener solo letras y no estar vacío.\n";
                    }
                } while (!validarTexto(color));

                do {
                    std::cout << "Ingrese el año del carro: ";
                    
                    std::getline(std::cin, anio);
                
                    if (!validarAnio(anio)) {
                        std::cout << "Año inválido. Debe tener exactamente 4 dígitos.\n";
                    }
                } while (!validarAnio(anio));

                            do {
                std::cout << "Provincia del usuario : "<<"\n"<<"(A – Auto, C – Camion, M – Moto)"<<"\n";
                std::cout << "Ingrese la provincia del usuario : ";

                std::getline(std::cin, tipo);
                if (!validarTipo(tipo)) {
                    std::cout << "Tipo inválida. Debe ser una de las especificadas.\n";
                }
            } while (!validarTipo(tipo));


                std::string placa = registro.generarPlaca(usuario->provincia);
                Fecha fechaActual = solicitarFecha();
                Carro carro(placa, modelo, marca,color,tipo, std::stoi(anio), fechaActual);
                registro.insertarCarro(cedula, carro);

            } else {
                std::cout << "Usuario no encontrado.\n";
                
            }

        } else if (opcion == 3) {
            std::string cedula, placa;
            std::cout << "Ingrese la cédula del usuario: ";
            std::cin >> cedula;
            Usuario* usuario = registro.buscarUsuario(cedula);

            if (usuario) {
                std::cout << "Ingrese la placa del carro a eliminar: ";
                std::cin >> placa;
                registro.eliminarCarro(cedula, placa);
            } else {
                std::cout << "Usuario no encontrado.\n";
            }

        } else if (opcion == 4) {
            std::string cedula;
            std::cout << "Ingrese la cédula del usuario: ";
            std::cin >> cedula;
            Usuario* usuario = registro.buscarUsuario(cedula);

            if (usuario) {
                std::cout << "Usuario: " << usuario->nombre << ", Cédula: " << usuario->cedula
                          << ", Provincia: " << usuario->provincia << "\n";
                NodoCarro* actualCarro = usuario->listaCarros;
                if (actualCarro) {
                    do {
                        std::cout << "  Carro: " << actualCarro->carro.modelo << ", Placa: " << actualCarro->carro.placa
                                  << ", Color: " << actualCarro->carro.color << ", Marca: "
                                  << actualCarro->carro.marca << ", Año: " << actualCarro->carro.anio
                                  << ", Fecha: " << actualCarro->carro.fecha.toString() << "\n";
                        actualCarro = actualCarro->siguiente;
                    } while (actualCarro != usuario->listaCarros);
                }
            } else {
                std::cout << "Usuario no encontrado.\n";
            }

        } else if (opcion == 5) {
            int dia, mes, anio;
            std::cout << "Ingrese la fecha (dd mm aaaa): ";
            std::cin >> dia >> mes >> anio;
            if (!Fecha::validarFecha(dia, mes, anio)) {
                std::cout << "Fecha inválida.\n";
            } else {
                Fecha fechaBusqueda(dia, mes, anio);
                registro.buscarPorFecha(fechaBusqueda);
            }
        } else if (opcion == 6) {
            registro.mostrar();
        }

    } while (opcion != 7);

    return 0;
}

// Funciones de validación y solicitud de fecha
bool validarCedula(const std::string& cedula) {
    if (cedula.length() != 10) return false;
    return std::all_of(cedula.begin(), cedula.end(), ::isdigit);
}

bool validarProvincia(const std::string& provincia) {
    return provincia == "A" || provincia == "B" || provincia == "U" || provincia == "C" || provincia == "X" ||
    provincia == "H" || provincia == "O" || provincia == "E" || provincia == "W" || provincia == "G" ||
    provincia == "I" || provincia == "L" || provincia == "R" || provincia == "M" || provincia == "V"||
    provincia == "N" || provincia == "S" || provincia == "P" || provincia == "Q" || provincia == "K"||
    provincia == "T" || provincia == "Z" || provincia == "Y" || provincia == "J";

}

bool validarTipo(const std::string& tipo) {
    return tipo == "A" || tipo == "C" || tipo == "M" ;

}
bool validarAnio(const std::string& anio) {
    if (anio.length() != 4) return false;
    return std::all_of(anio.begin(), anio.end(), ::isdigit);
}



bool validarTexto(const std::string& texto) {
    if (texto.empty()) return false;
    return std::all_of(texto.begin(), texto.end(), [](char c) { return std::isalpha(c) || std::isspace(c); });
}

Fecha solicitarFecha() {
    int dia, mes, anio;
    Fecha fechaActual = Fecha::obtenerFechaActual();
    do {
        std::cout << "Ingrese la fecha actual (dd mm aaaa): ";
        std::cin >> dia >> mes >> anio;
        if (!Fecha::validarFecha(dia, mes, anio)) {
            std::cout << "Fecha inválida. Debe estar entre 01/01/2001 y "<< fechaActual.toString()<<".\n";
        }
    } while (!Fecha::validarFecha(dia, mes, anio));
    return Fecha(dia, mes, anio);
}

