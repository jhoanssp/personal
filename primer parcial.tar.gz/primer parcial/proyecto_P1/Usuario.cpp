
#include "Usuario.h"

Usuario::Usuario(const std::string& nombre, const std::string& segundonombre,const std::string& apellido,const std::string& cedula, const std::string& provincia,const std::string& correo,const std::string& contrasena)
    : nombre(nombre),cedula(cedula), provincia(provincia),correo(correo),contrasena(contrasena), listaCarros(nullptr) {}

void Usuario::agregarCarro(const Carro& carro) {
    NodoCarro* nuevo = new NodoCarro(carro);
    if (!listaCarros) {
        listaCarros = nuevo;
    } else {
        NodoCarro* ultimo = listaCarros->anterior;
        ultimo->siguiente = nuevo;
        nuevo->anterior = ultimo;
        nuevo->siguiente = listaCarros;
        listaCarros->anterior = nuevo;
    }
}




// Función para generar un correo único
void Usuario:: generarCorreo(map<string, int>& correosExistentes, const string& nombre, const string& segundonombre, const string& apellido) {
    string correoBase;
    correoBase += tolower(nombre[0]);
    if (!segundonombre.empty()) correoBase += tolower(segundonombre[0]);
    correoBase += apellido;

    if (correosExistentes[correoBase] > 0) {
        correoBase += to_string(correosExistentes[correoBase]);
    }
    correosExistentes[correoBase]++;

    return correoBase + "@espe.edu.ec";
}


void Usuario::eliminarCarro(const std::string& placa) {
    if (!listaCarros) return;
    NodoCarro* actual = listaCarros;
    do {
        if (actual->carro.placa == placa) {
            if (actual->siguiente == actual) {
                listaCarros = nullptr;
            } else {
                actual->anterior->siguiente = actual->siguiente;
                actual->siguiente->anterior = actual->anterior;
                if (actual == listaCarros) {
                    listaCarros = actual->siguiente;
                }
            }
            delete actual;
            return;
        }
        actual = actual->siguiente;
    } while (actual != listaCarros);
}

Carro* Usuario::buscarCarro(const std::string& placa) {
    if (!listaCarros) return nullptr;
    NodoCarro* actual = listaCarros;
    do {
        if (actual->carro.placa == placa) {
            return &actual->carro;
        }
        actual = actual->siguiente;
    } while (actual != listaCarros);
    return nullptr;
}

