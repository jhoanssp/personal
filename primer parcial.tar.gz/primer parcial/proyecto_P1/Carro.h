
#ifndef CARRO_H
#define CARRO_H

#include <string>
#include "Fecha.h"

class Carro {
public:
    Carro(const std::string& placa, const std::string& modelo, const std::string& marca,const std::string& color,const std::string& tipo, int anio, const Fecha& fecha);

    
    std::string placa;
    std::string modelo;
    std::string marca;
    std::string color;
    std::string tipo;

    int anio;
    Fecha fecha;

    std::string toString() const;
};

#endif // CARRO_H
