

#include "Fecha.h"
#include <sstream>
#include <iomanip>
#include<ctime>

Fecha::Fecha(int dia, int mes, int anio) : dia(dia), mes(mes), anio(anio) {}

int Fecha::getDia() const { return dia; }
int Fecha::getMes() const { return mes; }
int Fecha::getAnio() const { return anio; }

std::string Fecha::toString() const {
    std::ostringstream oss;
    oss << std::setw(2) << std::setfill('0') << dia << '/'
        << std::setw(2) << std::setfill('0') << mes << '/'
        << anio;
    return oss.str();
}

bool Fecha::validarFecha(int dia, int mes, int anio) {
    if (anio < 2001 || anio > 2024) return false;
    if (mes < 1 || mes > 12) return false;
    if (dia < 1 || dia > 31) return false;

    if((mes ==4 ||mes ==6 ||mes ==9 ||mes ==11 ) && dia > 30)return false;
    if (mes == 2){
    bool esBisiesto = (anio % 4 == 0 && anio % 100 != 0) || (anio % 400 == 0);
    if (dia > (esBisiesto ? 29 : 28)) return false;
    }
    

    Fecha fechaActual = obtenerFechaActual();
    if(anio > fechaActual.getAnio() ||
        (anio ==fechaActual.getAnio()  && mes > fechaActual.getMes()) ||
        (anio == fechaActual.getAnio() && mes == fechaActual.getMes() && dia > fechaActual.getDia())){

        return false;
    }
    return true;

}


Fecha Fecha :: obtenerFechaActual(){

    std:: time_t t = std :: time(nullptr);
    std:: tm* ahora = std::localtime(&t);

    int dia = ahora->tm_mday;
    int mes = ahora-> tm_mon +1;
    int anio = ahora->tm_year + 1900;

    return Fecha(dia,mes,anio);
}