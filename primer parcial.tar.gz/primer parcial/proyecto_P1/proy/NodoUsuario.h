
#ifndef NODOUSUARIO_H
#define NODOUSUARIO_H

#include "Usuario.h"

// Estructura del nodo para la lista circular doble de usuarios
struct NodoUsuario {
    Usuario usuario;  // Datos del usuario
    NodoUsuario* siguiente;  // Puntero al siguiente nodo
    NodoUsuario* anterior;  // Puntero al nodo anterior

    // Constructor del nodo
    NodoUsuario(const Usuario& usuario) : usuario(usuario), siguiente(this), anterior(this) {}
};

#endif
