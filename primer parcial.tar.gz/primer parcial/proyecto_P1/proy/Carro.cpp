
#include "Carro.h"

Carro::Carro(const std::string& numero_chasis, const std::string& placa, const std::string& modelo, const std::string& marca, int anio, float cilindraje)
    : numero_chasis(numero_chasis), placa(placa), modelo(modelo), marca(marca), anio(anio), cilindraje(cilindraje) {}
