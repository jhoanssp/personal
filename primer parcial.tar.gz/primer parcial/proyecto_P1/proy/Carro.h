
#ifndef CARRO_H
#define CARRO_H

#include <string>

class Carro {
public:
    std::string numero_chasis;
    std::string placa;
    std::string modelo;
    std::string marca;
    int anio;
    float cilindraje;

    Carro(const std::string& numero_chasis, const std::string& placa, const std::string& modelo, const std::string& marca, int anio, float cilindraje);
};

#endif // CARRO_H
