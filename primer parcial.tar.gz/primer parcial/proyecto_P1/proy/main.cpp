
#include "RegistroCarro.h"
#include <regex>
#include <iostream>

bool validarNombre(const std::string& nombre) {
    std::regex regex("^[a-zA-Z]{2,}$");
    return std::regex_match(nombre, regex);
}

bool validarCedula(const std::string& cedula) {
    std::regex regex("^\\d{10}$");
    return std::regex_match(cedula, regex);
}

bool validarAnio(const std::string& anio) {
    std::regex regex("^\\d{4}$");
    return std::regex_match(anio, regex);
}

bool validarPlaca(const std::string& placa) {
    std::regex regex("^[A-Z]{3}\\d{4}$");
    return std::regex_match(placa, regex);
}

bool validarCilindraje(const std::string& cilindraje) {
    std::regex regex("^[0-9]+([.,][0-9]+)?$");
    int puntos = std::count(cilindraje.begin(), cilindraje.end(), '.');
    int comas = std::count(cilindraje.begin(), cilindraje.end(), ',');
    return std::regex_match(cilindraje, regex) && (puntos <= 1 && comas <= 1);
}

int main() {
    RegistroCarro registro;
    registro.cargarDatos();

    std::string nombre, apellido, cedula, numero_chasis, placa, modelo, marca, anio, cilindrajeStr;
    int anioInt;
    float cilindrajeFloat;

    std::cout << "Ingrese el nombre del usuario: ";
    std::getline(std::cin, nombre);
    while (!validarNombre(nombre)) {
        std::cout << "Nombre inválido. Ingrese nuevamente (mínimo 2 letras, sin caracteres no alfabéticos): ";
        std::getline(std::cin, nombre);
    }

    std::cout << "Ingrese el apellido del usuario: ";
    std::getline(std::cin, apellido);
    while (!validarNombre(apellido)) {
        std::cout << "Apellido inválido. Ingrese nuevamente (mínimo 2 letras, sin caracteres no alfabéticos): ";
        std::getline(std::cin, apellido);
    }

    std::cout << "Ingrese la cédula del usuario: ";
    std::getline(std::cin, cedula);
    while (!validarCedula(cedula)) {
        std::cout << "Cédula inválida. Ingrese nuevamente (10 dígitos numéricos): ";
        std::getline(std::cin, cedula);
    }

    Usuario usuario(nombre, apellido, cedula);

    std::cout << "Ingrese el número de chasis del carro: ";
    std::getline(std::cin, numero_chasis);
    while (numero_chasis.length() < 4) {
        std::cout << "Número de chasis inválido. Ingrese nuevamente (mínimo 4 caracteres): ";
        std::getline(std::cin, numero_chasis);
    }

    std::cout << "Ingrese la placa del carro: ";
    std::getline(std::cin, placa);
    while (!validarPlaca(placa)) {
        std::cout << "Placa inválida. Ingrese nuevamente (formato: 3 letras y 4 números): ";
        std::getline(std::cin, placa);
    }

    std::cout << "Ingrese el modelo del carro: ";
    std::getline(std::cin, modelo);
    while (!validarNombre(modelo)) {
        std::cout << "Modelo inválido. Ingrese nuevamente (mínimo 2 letras, sin caracteres no alfabéticos): ";
        std::getline(std::cin, modelo);
    }

    std::cout << "Ingrese la marca del carro: ";
    std::getline(std::cin, marca);
    while (!validarNombre(marca)) {
        std::cout << "Marca inválida. Ingrese nuevamente (mínimo 2 letras, sin caracteres no alfabéticos): ";
        std::getline(std::cin, marca);
    }

    std::cout << "Ingrese el año del carro: ";
    std::getline(std::cin, anio);
    while (!validarAnio(anio)) {
        std::cout << "Año inválido. Ingrese nuevamente (4 dígitos numéricos): ";
        std::getline(std::cin, anio);
    }
    anioInt = std::stoi(anio);

    std::cout << "Ingrese el cilindraje del carro: ";
    std::getline(std::cin, cilindrajeStr);
    while (!validarCilindraje(cilindrajeStr)) {
        std::cout << "Cilindraje inválido. Ingrese nuevamente (números, punto o coma decimal): ";
        std::getline(std::cin, cilindrajeStr);
    }
    cilindrajeFloat = std::stof(cilindrajeStr);

    Carro carro(numero_chasis, placa, modelo, marca, anioInt, cilindrajeFloat);
    registro.agregarUsuario(usuario);
    registro.agregarCarro(cedula, carro);

    registro.guardarDatos();
    registro.mostrar();

    return 0;
}
                     
