
#ifndef NODOCARRO_H
#define NODOCARRO_H

#include "Carro.h"

// Estructura del nodo para la lista circular doble de carros
struct NodoCarro {
    Carro carro;  // Datos del carro
    NodoCarro* siguiente;  // Puntero al siguiente nodo
    NodoCarro* anterior;  // Puntero al nodo anterior

    // Constructor del nodo
    NodoCarro(const Carro& carro) : carro(carro), siguiente(this), anterior(this) {}
};

#endif

