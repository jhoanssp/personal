
#ifndef USUARIO_H
#define USUARIO_H

#include "ListaCarros.h"
#include <string>

class Usuario {
public:
    std::string nombre;
    std::string apellido;
    std::string cedula;
    ListaCarros carros;

    Usuario(const std::string& nombre, const std::string& apellido, const std::string& cedula);
    void agregarCarro(const Carro& carro);
    void eliminarCarro(const std::string& placa);
    Carro* buscarCarro(const std::string& placa);
};

#endif // USUARIO_H

