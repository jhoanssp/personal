

#include "ListaCarros.h"
#include <iostream>

ListaCarros::ListaCarros() : cabeza(nullptr) {}

ListaCarros::~ListaCarros() {
    if (!cabeza) return;
    NodoCarro* actual = cabeza;
    do {
        NodoCarro* temp = actual;
        actual = actual->siguiente;
        delete temp;
    } while (actual != cabeza);
}

void ListaCarros::insertar(const Carro& carro) {
    NodoCarro* nuevo = new NodoCarro(carro);
    if (!cabeza) {
        cabeza = nuevo;
        cabeza->siguiente = cabeza;
        cabeza->anterior = cabeza;
    } else {
        NodoCarro* ultimo = cabeza->anterior;
        nuevo->siguiente = cabeza;
        nuevo->anterior = ultimo;
        ultimo->siguiente = nuevo;
        cabeza->anterior = nuevo;
    }
}

void ListaCarros::eliminar(const std::string& placa) {
    if (!cabeza) return;
    NodoCarro* actual = cabeza;
    do {
        if (actual->carro.placa == placa) {
            if (actual->siguiente == actual) {
                delete actual;
                cabeza = nullptr;
                return;
            } else {
                NodoCarro* siguiente = actual->siguiente;
                NodoCarro* anterior = actual->anterior;
                anterior->siguiente = siguiente;
                siguiente->anterior = anterior;
                if (actual == cabeza) cabeza = siguiente;
                delete actual;
                return;
            }
        }
        actual = actual->siguiente;
    } while (actual != cabeza);
}

Carro* ListaCarros::buscar(const std::string& placa) {
    if (!cabeza) return nullptr;
    NodoCarro* actual = cabeza;
    do {
        if (actual->carro.placa == placa) return &actual->carro;
        actual = actual->siguiente;
    } while (actual != cabeza);
    return nullptr;
}

NodoCarro* ListaCarros::obtenerCabeza() const {
    return cabeza;
}

void ListaCarros::mostrar() const {
    if (!cabeza) return;
    NodoCarro* actual = cabeza;
    do {
        std::cout << "Numero de chasis: " << actual->carro.numero_chasis << " Placa: " << actual->carro.placa << " Modelo: " << actual->carro.modelo << " Marca: " << actual->carro.marca << " Año: " << actual->carro.anio << " Cilindraje: " << actual->carro.cilindraje << std::endl;
        actual = actual->siguiente;
    } while (actual != cabeza);
}

