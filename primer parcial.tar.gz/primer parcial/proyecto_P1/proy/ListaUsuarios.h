

#ifndef LISTA_USUARIOS_H
#define LISTA_USUARIOS_H

#include "Usuario.h"

struct NodoUsuario {
    Usuario usuario;
    NodoUsuario* siguiente;
    NodoUsuario* anterior;
    NodoUsuario(const Usuario& usuario) : usuario(usuario), siguiente(nullptr), anterior(nullptr) {}
};

class ListaUsuarios {
private:
    NodoUsuario* cabeza;

public:
    ListaUsuarios();
    ~ListaUsuarios();
    void insertar(const Usuario& usuario);
    void eliminar(const std::string& cedula);
    NodoUsuario* buscar(const std::string& cedula);
    NodoUsuario* obtenerCabeza() const;
    void mostrar() const;
};

#endif // LISTA_USUARIOS_H

