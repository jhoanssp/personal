

#include "ListaUsuarios.h"
#include <iostream>

ListaUsuarios::ListaUsuarios() : cabeza(nullptr) {}

ListaUsuarios::~ListaUsuarios() {
    if (!cabeza) return;
    NodoUsuario* actual = cabeza;
    do {
        NodoUsuario* temp = actual;
        actual = actual->siguiente;
        delete temp;
    } while (actual != cabeza);
}

void ListaUsuarios::insertar(const Usuario& usuario) {
    NodoUsuario* nuevo = new NodoUsuario(usuario);
    if (!cabeza) {
        cabeza = nuevo;
        cabeza->siguiente = cabeza;
        cabeza->anterior = cabeza;
    } else {
        NodoUsuario* ultimo = cabeza->anterior;
        nuevo->siguiente = cabeza;
        nuevo->anterior = ultimo;
        ultimo->siguiente = nuevo;
        cabeza->anterior = nuevo;
    }
}

void ListaUsuarios::eliminar(const std::string& cedula) {
    if (!cabeza) return;
    NodoUsuario* actual = cabeza;
    do {
        if (actual->usuario.cedula == cedula) {
            if (actual->siguiente == actual) {
                delete actual;
                cabeza = nullptr;
                return;
            } else {
                NodoUsuario* siguiente = actual->siguiente;
                NodoUsuario* anterior = actual->anterior;
                anterior->siguiente = siguiente;
                siguiente->anterior = anterior;
                if (actual == cabeza) cabeza = siguiente;
                delete actual;
                return;
            }
        }
        actual = actual->siguiente;
    } while (actual != cabeza);
}

NodoUsuario* ListaUsuarios::buscar(const std::string& cedula) {
    if (!cabeza) return nullptr;
    NodoUsuario* actual = cabeza;
    do {
        if (actual->usuario.cedula == cedula) return actual;
        actual = actual->siguiente;
    } while (actual != cabeza);
    return nullptr;
}

NodoUsuario* ListaUsuarios::obtenerCabeza() const {
    return cabeza;
}

void ListaUsuarios::mostrar() const {
    if (!cabeza) return;
    NodoUsuario* actual = cabeza;
    do {
        std::cout << "Nombre: " << actual->usuario.nombre << " Apellido: " << actual->usuario.apellido << " Cedula: " << actual->usuario.cedula << std::endl;
        actual->usuario.carros.mostrar();
        actual = actual->siguiente;
    } while (actual != cabeza);
}
