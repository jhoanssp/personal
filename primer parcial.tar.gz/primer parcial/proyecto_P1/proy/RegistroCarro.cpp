
#include "RegistroCarro.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <regex>

RegistroCarro::RegistroCarro() : archivo_usuarios("usuarios.txt"), archivo_carros("carros.txt") {
    cargarDatos();
}

RegistroCarro::~RegistroCarro() {
    guardarDatos();
}

void RegistroCarro::agregarUsuario(const Usuario& usuario) {
    if (!cedulaExiste(usuario.cedula)) {
        usuarios.insertar(usuario);
    } else {
        std::cerr << "Usuario con cedula " << usuario.cedula << " ya existe." << std::endl;
    }
}

void RegistroCarro::agregarCarro(const std::string& cedula, const Carro& carro) {
    if (placaExiste(carro.placa)) {
        std::cerr << "Carro con placa " << carro.placa << " ya existe. Por favor ingrese una nueva placa: ";
        std::string nuevaPlaca;
        bool placaValida = false;

        while (!placaValida) {
            std::cin >> nuevaPlaca;
            if (placaExiste(nuevaPlaca)) {
                std::cerr << "Carro con placa " << nuevaPlaca << " ya existe. Por favor ingrese una nueva placa: ";
            } else if (!std::regex_match(nuevaPlaca, std::regex("^[A-Z]{3}[0-9]{4}$"))) {
                std::cerr << "Formato de placa inválido. Debe tener 3 letras seguidas de 4 números. Por favor intente de nuevo: ";
            } else {
                placaValida = true;
            }
        }

        Carro nuevoCarro = carro;
        nuevoCarro.placa = nuevaPlaca;
        agregarCarro(cedula, nuevoCarro);
        return;
    }

    NodoUsuario* nodo = usuarios.buscar(cedula);
    if (nodo) {
        nodo->usuario.agregarCarro(carro);
    } else {
        std::cerr << "Usuario con cedula " << cedula << " no encontrado." << std::endl;
    }
}

void RegistroCarro::eliminarUsuario(const std::string& cedula) {
    usuarios.eliminar(cedula);
}

void RegistroCarro::eliminarCarro(const std::string& cedula, const std::string& placa) {
    NodoUsuario* nodo = usuarios.buscar(cedula);
    if (nodo) {
        nodo->usuario.eliminarCarro(placa);
    } else {
        std::cerr << "Usuario con cedula " << cedula << " no encontrado." << std::endl;
    }
}

void RegistroCarro::mostrar() {
    usuarios.mostrar();
}

bool RegistroCarro::cedulaExiste(const std::string& cedula) {
    return usuarios.buscar(cedula) != nullptr;
}

bool RegistroCarro::placaExiste(const std::string& placa) {
    NodoUsuario* usuario_actual = usuarios.obtenerCabeza();
    if (usuario_actual) {
        do {
            if (usuario_actual->usuario.carros.buscar(placa)) {
                return true;
            }
            usuario_actual = usuario_actual->siguiente;
        } while (usuario_actual != usuarios.obtenerCabeza());
    }
    return false;
}

void RegistroCarro::cargarDatos() {
    std::ifstream archivo(archivo_usuarios);
    std::string linea;
    while (std::getline(archivo, linea)) {
        std::istringstream iss(linea);
        std::string nombre, apellido, cedula;
        iss >> nombre >> apellido >> cedula;
        Usuario usuario(nombre, apellido, cedula);
        usuarios.insertar(usuario);
    }
    archivo.close();

    archivo.open(archivo_carros);
    while (std::getline(archivo, linea)) {
        std::istringstream iss(linea);
        std::string cedula, numero_chasis, placa, modelo, marca;
        int anio;
        float cilindraje;
        iss >> cedula >> numero_chasis >> placa >> modelo >> marca >> anio >> cilindraje;
        Carro carro(numero_chasis, placa, modelo, marca, anio, cilindraje);
        agregarCarro(cedula, carro);
    }
    archivo.close();
}

void RegistroCarro::guardarDatos() {
    std::ofstream archivo(archivo_usuarios);
    NodoUsuario* usuario_actual = usuarios.obtenerCabeza();
    if (usuario_actual) {
        do {
            archivo << usuario_actual->usuario.nombre << " " << usuario_actual->usuario.apellido << " " << usuario_actual->usuario.cedula << std::endl;
            usuario_actual = usuario_actual->siguiente;
        } while (usuario_actual != usuarios.obtenerCabeza());
    }
    archivo.close();

    archivo.open(archivo_carros);
    if (usuario_actual) {
        do {
            NodoCarro* carro_actual = usuario_actual->usuario.carros.obtenerCabeza();
            if (carro_actual) {
                do {
                    archivo << usuario_actual->usuario.cedula << " " << carro_actual->carro.numero_chasis << " " << carro_actual->carro.placa << " " << carro_actual->carro.modelo << " " << carro_actual->carro.marca << " " << carro_actual->carro.anio << " " << carro_actual->carro.cilindraje << std::endl;
                    carro_actual = carro_actual->siguiente;
                } while (carro_actual != usuario_actual->usuario.carros.obtenerCabeza());
            }
            usuario_actual = usuario_actual->siguiente;
        } while (usuario_actual != usuarios.obtenerCabeza());
    }
    archivo.close();
}

