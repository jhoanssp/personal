
#ifndef LISTA_CARROS_H
#define LISTA_CARROS_H

#include "Carro.h"

struct NodoCarro {
    Carro carro;
    NodoCarro* siguiente;
    NodoCarro* anterior;
    NodoCarro(const Carro& carro) : carro(carro), siguiente(nullptr), anterior(nullptr) {}
};

class ListaCarros {
private:
    NodoCarro* cabeza;

public:
    ListaCarros();
    ~ListaCarros();
    void insertar(const Carro& carro);
    void eliminar(const std::string& placa);
    Carro* buscar(const std::string& placa);
    NodoCarro* obtenerCabeza() const;
    void mostrar() const;
};

#endif // LISTA_CARROS_H
