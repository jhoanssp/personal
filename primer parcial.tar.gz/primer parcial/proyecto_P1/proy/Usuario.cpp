
#include "Usuario.h"

Usuario::Usuario(const std::string& nombre, const std::string& apellido, const std::string& cedula)
    : nombre(nombre), apellido(apellido), cedula(cedula) {}

void Usuario::agregarCarro(const Carro& carro) {
    carros.insertar(carro);
}

void Usuario::eliminarCarro(const std::string& placa) {
    carros.eliminar(placa);
}

Carro* Usuario::buscarCarro(const std::string& placa) {
    return carros.buscar(placa);
}

