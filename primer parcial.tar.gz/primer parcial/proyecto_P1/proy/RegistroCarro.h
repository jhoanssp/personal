
#ifndef REGISTRO_CARRO_H
#define REGISTRO_CARRO_H

#include "ListaUsuarios.h"
#include <string>

class RegistroCarro {
private:
    ListaUsuarios usuarios;
    std::string archivo_usuarios;
    std::string archivo_carros;

public:
    RegistroCarro();
    ~RegistroCarro();
    void agregarUsuario(const Usuario& usuario);
    void agregarCarro(const std::string& cedula, const Carro& carro);
    void eliminarUsuario(const std::string& cedula);
    void eliminarCarro(const std::string& cedula, const std::string& placa);
    void mostrar();
    bool cedulaExiste(const std::string& cedula);
    bool placaExiste(const std::string& placa);

private:
    void cargarDatos();
    void guardarDatos();
};

#endif // REGISTRO_CARRO_H
