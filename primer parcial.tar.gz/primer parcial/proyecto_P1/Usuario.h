
#ifndef USUARIO_H
#define USUARIO_H

#include <string>
#include "Carro.h"


class NodoCarro {
public:
    Carro carro;
    NodoCarro* siguiente;
    NodoCarro* anterior;
    NodoCarro(const Carro& carro) : carro(carro), siguiente(this), anterior(this) {}
};

class Usuario {
public:
    std::string nombre;
    std::string apellido;
    std::string segundonombre;
    std::string cedula;
    std::string provincia;
    std::string correo;
    std::string contrasena;
    NodoCarro* listaCarros;

    Usuario(const std::string& nombre,const std::string& segundonombre, const std::string& apellido,const std::string& cedula, const std::string& provincia,const std::string& correo,const std::string& contrasena);
    
    void agregarCarro(const Carro &carro);
    void eliminarCarro(const std::string& placa);
    void generarCorreo();
    Carro* buscarCarro(const std::string& placa);
    
};

#endif // USUARIO_H
