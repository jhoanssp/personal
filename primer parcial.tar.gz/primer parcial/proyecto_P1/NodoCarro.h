
#ifndef NODOCARRO_H
#define NODOCARRO_H

#include "Carro.h"

// Clase NodoCarro que representa un nodo en la lista doblemente enlazada circular de carros.
class NodoCarro {
public:
    Carro carro;          // Datos del carro almacenado en el nodo
    NodoCarro* siguiente; // Puntero al siguiente nodo en la lista
    NodoCarro* anterior;  // Puntero al nodo anterior en la lista

    // Constructor que inicializa el nodo con los datos del carro.
    NodoCarro(const Carro& carro) : carro(carro), siguiente(this), anterior(this) {}
};

#endif // NODOCARRO_H

