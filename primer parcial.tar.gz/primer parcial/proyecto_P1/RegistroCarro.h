
#ifndef REGISTROCARRO_H
#define REGISTROCARRO_H

#include <string>
#include <map>
#include "Usuario.h"
#include "Carro.h"
#include "Fecha.h"
#include "NodoUsuario.h"

class RegistroCarro {
public:
    RegistroCarro(const std::string& archivo);
    void insertarUsuario(const Usuario& usuario);
    void insertarCarro(const std::string& cedula, const Carro& carro);
    void eliminarCarro(const std::string& cedula, const std::string& placa);
    Usuario* buscarUsuario(const std::string& cedula);
    void buscarPorFecha(const Fecha& fecha);
    void mostrar();
    std::string generarPlaca(const std::string& provincia);

public:
    NodoUsuario* listaUsuarios;
    std::string archivo;
    std::map<std::string, std::string> ultimaPlacaPorProvincia;
    void cargarDesdeArchivo();
    void guardarEnArchivo();
    //bool placaExiste(const std::string& placa) const;
};

#endif // REGISTROCARRO_H

