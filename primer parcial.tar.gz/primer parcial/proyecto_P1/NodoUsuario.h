
#ifndef NODOUSUARIO_H
#define NODOUSUARIO_H

#include "Usuario.h"

// Clase NodoUsuario representa un nodo en una lista doblemente enlazada circular de usuarios
class NodoUsuario {
public:
    Usuario usuario;  // Usuario almacenado en este nodo
    NodoUsuario* siguiente;  // Puntero al siguiente nodo
    NodoUsuario* anterior;  // Puntero al nodo anterior

    // Constructor
    NodoUsuario(const Usuario& usuario) : usuario(usuario), siguiente(this), anterior(this) {}
};

#endif

