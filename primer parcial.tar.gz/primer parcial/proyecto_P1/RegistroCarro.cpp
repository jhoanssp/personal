

#include "RegistroCarro.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <iomanip>

RegistroCarro::RegistroCarro(const std::string& archivo) : listaUsuarios(nullptr), archivo(archivo) {
    cargarDesdeArchivo();
}

void RegistroCarro::insertarUsuario(const Usuario& usuario) {
    NodoUsuario* nuevo = new NodoUsuario(usuario);
    if (!listaUsuarios) {
        listaUsuarios = nuevo;
        listaUsuarios->siguiente = listaUsuarios->anterior = listaUsuarios;
    } else {
        NodoUsuario* ultimo = listaUsuarios->anterior;
        ultimo->siguiente = nuevo;
        nuevo->anterior = ultimo;
        nuevo->siguiente = listaUsuarios;
        listaUsuarios->anterior = nuevo;
    }
    guardarEnArchivo();
}

void RegistroCarro::insertarCarro(const std::string& cedula, const Carro& carro) {
    Usuario* usuario = buscarUsuario(cedula);
    if (usuario) {
        NodoCarro* nuevo = new NodoCarro(carro);
        if (!usuario->listaCarros) {
            usuario->listaCarros = nuevo;
            usuario->listaCarros->siguiente = usuario->listaCarros->anterior = usuario->listaCarros;
        } else {
            NodoCarro* ultimo = usuario->listaCarros->anterior;
            ultimo->siguiente = nuevo;
            nuevo->anterior = ultimo;
            nuevo->siguiente = usuario->listaCarros;
            usuario->listaCarros->anterior = nuevo;
        }
        guardarEnArchivo();
    }
}

void RegistroCarro::eliminarCarro(const std::string& cedula, const std::string& placa) {
    Usuario* usuario = buscarUsuario(cedula);
    if (usuario && usuario->listaCarros) {
        NodoCarro* actual = usuario->listaCarros;
        do {
            if (actual->carro.placa == placa) {
                if (actual->siguiente == actual) {
                    usuario->listaCarros = nullptr;
                } else {
                    actual->anterior->siguiente = actual->siguiente;
                    actual->siguiente->anterior = actual->anterior;
                    if (usuario->listaCarros == actual) {
                        usuario->listaCarros = actual->siguiente;
                    }
                }
                delete actual;
                guardarEnArchivo();
                return;
            }
            actual = actual->siguiente;
        } while (actual != usuario->listaCarros);
    }
}

Usuario* RegistroCarro::buscarUsuario(const std::string& cedula) {
    if (!listaUsuarios) return nullptr;
    NodoUsuario* actual = listaUsuarios;
    do {
        if (actual->usuario.cedula == cedula) {
            return &actual->usuario;
        }
        actual = actual->siguiente;
    } while (actual != listaUsuarios);
    return nullptr;
}

void RegistroCarro::buscarPorFecha(const Fecha& fecha) {
    if (!listaUsuarios) return;
    NodoUsuario* actualUsuario = listaUsuarios;
    bool encontrado = false;
    do {
        NodoCarro* actualCarro = actualUsuario->usuario.listaCarros;
        if (actualCarro) {
            do {
                if (actualCarro->carro.fecha.getDia() == fecha.getDia() &&
                    actualCarro->carro.fecha.getMes() == fecha.getMes() &&
                    actualCarro->carro.fecha.getAnio() == fecha.getAnio()) {
                    if (!encontrado) {
                        std::cout << "Carros encontrados en la fecha " << fecha.toString() << ":\n";
                        encontrado = true;
                    }
                    std::cout << actualCarro->carro.toString() << "\n";
                }
                actualCarro = actualCarro->siguiente;
            } while (actualCarro != actualUsuario->usuario.listaCarros);
        }
        actualUsuario = actualUsuario->siguiente;
    } while (actualUsuario != listaUsuarios);
    if (!encontrado) {
        std::cout << "No se encontraron carros en la fecha " << fecha.toString() << ".\n";
    }
}

void RegistroCarro::mostrar() {
    if (!listaUsuarios) return;
    NodoUsuario* actualUsuario = listaUsuarios;
    do {
        std::cout << "Usuario: " << actualUsuario->usuario.nombre <<" " << actualUsuario->usuario.segundonombre << " " << actualUsuario->usuario.apellido << ", Cédula: " << actualUsuario->usuario.cedula
                  << ", Provincia: " << actualUsuario->usuario.provincia << "\n";
        NodoCarro* actualCarro = actualUsuario->usuario.listaCarros;
        if (actualCarro) {
            do {
                std::cout << "  Carro: " << actualCarro->carro.modelo << ", Placa: " << actualCarro->carro.placa
                          << ", Color: " << actualCarro->carro.color << ", Tipo: " << actualCarro->carro.tipo <<", Marca: "
                          << actualCarro->carro.marca << ", Año: " << actualCarro->carro.anio
                            << ", Fecha: " << actualCarro->carro.fecha.toString() << "\n";
                actualCarro = actualCarro->siguiente;
            } while (actualCarro != actualUsuario->usuario.listaCarros);
        }
        actualUsuario = actualUsuario->siguiente;
    } while (actualUsuario != listaUsuarios);
}

std::string RegistroCarro::generarPlaca(const std::string& provincia) {
    std::string& ultimaPlaca = ultimaPlacaPorProvincia[provincia];
    if (ultimaPlaca.empty()) {
        ultimaPlaca = provincia + "AA-0000";
    }

    std::string letras = ultimaPlaca.substr(1, 3);
    int numeros = std::stoi(ultimaPlaca.substr(5, 4));

    if (numeros < 9999) {
        numeros++;
    } else {
        numeros = 1;
        for (int i = 2; i >= 0; --i) {
            if (letras[i] < 'Z') {
                letras[i]++;
                break;
            } else {
                letras[i] = 'A';
            }
        }
    }

    std::ostringstream oss;
    oss << provincia << letras << '-' << std::setw(4) << std::setfill('0') << numeros;
    ultimaPlaca = oss.str();
    return ultimaPlaca;
}

void RegistroCarro::cargarDesdeArchivo() {
    std::ifstream archivoEntrada(archivo);
    if (archivoEntrada) {
        std::string linea;
        while (std::getline(archivoEntrada, linea)) {
            std::istringstream iss(linea);
            std::string nombre,segundonombre,apellido ,cedula, provincia,correo,contrasena;
            std::getline(iss, nombre, ',');
            std::getline(iss, segundonombre, ',');
            std::getline(iss, apellido, ',');
            std::getline(iss, cedula, ',');
            std::getline(iss, provincia, ',');
            std::getline(iss, correo, ',');
            std::getline(iss, contrasena, ',');
            Usuario usuario(nombre,segundonombre,apellido,cedula, provincia,cedula,contrasena);

            std::string placa, modelo, marca,color,tipo, anioStr, diaStr, mesStr, anioFechaStr;
            while (std::getline(iss, placa, ',')) {
                std::getline(iss, modelo, ',');
                std::getline(iss, marca, ',');
                std::getline(iss, color, ',');
                std::getline(iss, tipo, ',');
                std::getline(iss, anioStr, ',');
                std::getline(iss, diaStr, ',');
                std::getline(iss, mesStr, ',');
                std::getline(iss, anioFechaStr, ',');

                int anio = std::stoi(anioStr);
                int dia = std::stoi(diaStr);
                int mes = std::stoi(mesStr);
                int anioFecha = std::stoi(anioFechaStr);

                Carro carro(placa, modelo, marca,color,tipo, anio, Fecha(dia, mes, anioFecha));
                usuario.agregarCarro(carro);
            }
            insertarUsuario(usuario);
        }
        archivoEntrada.close();
    }
}

void RegistroCarro::guardarEnArchivo() {
    std::ofstream archivoSalida(archivo);
    if (archivoSalida) {
        NodoUsuario* actualUsuario = listaUsuarios;
        do {
            archivoSalida << actualUsuario->usuario.nombre << ',' << actualUsuario->usuario.segundonombre << ',' << actualUsuario->usuario.apellido << ',' << actualUsuario->usuario.cedula << ',' << actualUsuario->usuario.provincia;
            NodoCarro* actualCarro = actualUsuario->usuario.listaCarros;
            if (actualCarro) {
                do {
                    archivoSalida << ',' << actualCarro->carro.placa << ',' << actualCarro->carro.modelo
                                  << ',' << actualCarro->carro.marca << ',' << actualCarro->carro.color << ',' << actualCarro->carro.tipo << ',' << actualCarro->carro.anio 
                                  << ',' << actualCarro->carro.fecha.getDia() << ',' << actualCarro->carro.fecha.getMes()
                                  << ',' << actualCarro->carro.fecha.getAnio();
                    actualCarro = actualCarro->siguiente;
                } while (actualCarro != actualUsuario->usuario.listaCarros);
            }
            archivoSalida << '\n';
            actualUsuario = actualUsuario->siguiente;
        } while (actualUsuario != listaUsuarios);
        archivoSalida.close();
    }
}


