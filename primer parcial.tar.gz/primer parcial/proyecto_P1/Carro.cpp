
#include "Carro.h"
#include <sstream>

Carro::Carro(const std::string& placa, const std::string& modelo, const std::string& marca,const std::string& color,const std::string& tipo, int anio, const Fecha& fecha)
    : placa(placa), modelo(modelo), marca(marca),color(color),tipo(tipo), anio(anio), fecha(fecha) {}

std::string Carro::toString() const {
    std::ostringstream oss;
    oss << "Modelo: " << modelo << ", Placa: " << placa << ", Color: " << color<< ", Tipo: " << tipo
        << ", Marca: " << marca << ", Año: " << anio<< ", Fecha: " << fecha.toString();
    return oss.str();
}

