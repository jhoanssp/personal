
#ifndef FECHA_H
#define FECHA_H

#include <string>

class Fecha {
public:
    Fecha(int dia, int mes, int anio);

    int getDia() const;
    int getMes() const;
    int getAnio() const;
    bool esValida() const;
    std::string toString() const;
    static bool validarFecha(int dia, int mes, int anio);
    static Fecha obtenerFechaActual();

private:
    int dia;
    int mes;
    int anio;
};

#endif // FECHA_H
