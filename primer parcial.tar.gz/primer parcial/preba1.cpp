#include <iostream>
#include <functional>

// Función auxiliar para sumar los dígitos de un número
int sumaDigitos(int numero) {
    int suma = 0;
    while (numero != 0) {
        suma += numero % 10;
        numero /= 10;
    }
    return suma;
}

int main() {
    Nodo* cabeza = nullptr;

    // Agregar algunos elementos a la lista
    agregarNodo(cabeza, 123);
    agregarNodo(cabeza, 45);
    agregarNodo(cabeza, 678);

    // Imprimir la lista (para depuración)
    imprimirLista(cabeza);

    // Definir la lambda recursiva
    std::function<int(Nodo*)> sumarDigitos = [&](Nodo* nodo) -> int {
        if (nodo == nullptr) {
            return 0;
        }
        return sumaDigitos(nodo->dato) + sumarDigitos(nodo->siguiente);
    };

    // Calcular la suma de los dígitos
    int resultado = sumarDigitos(cabeza);
    std::cout << "La suma de los dígitos es: " << resultado << std::endl;

    // Liberar memoria
    while (cabeza != nullptr) {
        Nodo* temp = cabeza;
        cabeza = cabeza->siguiente;
        delete temp;
    }

    return 0;
}
