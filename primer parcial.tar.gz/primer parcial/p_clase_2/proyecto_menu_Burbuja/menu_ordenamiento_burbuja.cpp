#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include <set>
#include <vector>
#include <algorithm>
#include <cctype>
#include <iomanip>

using namespace std;

class Empleado {
public:
    string idEmpleado;
    string cedula;
    string nombre1;
    string nombre2;
    string apellido;
    string correo;
    string clave;
    string claveCifrada;

    Empleado(string id, string ced, string nom1, string nom2, string ape, string cor, string cla, string claCif)
        : idEmpleado(id), cedula(ced), nombre1(nom1), nombre2(nom2), apellido(ape), correo(cor), clave(cla), claveCifrada(claCif) {}
};

class DoublyLinkedList {
    struct Node {
        Empleado* empleado;
        Node* next;
        Node* prev;
        Node(Empleado* emp) : empleado(emp), next(nullptr), prev(nullptr) {}
    };
    Node* head;
    Node* tail;

public:
    DoublyLinkedList() : head(nullptr), tail(nullptr) {}

    void append(Empleado* empleado) {
        Node* newNode = new Node(empleado);
        if (!head) {
            head = tail = newNode;
        } else {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
    }

    Empleado* findByCedula(const string& cedula) {
        Node* current = head;
        while (current) {
            if (current->empleado->cedula == cedula) {
                return current->empleado;
            }
            current = current->next;
        }
        return nullptr;
    }

    vector<Empleado*> toVector() {
        vector<Empleado*> vec;
        Node* current = head;
        while (current) {
            vec.push_back(current->empleado);
            current = current->next;
        }
        return vec;
    }

    void fromVector(const vector<Empleado*>& vec) {
        head = tail = nullptr;
        for (Empleado* emp : vec) {
            append(emp);
        }
    }

    void saveToFile(const string& filename) {
        ofstream file(filename, ios::app); // Abre el archivo en modo de adición
        Node* current = head;
        while (current) {
            file << current->empleado->idEmpleado << " "
                 << current->empleado->cedula << " "
                 << current->empleado->nombre1 << " "
                 << current->empleado->nombre2 << " "
                 << current->empleado->apellido << " "
                 << current->empleado->correo << " "
                 << current->empleado->clave << " "
                 << current->empleado->claveCifrada << endl;
            current = current->next;
        }
    }
};

bool validarCedula(const string& cedula) {
    // Validar que la cédula tenga solo dígitos y tenga 10 caracteres
    return cedula.size() == 10 && all_of(cedula.begin(), cedula.end(), ::isdigit);
}

bool validarNombreApellido(const string& nombre) {
    // Validar que el nombre o apellido no tenga caracteres alfanuméricos
    return all_of(nombre.begin(), nombre.end(), ::isalpha);
}

string cifrarContrasena(const string& contrasena) {
    string cifrada;
    for (char c : contrasena) {
        if (isalpha(c)) {
            if (islower(c)) {
                cifrada += (c - 'a' + 2) % 26 + 'a';
            } else {
                cifrada += (c - 'A' + 2) % 26 + 'A';
            }
        } else if (isdigit(c)) {
            cifrada += (c - '0' + 2) % 10 + '0';
        }
    }
    // Si no hay números en la contraseña cifrada, agregar un '3' al final de la cifrada
    if (cifrada.find_first_of("0123456789") == string::npos) {
        cifrada += '3';
    }
    return cifrada;
}

string descifrarContrasena(const string& contrasenaCifrada) {
    string descifrada;
    for (char c : contrasenaCifrada) {
        if (isalpha(c)) {
            if (islower(c)) {
                descifrada += (c - 'a' - 2 + 26) % 26 + 'a';
            } else {
                descifrada += (c - 'A' - 2 + 26) % 26 + 'A';
            }
        } else if (isdigit(c)) {
            descifrada += (c - '0' - 2 + 10) % 10 + '0';
        }
    }
    // Si no hay números en la contraseña descifrada, agregar un '1' al final de la descifrada
    if (descifrada.find_first_of("0123456789") == string::npos) {
        descifrada += '1';
    }
    return descifrada;
}

string generarCorreo(const string& nombre1, const string& nombre2, const string& apellido, map<string, int>& correosExistentes) {
    string base = nombre1.substr(0, 1) + nombre2.substr(0, 1) + apellido;
    string correo;
    int contador = 1;
    if (correosExistentes.find(base) != correosExistentes.end()) {
        contador = ++correosExistentes[base];
    } else {
        correosExistentes[base] = contador;
    }
    correo = base + to_string(contador) + "@espe.edu.ec";
    return correo;
}

string generarContrasena(const string& nombre1, const string& nombre2, const string& apellido, map<string, int>& contrasenasExistentes) {
    string base = apellido.substr(apellido.size() - 1) + nombre1.substr(0, 1) + nombre2.substr(0, 1) + string(apellido.rbegin() + 1, apellido.rend());
    string contrasena;
    int contador = 1;
    if (contrasenasExistentes.find(base) != contrasenasExistentes.end()) {
        contador = ++contrasenasExistentes[base];
    } else {
        contrasenasExistentes[base] = contador;
    }
    contrasena = base + to_string(contador);
    return contrasena;
}

string generarIDEmpleado(int ultimoID) {
    ostringstream oss;
    oss << "EMP" << setfill('0') << setw(4) << (ultimoID + 1);
    return oss.str();
}

void agregarEmpleado(DoublyLinkedList& empleados, set<string>& cedulasExistentes, map<string, int>& correosExistentes, map<string, int>& contrasenasExistentes, int& ultimoID) {
    string cedula;
    while (true) {
        cout << "Ingrese la cédula del empleado: ";
        cin >> cedula;
        if (validarCedula(cedula) && cedulasExistentes.find(cedula) == cedulasExistentes.end()) {
            break;
        }
        cout << "Cédula inválida o ya existente. Intente nuevamente." << endl;
    }

    string nombre1;
    while (true) {
        cout << "Ingrese el primer nombre del empleado: ";
        cin >> nombre1;
        if (validarNombreApellido(nombre1)) {
            break;
        }
        cout << "Nombre inválido. Intente nuevamente." << endl;
    }

    string nombre2;
    cout << "Ingrese el segundo nombre del empleado (opcional): ";
    cin.ignore();
    getline(cin, nombre2);
    if (!nombre2.empty() && !validarNombreApellido(nombre2)) {
        cout << "Segundo nombre inválido. Se omitirá el segundo nombre." << endl;
        nombre2 = "";
    }

    string apellido;
    while (true) {
        cout << "Ingrese el apellido del empleado: ";
        cin >> apellido;
        if (validarNombreApellido(apellido)) {
            break;
        }
        cout << "Apellido inválido. Intente nuevamente." << endl;
    }

    string correo = generarCorreo(nombre1, nombre2, apellido, correosExistentes);
    string contrasena = generarContrasena(nombre1, nombre2, apellido, contrasenasExistentes);
    string claveCifrada = cifrarContrasena(contrasena);
    string idEmpleado = generarIDEmpleado(ultimoID);

    Empleado* empleado = new Empleado(idEmpleado, cedula, nombre1, nombre2, apellido, correo, contrasena, claveCifrada);
    empleados.append(empleado);
    cedulasExistentes.insert(cedula);
    ultimoID++;
    cout << "Empleado agregado con éxito. Su correo es: " << correo << " y su contraseña es: " << contrasena << endl;
}

void cargarDatosExistentes(const string& filename, map<string, int>& correosExistentes, map<string, int>& contrasenasExistentes, set<string>& cedulasExistentes, DoublyLinkedList& empleados, int& ultimoID) {
    ifstream file(filename);
    if (!file) {
        return;
    }

    string id, cedula, nombre1, nombre2, apellido, correo, clave, claveCifrada;
    while (file >> id >> cedula >> nombre1 >> nombre2 >> apellido >> correo >> clave >> claveCifrada) {
        Empleado* empleado = new Empleado(id, cedula, nombre1, nombre2, apellido, correo, clave, claveCifrada);
        empleados.append(empleado);
        cedulasExistentes.insert(cedula);
        correosExistentes[correo]++;
        contrasenasExistentes[clave]++;
        stringstream ss(id.substr(3));
        int idNum;
        ss >> idNum;
        if (idNum > ultimoID) {
            ultimoID = idNum;
        }
    }
}

template<typename Compare>
void bubbleSort(vector<Empleado*>& vec, Compare comp) {
    for (size_t i = 0; i < vec.size() - 1; ++i) {
        for (size_t j = 0; j < vec.size() - i - 1; ++j) {
            if (comp(vec[j + 1], vec[j])) {
                swap(vec[j], vec[j + 1]);
            }
        }
    }
}

bool compareByCedula(Empleado* a, Empleado* b) {
    return a->cedula < b->cedula;
}

bool compareByNombre(Empleado* a, Empleado* b) {
    return a->nombre1 < b->nombre1;
}

bool compareByApellido(Empleado* a, Empleado* b) {
    return a->apellido < b->apellido;
}

void ordenarEmpleados(DoublyLinkedList& empleados) {
    vector<Empleado*> vec = empleados.toVector();
    int opcion;
    cout << "Seleccione el criterio de ordenación:" << endl;
    cout << "1. Ordenar por cédula" << endl;
    cout << "2. Ordenar por nombre" << endl;
    cout << "3. Ordenar por apellido" << endl;
    cout << "Ingrese su opción: ";
    cin >> opcion;

    switch (opcion) {
    case 1:
        bubbleSort(vec, compareByCedula);
        break;
    case 2:
        bubbleSort(vec, compareByNombre);
        break;
    case 3:
        bubbleSort(vec, compareByApellido);
        break;
    default:
        cout << "Opción inválida." << endl;
        return;
    }

    // Mostrar los empleados ordenados en la terminal
    for (Empleado* emp : vec) {
        cout << emp->idEmpleado << " "
             << emp->cedula << " "
             << emp->nombre1 << " "
             << emp->nombre2 << " "
             << emp->apellido << " "
             << emp->correo << " "
             << emp->clave << " "
             << emp->claveCifrada << endl;
    }
}

void mostrarMenu(DoublyLinkedList& empleados, set<string>& cedulasExistentes, map<string, int>& correosExistentes, map<string, int>& contrasenasExistentes, int& ultimoID) {
    int opcion;
    do {
        cout << "Menú de opciones:" << endl;
        cout << "1. Crear nuevo empleado" << endl;
        cout << "2. Buscar empleado por cédula y mostrar información" << endl;
        cout << "3. Ordenar empleados" << endl;
        cout << "4. Salir" << endl;
        cout << "Ingrese su opción: ";
        cin >> opcion;

        switch (opcion) {
        case 1:
            agregarEmpleado(empleados, cedulasExistentes, correosExistentes, contrasenasExistentes, ultimoID);
            empleados.saveToFile("empleados.txt");
            break;
        case 2: {
            string cedula;
            cout << "Ingrese la cédula del empleado: ";
            cin >> cedula;
            Empleado* empleado = empleados.findByCedula(cedula);
            if (empleado) {
                cout << "Información del empleado:" << endl;
                cout << "ID: " << empleado->idEmpleado << endl;
                cout << "Cédula: " << empleado->cedula << endl;
                cout << "Nombre: " << empleado->nombre1 << " " << empleado->nombre2 << endl;
                cout << "Apellido: " << empleado->apellido << endl;
                cout << "Correo: " << empleado->correo << endl;
                cout << "Contraseña cifrada: " << empleado->claveCifrada << endl;
            } else {
                cout << "Empleado no encontrado." << endl;
            }
            break;
        }
        case 3:
            ordenarEmpleados(empleados);
            break;
        case 4:
            cout << "Saliendo del programa..." << endl;
            break;
        default:
            cout << "Opción inválida. Intente nuevamente." << endl;
        }
    } while (opcion != 4);
}

int main() {
    DoublyLinkedList empleados;
    map<string, int> correosExistentes;
    map<string, int> contrasenasExistentes;
    set<string> cedulasExistentes;
    int ultimoID = 0;

    cargarDatosExistentes("empleados.txt", correosExistentes, contrasenasExistentes, cedulasExistentes, empleados, ultimoID);
    mostrarMenu(empleados, cedulasExistentes, correosExistentes, contrasenasExistentes, ultimoID);

    return 0;
}
