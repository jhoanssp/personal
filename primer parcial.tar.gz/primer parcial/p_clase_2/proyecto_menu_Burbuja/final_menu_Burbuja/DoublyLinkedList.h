
#ifndef DOUBLYLINKEDLIST_H
#define DOUBLYLINKEDLIST_H

#include <vector>
#include <string>
#include <fstream>
#include "Empleado.h"

class DoublyNode {
public:
    Empleado* data;
    DoublyNode* next;
    DoublyNode* prev;

    DoublyNode(Empleado* data) : data(data), next(nullptr), prev(nullptr) {}
};

class DoublyLinkedList {
private:
    DoublyNode* head;
    DoublyNode* tail;

public:
    DoublyLinkedList() : head(nullptr), tail(nullptr) {}

    void append(Empleado* data) {
        DoublyNode* newNode = new DoublyNode(data);
        if (!head) {
            head = newNode;
            tail = newNode;
        } else {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
    }

    Empleado* buscarPorCedula(const std::string& cedula) {
        DoublyNode* current = head;
        while (current) {
            if (current->data->cedula == cedula) {
                return current->data;
            }
            current = current->next;
        }
        return nullptr;
    }

    std::vector<Empleado*> toVector() {
        std::vector<Empleado*> vec;
        DoublyNode* current = head;
        while (current) {
            vec.push_back(current->data);
            current = current->next;
        }
        return vec;
    }

    void saveToFile(const std::string& filename) {
        std::ofstream file(filename);
        std::set<std::string> savedCedulas;
        DoublyNode* current = head;
        while (current) {
            if (savedCedulas.count(current->data->cedula) == 0) {
                file << current->data->cedula << " "
                     << current->data->nombre << " "
                     << current->data->apellido << " "
                     << current->data->nombreOrdenado << std::endl;
                savedCedulas.insert(current->data->cedula);
            }
            current = current->next;
        }
    }
};

#endif
