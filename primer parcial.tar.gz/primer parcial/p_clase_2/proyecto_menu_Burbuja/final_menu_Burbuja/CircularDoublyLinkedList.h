
#ifndef CIRCULARDOUBLYLINKEDLIST_H
#define CIRCULARDOUBLYLINKEDLIST_H

#include <vector>
#include <string>
#include <fstream>
#include "Empleado.h"

class CircularDoublyNode {
public:
    Empleado* data;
    CircularDoublyNode* next;
    CircularDoublyNode* prev;

    CircularDoublyNode(Empleado* data) : data(data), next(this), prev(this) {}
};

class CircularDoublyLinkedList {
private:
    CircularDoublyNode* head;

public:
    CircularDoublyLinkedList() : head(nullptr) {}

    void append(Empleado* data) {
        CircularDoublyNode* newNode = new CircularDoublyNode(data);
        if (!head) {
            head = newNode;
        } else {
            CircularDoublyNode* tail = head->prev;
            tail->next = newNode;
            newNode->prev = tail;
            newNode->next = head;
            head->prev = newNode;
        }
    }

    Empleado* buscarPorCedula(const std::string& cedula) {
        if (!head) return nullptr;
        CircularDoublyNode* current = head;
        do {
            if (current->data->cedula == cedula) {
                return current->data;
            }
            current = current->next;
        } while (current != head);
        return nullptr;
    }

    std::vector<Empleado*> toVector() {
        std::vector<Empleado*> vec;
        if (!head) return vec;
        CircularDoublyNode* current = head;
        do {
            vec.push_back(current->data);
            current = current->next;
        } while (current != head);
        return vec;
    }

    void saveToFile(const std::string& filename) {
        std::ofstream file(filename);
        std::set<std::string> savedCedulas;
        if (!head) return;
        CircularDoublyNode* current = head;
        do {
            if (savedCedulas.count(current->data->cedula) == 0) {
                file << current->data->cedula << " "
                     << current->data->nombre << " "
                     << current->data->apellido << " "
                     << current->data->nombreOrdenado << std::endl;
                savedCedulas.insert(current->data->cedula);
            }
            current = current->next;
        } while (current != head);
    }
};

#endif
