
#ifndef EMPLEADO_H
#define EMPLEADO_H

#include <string>

class Empleado {
public:
    std::string cedula;
    std::string nombre;
    std::string apellido;
    std::string nombreOrdenado;

    Empleado(const std::string& cedula, const std::string& nombre, const std::string& apellido, const std::string& nombreOrdenado)
        : cedula(cedula), nombre(nombre), apellido(apellido), nombreOrdenado(nombreOrdenado) {}
};

#endif

