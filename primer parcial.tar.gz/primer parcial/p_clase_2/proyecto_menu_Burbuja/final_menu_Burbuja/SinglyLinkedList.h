
#ifndef SINGLYLINKEDLIST_H
#define SINGLYLINKEDLIST_H

#include <vector>
#include <string>
#include <fstream>
#include "Empleado.h"

class Node {
public:
    Empleado* data;
    Node* next;

    Node(Empleado* data) : data(data), next(nullptr) {}
};

class SinglyLinkedList {
private:
    Node* head;
    Node* tail;

public:
    SinglyLinkedList() : head(nullptr), tail(nullptr) {}

    void append(Empleado* data) {
        Node* newNode = new Node(data);
        if (!head) {
            head = newNode;
            tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }
    }

    Empleado* buscarPorCedula(const std::string& cedula) {
        Node* current = head;
        while (current) {
            if (current->data->cedula == cedula) {
                return current->data;
            }
            current = current->next;
        }
        return nullptr;
    }

    std::vector<Empleado*> toVector() {
        std::vector<Empleado*> vec;
        Node* current = head;
        while (current) {
            vec.push_back(current->data);
            current = current->next;
        }
        return vec;
    }

    void saveToFile(const std::string& filename) {
        std::ofstream file(filename);
        std::set<std::string> savedCedulas;
        Node* current = head;
        while (current) {
            if (savedCedulas.count(current->data->cedula) == 0) {
                file << current->data->cedula << " "
                     << current->data->nombre << " "
                     << current->data->apellido << " "
                     << current->data->nombreOrdenado << std::endl;
                savedCedulas.insert(current->data->cedula);
            }
            current = current->next;
        }
    }
};

#endif

