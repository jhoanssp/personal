#include <iostream>
#include <sstream>
#include <algorithm>
#include <map>
#include <set>
#include <fstream>
#include <cctype>
#include <iomanip>
#include <limits>
#include <cstring>
#include <vector>

using namespace std;

class Clave {
public:
    string clave;

    Clave(string clave) {
        this->clave = clave;
    }
};

class Trabajo {
public:
    string nombre;
    double sueldo;

    Trabajo(string nombre, double sueldo) {
        this->nombre = nombre;
        this->sueldo = sueldo;
    }
};

class Persona {
public:
    string cedula;
    string nombre1;
    string nombre2;
    string apellido;
    string correo;

    Persona(string cedula, string nombre1, string nombre2, string apellido, string correo) {
        this->cedula = cedula;
        this->nombre1 = nombre1;
        this->nombre2 = nombre2;
        this->apellido = apellido;
        this->correo = correo;
    }
};

class Empleado : public Persona {
public:
    string idEmpleado;
    Clave clave;
    string claveCifrada;
    vector<Trabajo> trabajos;

    Empleado(string idEmpleado, string cedula, string nombre1, string nombre2, string apellido, string correo, string clave, string claveCifrada)
        : Persona(cedula, nombre1, nombre2, apellido, correo), clave(clave), claveCifrada(claveCifrada) {
        this->idEmpleado = idEmpleado;
    }

    void agregarTrabajo(string nombre, double sueldo) {
        trabajos.push_back(Trabajo(nombre, sueldo));
    }

    void ordenarSueldos() {
        // Algoritmo de ordenación burbuja
        //iterar sobre cada elemento
        for (size_t i = 0; i < trabajos.size(); i++) {
            //compara cada par de elementos adyacentes
            for (size_t j = 0; j < trabajos.size() - i - 1; j++) {
                //si el sueldo del elemento actual es mayor que el sueldo del elemento siguiente, entonces intercambiarlos
                if (trabajos[j].sueldo > trabajos[j + 1].sueldo) {
                    swap(trabajos[j], trabajos[j + 1]);
                }
            }
        }
    }
};

class Nodo {
public:
    Empleado* empleado;
    Nodo* siguiente;
    Nodo* anterior;

    Nodo(Empleado* empleado) : empleado(empleado), siguiente(nullptr), anterior(nullptr) {}
};

class ListaDobleEnlazada {
public:
    Nodo* cabeza;
    Nodo* cola;

    ListaDobleEnlazada() : cabeza(nullptr), cola(nullptr) {}

    void agregar(Empleado* empleado) {
        Nodo* nuevoNodo = new Nodo(empleado);
        if (!cabeza) {
            cabeza = cola = nuevoNodo;
        } else {
            cola->siguiente = nuevoNodo;
            nuevoNodo->anterior = cola;
            cola = nuevoNodo;
        }
    }

    Empleado* buscarPorCedula(const string& cedula) {
        Nodo* actual = cabeza;
        while (actual) {
            if (actual->empleado->cedula == cedula) {
                return actual->empleado;
            }
            actual = actual->siguiente;
        }
        return nullptr;
    }

    void guardarEnArchivo(const string& rutaArchivo) {
        ofstream archivo(rutaArchivo, ios::trunc);
        if (archivo.is_open()) {
            Nodo* actual = cabeza;
            while (actual) {
                Empleado* empleado = actual->empleado;
                archivo << empleado->idEmpleado << endl;
                archivo << empleado->nombre1 << " " << empleado->nombre2 << " " << empleado->apellido << endl;
                archivo << empleado->cedula << endl;
                archivo << empleado->correo << endl;
                archivo << empleado->clave.clave << endl;
                archivo << empleado->claveCifrada << endl;
                for (const auto& trabajo : empleado->trabajos) {
                    archivo << trabajo.nombre << ": " << fixed << setprecision(2) << trabajo.sueldo << endl;
                }
                archivo << "END" << endl;
                actual = actual->siguiente;
            }
            archivo.close();
            cout << "Los datos han sido guardados y actualizados en '" << rutaArchivo << "'." << endl;
        } else {
            cout << "No se pudo abrir el archivo para escribir." << endl;
        }
    }
};

void cargarDatosExistentes(string rutaArchivo, map<string, int>& correosExistentes, map<string, int>& contrasenasExistentes, set<string>& cedulasExistentes, ListaDobleEnlazada& empleados, int& ultimoID) {
    ifstream archivo(rutaArchivo);
    if (archivo.is_open()) {
        string linea;
        while (getline(archivo, linea)) {
            string idEmpleado;
            string nombreCompleto;
            string cedula;
            string correo;
            string contrasena;
            string contrasenaCifrada;

            idEmpleado = linea;

            getline(archivo, nombreCompleto);
            getline(archivo, cedula);
            getline(archivo, correo);
            getline(archivo, contrasena);
            getline(archivo, contrasenaCifrada);

            Empleado* empleado = new Empleado(idEmpleado, cedula, nombreCompleto, "", "", correo, contrasena, contrasenaCifrada);

            while (getline(archivo, linea) && linea != "END") {
                stringstream ss(linea);
                string nombreTrabajo;
                double sueldo;
                ss >> nombreTrabajo;
                ss.ignore(2);
                ss >> sueldo;
                empleado->agregarTrabajo(nombreTrabajo, sueldo);
            }

            empleados.agregar(empleado);
            cedulasExistentes.insert(cedula);

            if (idEmpleado.length() > 5) {
                try {
                    int idNum = stoi(idEmpleado.substr(5));
                    ultimoID = max(ultimoID, idNum);
                } catch (const std::invalid_argument& e) {
                    cerr << "Error al convertir ID de empleado a entero: " << e.what() << endl;
                }
            }
        }
        archivo.close();
    } else {
        cout << "No se pudo abrir el archivo para leer." << endl;
    }
}

bool validarCedula(const string& cedula) {
    return cedula.length() == 10 && all_of(cedula.begin(), cedula.end(), ::isdigit);
}

bool validarNombreApellido(const string& nombre) {
    if (nombre.length() < 2) {
        return false;
    }
    return all_of(nombre.begin(), nombre.end(), ::isalpha);
}

bool validarTrabajo(const string& nombreTrabajo) {
    return !nombreTrabajo.empty() && all_of(nombreTrabajo.begin(), nombreTrabajo.end(), ::isalpha);
}

string cifrarContrasena(const string& contrasena) {
    string cifrada;
    for (char c : contrasena) {
        if (isalpha(c)) {
            if (islower(c)) {
                cifrada += (c - 'a' + 2) % 26 + 'a';
            } else {
                cifrada += (c - 'A' + 2) % 26 + 'A';
            }
        } else if (isdigit(c)) {
            cifrada += (c - '0' + 2) % 10 + '0';
        }
    }

    if (cifrada.find_first_of("0123456789") == string::npos) {
        cifrada += '3';
    }

    return cifrada;
}

string descifrarContrasena(const string& cifrada) {
    string contrasena;
    string cifrada_sin_3 = cifrada;

    if (cifrada.back() == '3' && cifrada.find_first_of("0123456789") == cifrada.size() - 1) {
        cifrada_sin_3.pop_back();
    }

    for (char c : cifrada_sin_3) {
        if (isalpha(c)) {
            if (islower(c)) {
                contrasena += (c - 'a' - 4 + 26) % 26 + 'a';
            } else {
                contrasena += (c - 'A' - 4 + 26) % 26 + 'A';
            }
        } else if (isdigit(c)) {
            contrasena += (c - '0' - 2 + 10) % 10 + '0';
        }
    }

    return contrasena;
}

string generarCorreo(map<string, int>& correosExistentes, const string& nombre1, const string& nombre2, const string& apellido) {
    string correoBase;
    correoBase += tolower(nombre1[0]);
    if (!nombre2.empty()) {
        correoBase += tolower(nombre2[0]);
    }

    string apellidoMin = apellido;
    transform(apellidoMin.begin(), apellidoMin.end(), apellidoMin.begin(), ::tolower);

    correoBase += apellidoMin;

    string correo = correoBase;
    if (correosExistentes[correoBase] > 0) {
        correo += to_string(correosExistentes[correoBase]);
    }
    correosExistentes[correoBase]++;

    correo += "@espe.edu.ec";

    return correo;
}

string generarContrasena(map<string, int>& contrasenasExistentes, const string& nombre1, const string& nombre2, const string& apellido) {
    string claveBase;
    claveBase += tolower(nombre1[0]);
    if (!nombre2.empty()) {
        claveBase += tolower(nombre2[0]);
    }

    string apellidoMin = apellido;
    transform(apellidoMin.begin(), apellidoMin.end(), apellidoMin.begin(), ::tolower);

    claveBase += apellidoMin;

    string clave = claveBase;
    if (contrasenasExistentes[claveBase] > 0) {
        clave += to_string(contrasenasExistentes[claveBase]);
    }
    contrasenasExistentes[claveBase]++;

    return clave;
}

string generarIDEmpleado(int& ultimoID) {
    ultimoID++;
    ostringstream oss;
    oss << "emp_" << setw(4) << setfill('0') << ultimoID;
    return oss.str();
}

bool validarSueldo(const string& sueldoStr) {
    int puntoCount = 0;
    for (char c : sueldoStr) {
        if (!isdigit(c)) {
            if (c == '.' || c == ',') {
                puntoCount++;
                if (puntoCount > 1) {
                    return false;
                }
            } else {
                return false;
            }
        }
    }
    return true;
}

double pedirSueldo() {
    string sueldoStr;
    while (true) {
        cout << "Ingrese el sueldo: ";
        cin >> sueldoStr;
        if (validarSueldo(sueldoStr)) {
            replace(sueldoStr.begin(), sueldoStr.end(), ',', '.');
            return stod(sueldoStr);
        } else {
            cout << "Sueldo inválido. Ingrese un número válido." << endl;
        }
    }
}

void agregarEmpleado(ListaDobleEnlazada& empleados, map<string, int>& correosExistentes, map<string, int>& contrasenasExistentes, set<string>& cedulasExistentes, int& ultimoID) {
    string cedula, nombre1, nombre2, apellido, correo, clave, claveCifrada;
    double sueldo;
    string nombreTrabajo;

    cout << "Ingrese la cédula: ";
    cin >> cedula;

    if (!validarCedula(cedula) || cedulasExistentes.find(cedula) != cedulasExistentes.end()) {
        cout << "Cédula inválida o ya existe." << endl;
        return;
    }

    cout << "Ingrese el primer nombre: ";
    cin >> nombre1;
    if (!validarNombreApellido(nombre1)) {
        cout << "Nombre inválido." << endl;
        return;
    }

    cout << "Ingrese el segundo nombre (opcional): ";
    cin >> nombre2;
    if (!nombre2.empty() && !validarNombreApellido(nombre2)) {
        cout << "Segundo nombre inválido." << endl;
        return;
    }

    cout << "Ingrese el apellido: ";
    cin >> apellido;
    if (!validarNombreApellido(apellido)) {
        cout << "Apellido inválido." << endl;
        return;
    }

    correo = generarCorreo(correosExistentes, nombre1, nombre2, apellido);
    clave = generarContrasena(contrasenasExistentes, nombre1, nombre2, apellido);
    claveCifrada = cifrarContrasena(clave);
    string idEmpleado = generarIDEmpleado(ultimoID);

    Empleado* nuevoEmpleado = new Empleado(idEmpleado, cedula, nombre1, nombre2, apellido, correo, clave, claveCifrada);

    cout << "Ingrese el nombre del trabajo: ";
    cin >> nombreTrabajo;
    if (!validarTrabajo(nombreTrabajo)) {
        cout << "Nombre del trabajo inválido." << endl;
        return;
    }
    sueldo = pedirSueldo();
    nuevoEmpleado->agregarTrabajo(nombreTrabajo, sueldo);

    empleados.agregar(nuevoEmpleado);
    cedulasExistentes.insert(cedula);

    cout << "Empleado agregado exitosamente." << endl;
}

void agregarTrabajoEmpleado(ListaDobleEnlazada& empleados) {
    string cedula;
    cout << "Ingrese la cédula del empleado: ";
    cin >> cedula;

    Empleado* empleado = empleados.buscarPorCedula(cedula);
    if (!empleado) {
        cout << "Empleado no encontrado." << endl;
        return;
    }

    string nombreTrabajo;
    double sueldo;
    cout << "Ingrese el nombre del nuevo trabajo: ";
    cin >> nombreTrabajo;
    if (!validarTrabajo(nombreTrabajo)) {
        cout << "Nombre del trabajo inválido." << endl;
        return;
    }
    sueldo = pedirSueldo();
    empleado->agregarTrabajo(nombreTrabajo, sueldo);

    empleado->ordenarSueldos();

    cout << "Nuevo trabajo agregado y sueldos ordenados:" << endl;
    for (const auto& trabajo : empleado->trabajos) {
        cout << trabajo.nombre << ": " << fixed << setprecision(2) << trabajo.sueldo << endl;
    }
}

void buscarEmpleadoPorCedula(ListaDobleEnlazada& empleados) {
    string cedula;
    cout << "Ingrese la cédula del empleado a buscar: ";
    cin >> cedula;

    Empleado* empleado = empleados.buscarPorCedula(cedula);
    if (!empleado) {
        cout << "Empleado no encontrado." << endl;
        return;
    }

    cout << "Empleado encontrado: " << empleado->nombre1 << " " << empleado->apellido << endl;
    cout << "Trabajos y sueldos actuales:" << endl;
    for (const auto& trabajo : empleado->trabajos) {
        cout << trabajo.nombre << ": " << fixed << setprecision(2) << trabajo.sueldo << endl;
    }

    string nombreTrabajo;
    double nuevoSueldo;
    cout << "Ingrese el nombre del nuevo trabajo: ";
    cin >> nombreTrabajo;
    if (!validarTrabajo(nombreTrabajo)) {
        cout << "Nombre del trabajo inválido." << endl;
        return;
    }
    nuevoSueldo = pedirSueldo();
    empleado->agregarTrabajo(nombreTrabajo, nuevoSueldo);

    empleado->ordenarSueldos();
    cout << "Sueldo actualizado y trabajos ordenados:" << endl;
    for (const auto& trabajo : empleado->trabajos) {
        cout << trabajo.nombre << ": " << fixed << setprecision(2) << trabajo.sueldo << endl;
    }
}

void mostrarMenu() {
    ListaDobleEnlazada empleados;
    map<string, int> correosExistentes;
    map<string, int> contrasenasExistentes;
    set<string> cedulasExistentes;
    int ultimoID = 0;

    string rutaArchivo = "empleados.txt";
    cargarDatosExistentes(rutaArchivo, correosExistentes, contrasenasExistentes, cedulasExistentes, empleados, ultimoID);

    int opcion;
    do {
        cout << "1. Agregar nuevo empleado" << endl;
       // cout << "2. Buscar empleado por cédula y actualizar sueldo" << endl;
       cout <<"2. EN PROCESO...."<<endl;
        cout << "3. Agregar nuevo trabajo a un empleado" << endl;
        cout << "4. Salir" << endl;
        cout << "Seleccione una opción: ";
        cin >> opcion;

        switch (opcion) {
            case 1:
                agregarEmpleado(empleados, correosExistentes, contrasenasExistentes, cedulasExistentes, ultimoID);
                empleados.guardarEnArchivo(rutaArchivo);
                break;
            case 2:
                buscarEmpleadoPorCedula(empleados);
                empleados.guardarEnArchivo(rutaArchivo);
                break;
            case 3:
                agregarTrabajoEmpleado(empleados);
                empleados.guardarEnArchivo(rutaArchivo);
                break;
            case 4:
                cout << "Saliendo del programa." << endl;
                break;
            default:
                cout << "Opción inválida. Intente nuevamente." << endl;
                break;
        }
    } while (opcion != 4);
}

int main() {
    mostrarMenu();
    return 0;
}
