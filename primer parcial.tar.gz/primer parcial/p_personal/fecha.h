/***********************************************************************
 * Module:  fecha.h
 * Author:  jhoan
 * Modified: martes, 14 de mayo de 2024 22:14:18
 * Purpose: Declaration of the class fecha
 ***********************************************************************/

#if !defined(__diagrama5_fecha_h)
#define __diagrama5_fecha_h

class fecha
{
public:
   int getDia(void);
   void setDia(int newDia);
   int getMes(void);
   void setMes(int newMes);
   int getAnio(void);
   void setAnio(int newAnio);
   fecha();
   ~fecha();

protected:
private:
   int dia;
   int mes;
   int anio;


};

#endif