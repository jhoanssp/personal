#include <iostream>
#include "funciones.h"
using namespace std;

int main(int argc, char *argv[])
{

    prinl("hola mundo");

    system("pause");
    return 0;

}