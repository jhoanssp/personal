#include <iostream>
using namespace std;
int main(){

//std::cout <<"hola mundo";
cout <<"hola mundo \n";
int a=10;
cout<<a;
const float gravedad = 9.8;
float pepe;
cout<<a*gravedad;
cout<<"ingrese un numero";
cin>>pepe;
cout<<pepe;
int b=5;
int c=6;
if(a>b){
cout<<"hola";

}
return 0;
}