#include <iostream>
#include <string>
using namespace std;

void prinl(string str)
{

    cout<<str<<endl;

}