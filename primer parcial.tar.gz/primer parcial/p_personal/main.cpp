#include <iostream>
#include "tarjeta_credito.h" // Incluimos el encabezado de la clase tarjeta_credito
#include "fecha.h" // Incluimos el encabezado de la clase fecha

int main() {
    // Creamos una instancia de tarjeta_credito
    tarjeta_credito tarjeta;

    // Configuramos algunos valores para la tarjeta
    tarjeta.setNombre("Propietario de la Tarjeta");
    tarjeta.setCodigo_tarjeta("1234 5678 9012 3456");
    tarjeta.setCodigo_cvv(123);
    
    // Creamos instancias de fecha para la fecha de emisión y caducidad
    fecha fechaEmision;
    fecha fechaCaducidad;

    fechaEmision.setDia(1);
    fechaEmision.setMes(1);
    fechaEmision.setAnio(2024);

    fechaCaducidad.setDia(31);
    fechaCaducidad.setMes(12);
    fechaCaducidad.setAnio(2026);

    tarjeta.setFecha_emision(fechaEmision);
    tarjeta.setFecha_caducidad(fechaCaducidad);

    // Mostramos los detalles de la tarjeta
    std::cout << "Nombre: " << tarjeta.getNombre() << std::endl;
    std::cout << "Número de Tarjeta: " << tarjeta.getCodigo_tarjeta() << std::endl;
    std::cout << "Fecha de Emisión: " << tarjeta.getFecha_emision().getDia() << "/" << tarjeta.getFecha_emision().getMes() << "/" << tarjeta.getFecha_emision().getAnio() << std::endl;
    std::cout << "Fecha de Caducidad: " << tarjeta.getFecha_caducidad().getDia() << "/" << tarjeta.getFecha_caducidad().getMes() << "/" << tarjeta.getFecha_caducidad().getAnio() << std::endl;
    std::cout << "Código CVV: " << tarjeta.getCodigo_cvv() << std::endl;

    return 0;
}
