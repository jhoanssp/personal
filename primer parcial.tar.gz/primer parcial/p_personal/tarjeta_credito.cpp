/***********************************************************************
 * Module:  tarjeta_credito.cpp
 * Author:  jhoan
 * Modified: martes, 14 de mayo de 2024 22:14:03
 * Purpose: Implementation of the class tarjeta_credito
 ***********************************************************************/

#include "tarjeta_credito.h"
#include <string>

////////////////////////////////////////////////////////////////////////
// Name:       tarjeta_credito::getNombre()
// Purpose:    Implementation of tarjeta_credito::getNombre()
// Return:     std::string
////////////////////////////////////////////////////////////////////////

std::string tarjeta_credito::getNombre(void)
{
   return Nombre;
}

////////////////////////////////////////////////////////////////////////
// Name:       tarjeta_credito::setNombre(std::string newNombre)
// Purpose:    Implementation of tarjeta_credito::setNombre()
// Parameters:
// - newNombre
// Return:     void
////////////////////////////////////////////////////////////////////////

void tarjeta_credito::setNombre(std::string newNombre)
{
   Nombre = newNombre;
}

////////////////////////////////////////////////////////////////////////
// Name:       tarjeta_credito::getCodigo_tarjeta()
// Purpose:    Implementation of tarjeta_credito::getCodigo_tarjeta()
// Return:     std::string
////////////////////////////////////////////////////////////////////////

std::string tarjeta_credito::getCodigo_tarjeta(void)
{
   return codigo_tarjeta;
}

////////////////////////////////////////////////////////////////////////
// Name:       tarjeta_credito::setCodigo_tarjeta(std::string newCodigo_tarjeta)
// Purpose:    Implementation of tarjeta_credito::setCodigo_tarjeta()
// Parameters:
// - newCodigo_tarjeta
// Return:     void
////////////////////////////////////////////////////////////////////////

void tarjeta_credito::setCodigo_tarjeta(std::string newCodigo_tarjeta)
{
   codigo_tarjeta = newCodigo_tarjeta;
}

////////////////////////////////////////////////////////////////////////
// Name:       tarjeta_credito::getFecha_emision()
// Purpose:    Implementation of tarjeta_credito::getFecha_emision()
// Return:     fecha
////////////////////////////////////////////////////////////////////////

fecha tarjeta_credito::getFecha_emision(void)
{
   return fecha_emision;
}

////////////////////////////////////////////////////////////////////////
// Name:       tarjeta_credito::setFecha_emision(fecha newFecha_emision)
// Purpose:    Implementation of tarjeta_credito::setFecha_emision()
// Parameters:
// - newFecha_emision
// Return:     void
////////////////////////////////////////////////////////////////////////

void tarjeta_credito::setFecha_emision(fecha newFecha_emision)
{
   fecha_emision = newFecha_emision;
}

////////////////////////////////////////////////////////////////////////
// Name:       tarjeta_credito::getFecha_caducidad()
// Purpose:    Implementation of tarjeta_credito::getFecha_caducidad()
// Return:     fecha
////////////////////////////////////////////////////////////////////////

fecha tarjeta_credito::getFecha_caducidad(void)
{
   return fecha_caducidad;
}

////////////////////////////////////////////////////////////////////////
// Name:       tarjeta_credito::setFecha_caducidad(fecha newFecha_caducidad)
// Purpose:    Implementation of tarjeta_credito::setFecha_caducidad()
// Parameters:
// - newFecha_caducidad
// Return:     void
////////////////////////////////////////////////////////////////////////

void tarjeta_credito::setFecha_caducidad(fecha newFecha_caducidad)
{
   fecha_caducidad = newFecha_caducidad;
}

////////////////////////////////////////////////////////////////////////
// Name:       tarjeta_credito::getCodigo_cvv()
// Purpose:    Implementation of tarjeta_credito::getCodigo_cvv()
// Return:     int
////////////////////////////////////////////////////////////////////////

int tarjeta_credito::getCodigo_cvv(void)
{
   return codigo_cvv;
}

////////////////////////////////////////////////////////////////////////
// Name:       tarjeta_credito::setCodigo_cvv(int newCodigo_cvv)
// Purpose:    Implementation of tarjeta_credito::setCodigo_cvv()
// Parameters:
// - newCodigo_cvv
// Return:     void
////////////////////////////////////////////////////////////////////////

void tarjeta_credito::setCodigo_cvv(int newCodigo_cvv)
{
   codigo_cvv = newCodigo_cvv;
}

////////////////////////////////////////////////////////////////////////
// Name:       tarjeta_credito::tarjeta_credito()
// Purpose:    Implementation of tarjeta_credito::tarjeta_credito()
// Return:     
////////////////////////////////////////////////////////////////////////

tarjeta_credito::tarjeta_credito()
{
}

////////////////////////////////////////////////////////////////////////
// Name:       tarjeta_credito::~tarjeta_credito()
// Purpose:    Implementation of tarjeta_credito::~tarjeta_credito()
// Return:     
////////////////////////////////////////////////////////////////////////

tarjeta_credito::~tarjeta_credito()
{
   // TODO : implement
}