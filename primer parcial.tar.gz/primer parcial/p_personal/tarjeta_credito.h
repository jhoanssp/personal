/***********************************************************************
 * Module:  tarjeta_credito.h
 * Author:  jhoan
 * Modified: martes, 14 de mayo de 2024 22:14:03
 * Purpose: Declaration of the class tarjeta_credito
 ***********************************************************************/

#if !defined(__diagrama5_tarjeta_credito_h)
#define __diagrama5_tarjeta_credito_h

#include "fecha.h"

class tarjeta_credito
{
public:
   std::string getNombre(void);
   void setNombre(std::string newNombre);
   std::string getCodigo_tarjeta(void);
   void setCodigo_tarjeta(std::string newCodigo_tarjeta);
   fecha getFecha_emision(void);
   void setFecha_emision(fecha newFecha_emision);
   fecha getFecha_caducidad(void);
   void setFecha_caducidad(fecha newFecha_caducidad);
   int getCodigo_cvv(void);
   void setCodigo_cvv(int newCodigo_cvv);
   tarjeta_credito();
   ~tarjeta_credito();

protected:
private:
   std::string Nombre;
   std::string codigo_tarjeta;
   fecha fecha_emision;
   fecha fecha_caducidad;
   int codigo_cvv;


};

#endif