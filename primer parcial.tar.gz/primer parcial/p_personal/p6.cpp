#include <iostream>
using namespace std;

class Pokemon//clases
{
public:
   string nombre;
   float peso; /* data */
public://metodos
    Pokemon(string , float);
    void Saludo();
};

Pokemon::Pokemon(string _nombre,float _peso)
{
    nombre = _nombre;
    peso = _peso;
}

void Pokemon::Saludo()
{
    cout << "Hola soy " << nombre << " y peso " << peso << endl;
}
//clase hija
class Pokemonfuego : public Pokemon
{
public:
    int vida;
    char genero;
public:
    Pokemonfuego(string,float,int,char);
    void MostrarPokemon();
};

Pokemonfuego::Pokemonfuego(string _nombre, float _peso, int _vida, char _genero) : Pokemon(_nombre, _peso)
{
    vida = _vida;
    genero = _genero;
}

void Pokemonfuego::MostrarPokemon()
{
    cout<< "Hola soy "<< vida << " y peso " << genero << endl;
}


int main(){
    
    Pokemonfuego pokemon1("pika",0.80,45,'F');
    pokemon1.MostrarPokemon();

    return 0;
}

