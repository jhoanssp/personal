/*hola mundo*/
#include <iostream>
using namespace std;

int main(){
    cout<< "hola mundo \n";
    int letra = 2;
    long frande=34;
    float flotante= 3.4;
    double doble = 5.4543;
    long double doblel=345.454545;

    char caracter = 'S', car2='t';
    char cadena[]="hola";
    char cadena2[100]="adios";
    bool b1 = false, b2 = true;
    return 0;
}

