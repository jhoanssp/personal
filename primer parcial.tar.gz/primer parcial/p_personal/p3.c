#include <stdio.h>
int main(int argc, char const *argv[])
{
    int num;
    printf("ingrese un entero");
    scanf("%d", &num);
    printf("se ingreso un %d", num);
    return 0;
}
