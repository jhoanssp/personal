#include <iostream>
using namespace std;

struct pokemon{

    char nombre[50];
    char tipo[50];
    float peso;

}pokemon1;

int main(){

cout<<"Ingrese el nombre: "<<"\n";
cin.getline(pokemon1.nombre,50,'\n');
cout<<"Ingrese el tipo: "<<"\n";
cin.getline(pokemon1.tipo,50,'\n');
cout<<"Ingrese el npeso: "<<"\n";
cin>>pokemon1.peso;

cout<<"nombre: "<<pokemon1.nombre<<"\n";
cout<<"tipo "<<pokemon1.tipo<<"\n";
cout<<"peso: "<<pokemon1.peso<<"\n";

}
