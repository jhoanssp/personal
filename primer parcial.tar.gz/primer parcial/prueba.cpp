/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
TEMA: prueba
AUTOR: Jhoan Salazar
FECHA DE CREACION: 31/05/2024
FECHA DE ULTIMA MODIFICACION:31/05/2024

*/

//lista enlazada simple

#include <iostream>
using namespace std;

// Definición de un nodo
struct Nodo {
    int dato;
    Nodo* siguiente;
};

int sumaDigitos(int numero) {
    int suma = 0;
    while (numero != 0) {
        suma += numero % 10;
        numero /= 10;
    }
    return suma;
}


// Función para insertar un nuevo nodo al inicio de la lista
void insertar(Nodo** cabeza, int dato) {
    Nodo* nuevoNodo = new Nodo();
    nuevoNodo->dato = dato;
    nuevoNodo->siguiente = *cabeza;
    *cabeza = nuevoNodo;
}

// Función para imprimir la lista
void imprimirLista(Nodo* nodo) {
    while (nodo != nullptr) {
        cout << nodo->dato << " ";
        nodo = nodo->siguiente;
    }
}

int main() {
    Nodo* cabeza = nullptr;
        //labda
    auto suma = [&](Nodo*Nodo) {

        imprimirLista(cabeza);
        return imprimirLista;
    };

 
    
    // Llamamos a la función anónima y mostramos el resultado

    insertar(&cabeza, 434);
    insertar(&cabeza, 884);
    insertar(&cabeza, 321);

    cout << "Lista enlazada simple: \n";
    imprimirLista(cabeza);
    int resultado = sumaDigitos(imprimirLista(Nodo));
    cout<<"\n";
   cout<<"la suma es "<< resultado;


    return 0;
}
