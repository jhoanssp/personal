


#include "CarRegistry.h"
#include <iostream>
#include <string>
#include <filesystem>
#include <regex>

std::string obtenerRutaDescargas() {
    std::string ruta = "/home/" + std::string(getenv("USER")) + "/Downloads/proyecto_P1";
    std::filesystem::create_directories(ruta);
    return ruta + "/car_registry.txt";
}

bool validarCedula(const std::string& cedula) {
    return std::regex_match(cedula, std::regex("\\d{1,10}"));
}

int main() {
    CarRegistry registro;
    int opcion;

    do {
        std::cout << "\n1. Insertar un nuevo registro\n";
        std::cout << "2. Eliminar un registro\n";
        std::cout << "3. Buscar un registro por placa\n";
        std::cout << "4. Buscar registros por cédula\n";
        std::cout << "5. Mostrar todos los registros\n";
        std::cout << "6. Salir\n";
        std::cout << "Seleccione una opción: ";
        std::cin >> opcion;
        std::cin.ignore();  // Ignorar el salto de línea dejado en el buffer

        if (opcion == 1) {
            std::string nombre, placa, cedula;
            int edad;
            std::cout << "Ingrese el nombre y apellido: ";
            std::getline(std::cin, nombre);
            std::cout << "Ingrese la edad: ";
            std::cin >> edad;
            std::cin.ignore();  // Ignorar el salto de línea dejado en el buffer
            std::cout << "Ingrese la placa: ";
            std::getline(std::cin, placa);
            std::cout << "Ingrese la cédula (máximo 10 dígitos): ";
            std::getline(std::cin, cedula);

            if (validarCedula(cedula)) {
                registro.insertar(nombre, edad, placa, cedula);
            } else {
                std::cout << "Cédula inválida. Debe contener solo números y hasta 10 dígitos." << std::endl;
            }
        } else if (opcion == 2) {
            std::string placa, cedula;
            std::cout << "Ingrese la cédula: ";
            std::getline(std::cin, cedula);
            std::cout << "Ingrese la placa del registro a eliminar: ";
            std::getline(std::cin, placa);
            registro.eliminar(cedula, placa);
        } else if (opcion == 3) {
            std::string placa, cedula;
            std::cout << "Ingrese la cédula: ";
            std::getline(std::cin, cedula);
            std::cout << "Ingrese la placa del registro a buscar: ";
            std::getline(std::cin, placa);
            CarNode* car = registro.buscar(cedula, placa);
            if (car) {
                std::cout << "Encontrado: Nombre: " << car->nombre << ", Edad: " << car->edad << ", Placa: " << car->placa << ", Cédula: " << car->cedula << std::endl;
            } else {
                std::cout << "No encontrado" << std::endl;
            }
        } else if (opcion == 4) {
            std::string cedula;
            std::cout << "Ingrese la cédula para buscar sus registros: ";
            std::getline(std::cin, cedula);
            if (validarCedula(cedula)) {
                registro.buscarPorCedula(cedula);
            } else {
                std::cout << "Cédula inválida. Debe contener solo números y hasta 10 dígitos." << std::endl;
            }
        } else if (opcion == 5) {
            registro.mostrar();
        }
    } while (opcion != 6);

    return 0;
}
