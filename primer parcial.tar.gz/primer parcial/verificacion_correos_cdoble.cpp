
#include <iostream>
#include <sstream>
#include <fstream>
#include <algorithm>
#include <map>
#include <set>
#include <vector>
#include <iomanip>
#include <limits>
#include <cstring>
#include <stdexcept>

using namespace std;

class Persona {
public:
    string cedula;
    string nombre1;
    string nombre2;
    string apellido;
    string correo;
};

class Clave {
public:
    string clave;
    string claveCifrada;
};

class Empleado : public Persona {
public:
    string idEmpleado;
    double sueldo;
    Clave clave;
};

class Nodo {
public:
    Empleado empleado;
    Nodo* siguiente;
    Nodo* anterior;

    Nodo(Empleado empleado) {
        this->empleado = empleado;
        this->siguiente = nullptr;
        this->anterior = nullptr;
    }
};

class ListaDobleEnlazada {
private:
    Nodo* cabeza;
public:
    ListaDobleEnlazada() {
        cabeza = nullptr;
    }

    void anexar(Empleado empleado) {
        Nodo* nuevoNodo = new Nodo(empleado);
        if (!cabeza) {
            cabeza = nuevoNodo;
            return;
        }
        Nodo* temp = cabeza;
        while (temp->siguiente) {
            temp = temp->siguiente;
        }
        temp->siguiente = nuevoNodo;
        nuevoNodo->anterior = temp;
    }

    Empleado* buscarPorCedula(const string& cedula) {
        Nodo* temp = cabeza;
        while (temp) {
            if (temp->empleado.cedula == cedula) {
                return &temp->empleado;
            }
            temp = temp->siguiente;
        }
        return nullptr;
    }

    void guardarEnArchivo(const string& filePath) {
        ofstream archivo(filePath);
        if (archivo.is_open()) {
            Nodo* temp = cabeza;
            while (temp) {
                archivo << temp->empleado.idEmpleado << endl;
                archivo << temp->empleado.cedula << endl;
                archivo << temp->empleado.nombre1 << endl;
                archivo << temp->empleado.nombre2 << endl;
                archivo << temp->empleado.apellido << endl;
                archivo << temp->empleado.correo << endl;
                archivo << temp->empleado.clave.clave << endl;
                archivo << temp->empleado.clave.claveCifrada << endl;
                archivo << fixed << setprecision(2) << temp->empleado.sueldo << endl;
                temp = temp->siguiente;
            }
            archivo.close();
        } else {
            cout << "No se pudo abrir el archivo para escribir." << endl;
        }
    }

    void cargarDatosExistentes(const string& filePath, map<string, int>& correosExistentes, map<string, int>& contrasenasExistentes, set<string>& cedulasRegistradas, int& ultimoID) {
        ifstream archivo(filePath);
        if (archivo.is_open()) {
            string linea;
            while (getline(archivo, linea)) {
                Empleado empleado;
                empleado.idEmpleado = linea;

                getline(archivo, empleado.cedula);
                cedulasRegistradas.insert(empleado.cedula);

                getline(archivo, empleado.nombre1);
                getline(archivo, empleado.nombre2);
                getline(archivo, empleado.apellido);

                getline(archivo, empleado.correo);
                correosExistentes[empleado.correo.substr(0, empleado.correo.find('@'))]++;

                getline(archivo, empleado.clave.clave);
                getline(archivo, empleado.clave.claveCifrada);
                contrasenasExistentes[empleado.clave.clave]++;

                getline(archivo, linea);
                empleado.sueldo = stod(linea);

                anexar(empleado);

                stringstream ss(empleado.idEmpleado.substr(5));
                int id;
                ss >> id;
                ultimoID = max(ultimoID, id);
            }
            archivo.close();
        } else {
            cout << "No se pudo abrir el archivo para leer." << endl;
        }
    }
};

// Función para validar nombres y apellidos
bool validarNombreApellido(const string& nombre) {
    if (nombre.length() < 2) return false;
    for (char c : nombre) {
        if (!isalpha(c)) return false;
    }
    return true;
}

// Función para validar la cédula (debe ser numérica y de 10 dígitos)
bool validarCedula(const string& cedula) {
    if (cedula.length() != 10) return false;
    for (char c : cedula) {
        if (!isdigit(c)) return false;
    }
    return true;
}

// Función para cifrar la contraseña
string cifrarContrasena(const string& contrasena) {
    string cifrada;
    bool tieneNumeros = false;
    for (char c : contrasena) {
        if (isalpha(c)) {
            char base = islower(c) ? 'a' : 'A';
            cifrada += base + (c - base + 2) % 26;
        } else if (isdigit(c)) {
            cifrada += '0' + (c - '0' + 2) % 10;
            tieneNumeros = true;
        } else {
            cifrada += c;
        }
    }
    if (!tieneNumeros) cifrada += '2';
    return cifrada;
}


// Función para descifrar la contraseña
string descifrarContrasena(const string& contrasenaCifrada) {
    string descifrada;
    for (size_t i = 0; i < contrasenaCifrada.length(); ++i) {
        char c = contrasenaCifrada[i];
        if (isalpha(c)) {
            char base = islower(c) ? 'a' : 'A';
            descifrada += base + (c - base - 2 + 26) % 26;
        } else if (isdigit(c)) {
            descifrada += '0' + (c - '0' - 2 + 10) % 10;
        } else {
            descifrada += c;
        }
    }
    if (descifrada.back() == '2') descifrada.pop_back();
    return descifrada;
}

// Función para generar un correo único
string generarCorreo(map<string, int>& correosExistentes, const string& nombre1, const string& nombre2, const string& apellido) {
    string correoBase;
    correoBase += tolower(nombre1[0]);
    if (!nombre2.empty()) correoBase += tolower(nombre2[0]);
    correoBase += apellido;

    if (correosExistentes[correoBase] > 0) {
        correoBase += to_string(correosExistentes[correoBase]);
    }
    correosExistentes[correoBase]++;

    return correoBase + "@espe.edu.ec";
}

// Función para generar una contraseña única
string generarContrasena(map<string, int>& contrasenasExistentes, const string& nombre1, const string& nombre2, const string& apellido) {
    string contrasenaBase;
    contrasenaBase += apellido.back();
    if (!nombre2.empty()) contrasenaBase += nombre2[0];
    contrasenaBase += nombre1[0];
    string apellidoReversed = apellido.substr(0, apellido.length() - 1);
    reverse(apellidoReversed.begin(), apellidoReversed.end());
    contrasenaBase += apellidoReversed;

    if (contrasenasExistentes[contrasenaBase] > 0) {
        contrasenaBase += to_string(contrasenasExistentes[contrasenaBase]);
    }
    contrasenasExistentes[contrasenaBase]++;

    return contrasenaBase;
}

// Función para generar un ID de empleado único
string generarIDEmpleado(int& ultimoID) {
    ultimoID++;
    stringstream ss;
    ss << "espe-" << setw(3) << setfill('0') << ultimoID;
    return ss.str();
}

// Función para validar el sueldo ingresado
bool validarSueldo(const string& sueldo) {
    bool puntoEncontrado = false;
    bool comaEncontrada = false;
    for (char c : sueldo) {
        if (isdigit(c)) {
            continue;
        } else if (c == '.') {
            if (puntoEncontrado || comaEncontrada) {
                return false;
            }
            puntoEncontrado = true;
        } else if (c == ',') {
            if (comaEncontrada || puntoEncontrado) {
                return false;
            }
            comaEncontrada = true;
        } else {
            return false;
        }
    }
    return true;
}

// Función para solicitar el sueldo al usuario y validarlo
double pedirSueldo() {
    string sueldoStr;
    do {
        cout << "Ingrese el sueldo (solo un punto o una coma permitidos): ";
        getline(cin, sueldoStr);
        if (!validarSueldo(sueldoStr)) {
            cout << "Entrada inválida. Asegúrese de ingresar un número válido con solo un punto o una coma." << endl;
        }
    } while (!validarSueldo(sueldoStr));

    replace(sueldoStr.begin(), sueldoStr.end(), ',', '.'); // Reemplazar coma por punto para convertir a double
    return stod(sueldoStr);
}

// Función para agregar un nuevo empleado a la lista
void agregarEmpleado(ListaDobleEnlazada& empleados, map<string, int>& correosExistentes, map<string, int>& contrasenasExistentes, set<string>& cedulasRegistradas, int& ultimoID) {
    string primerNombre, segundoNombre, primerApellido, cedula;
    double sueldo;

    cout << "\nCREACIÓN DE NUEVO EMPLEADO" << endl;

    // Solicitar y validar el primer nombre
    do {
        cout << "\nIngrese el primer nombre (mínimo 2 letras): ";
        getline(cin, primerNombre);
    } while (!validarNombreApellido(primerNombre));

    // Solicitar el segundo nombre
    do {
    cout << "Ingrese el segundo nombre (o dejar vacío si no tiene): ";
    getline(cin, segundoNombre);
    } while (!validarNombreApellido(segundoNombre));

    // Solicitar y validar el primer apellido
    do {
        cout << "Ingrese el primer apellido (mínimo 2 letras): ";
        getline(cin, primerApellido);
    } while (!validarNombreApellido(primerApellido));

    // Solicitar y validar la cédula
    do {
        cout << "Ingrese la cédula (10 dígitos numéricos): ";
        getline(cin, cedula);
        if (!validarCedula(cedula)) {
            cout << "Cédula inválida. Debe tener 10 dígitos numéricos." << endl;
        } else if (cedulasRegistradas.count(cedula) > 0) {
            cout << "La cédula ya está registrada. Intente nuevamente." << endl;
        }
    } while (!validarCedula(cedula) || cedulasRegistradas.count(cedula) > 0);

    // Solicitar el sueldo y validarlo
    sueldo = pedirSueldo();

    // Generar correo y contraseña
    string correo = generarCorreo(correosExistentes, primerNombre, segundoNombre, primerApellido);
    string contrasena = generarContrasena(contrasenasExistentes, primerNombre, segundoNombre, primerApellido);
    string contrasenaCifrada = cifrarContrasena(contrasena);
    string contrasenadesCifrada=descifrarContrasena(contrasenaCifrada);

    // Generar ID de empleado
    string idEmpleado = generarIDEmpleado(ultimoID);

    // Crear y agregar el nuevo empleado a la lista
    Empleado nuevoEmpleado;
    nuevoEmpleado.idEmpleado = idEmpleado;
    nuevoEmpleado.cedula = cedula;
    nuevoEmpleado.nombre1 = primerNombre;
    nuevoEmpleado.nombre2 = segundoNombre;
    nuevoEmpleado.apellido = primerApellido;
    nuevoEmpleado.correo = correo;
    nuevoEmpleado.clave.clave = contrasena;
    nuevoEmpleado.clave.claveCifrada = contrasenaCifrada;
    nuevoEmpleado.sueldo = sueldo;

    empleados.anexar(nuevoEmpleado);
    cedulasRegistradas.insert(cedula);

    cout << "Empleado creado exitosamente.\n";
    cout << "ID Empleado: " << idEmpleado << "\nCorreo: " << correo << "\nContraseña: " << contrasena << "\nContraseña cifrada: " << contrasenaCifrada << "\nSueldo: " << fixed << setprecision(2) << sueldo << endl;
}

// Función para buscar y actualizar el sueldo de un empleado
void actualizarSueldo(ListaDobleEnlazada& empleados) {
    string cedula;
    cout << "\nACTUALIZACIÓN DE SUELDO" << endl;
    cout << "Ingrese la cédula del empleado: ";
    getline(cin, cedula);

    Empleado* empleado = empleados.buscarPorCedula(cedula);
    if (empleado) {
        cout << "Empleado encontrado: " << empleado->nombre1 << " " << empleado->apellido << endl;
        cout << "Sueldo actual: " << fixed << setprecision(2) << empleado->sueldo << endl;

        double nuevoSueldo = pedirSueldo();
        empleado->sueldo = nuevoSueldo;

        cout << "Sueldo actualizado exitosamente.\n";
    } else {
        cout << "No se encontró un empleado con la cédula ingresada." << endl;
    }
}

// Función para mostrar el menú y manejar la entrada del usuario
void mostrarMenu(ListaDobleEnlazada& empleados, map<string, int>& correosExistentes, map<string, int>& contrasenasExistentes, set<string>& cedulasRegistradas, int& ultimoID) {
    int opcion;
    do {
        cout << "\nMENU\n1. Crear nuevo empleado\n2. Actualizar sueldo de empleado\n3. Salir\nIngrese su opción: ";
        cin >> opcion;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        switch (opcion) {
        case 1:
            agregarEmpleado(empleados, correosExistentes, contrasenasExistentes, cedulasRegistradas, ultimoID);
            empleados.guardarEnArchivo("correosTGcdoble.txt");
            break;
        case 2:
            actualizarSueldo(empleados);
            empleados.guardarEnArchivo("correosTGcdoble.txt");
            break;
        case 3:
            cout << "Saliendo del programa..." << endl;
            break;
        default:
            cout << "Opción inválida. Intente nuevamente." << endl;
        }
    } while (opcion != 3);
}

// Función principal
int principal() {
    ListaDobleEnlazada empleados;
    map<string, int> correosExistentes;
    map<string, int> contrasenasExistentes;
    set<string> cedulasRegistradas;
    int ultimoID = 0;

    empleados.cargarDatosExistentes("correosTGcdoble.txt", correosExistentes, contrasenasExistentes, cedulasRegistradas, ultimoID);

    mostrarMenu(empleados, correosExistentes, contrasenasExistentes, cedulasRegistradas, ultimoID);

    return 0;
}

int main() {
    return principal();
}

