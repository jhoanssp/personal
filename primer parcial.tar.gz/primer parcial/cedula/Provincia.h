/***********************************************************************
 * Module:  Provincia.h
 * Author:  jhoan
 * Modified: s�bado, 11 de mayo de 2024 23:01:13
 * Purpose: Declaration of the class Provincia
 ***********************************************************************/

#if !defined(__cedula_ej2_Provincia_h)
#define __cedula_ej2_Provincia_h

class Provincia
{
public:
   int getId_provincia(void);
   void setId_provincia(int newId_provincia);
   std::string getNom_provincia(void);
   void setNom_provincia(std::string newNom_provincia);
   std::string getObservacion(void);
   void setObservacion(std::string newObservacion);
   Provincia();
   ~Provincia();

protected:
private:
   int id_provincia;
   std::string nom_provincia;
   std::string observacion;


};

#endif