/***********************************************************************
 * Module:  Pais.h
 * Author:  jhoan
 * Modified: s�bado, 11 de mayo de 2024 23:01:13
 * Purpose: Declaration of the class Pais
 ***********************************************************************/

#if !defined(__cedula_ej2_Pais_h)
#define __cedula_ej2_Pais_h

#include <Provincia.h>

class Pais
{
public:
   int getId_pais(void);
   void setId_pais(int newId_pais);
   std::string getNombre(void);
   void setNombre(std::string newNombre);
   std::string getObservacion(void);
   void setObservacion(std::string newObservacion);
   Provincia getProvincia(void);
   void setProvincia(Provincia newProvincia);
   Pais();
   ~Pais();

protected:
private:
   int id_pais;
   std::string nombre;
   std::string observacion;
   Provincia provincia;


};

#endif