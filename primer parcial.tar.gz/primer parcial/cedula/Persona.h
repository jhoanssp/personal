/***********************************************************************
 * Module:  Persona.h
 * Author:  jhoan
 * Modified: s�bado, 11 de mayo de 2024 23:01:13
 * Purpose: Declaration of the class Persona
 ***********************************************************************/

#if !defined(__cedula_ej2_Persona_h)
#define __cedula_ej2_Persona_h

#include <Pais.h>
#include <Fecha.h>

class Persona
{
public:
   std::string getNum_cedula(void);
   void setNum_cedula(std::string newNum_cedula);
   std::string getApellido(void);
   void setApellido(std::string newApellido);
   std::string getNombre(void);
   void setNombre(std::string newNombre);
   Pais getPais(void);
   void setPais(Pais newPais);
   Fecha getFecha_n(void);
   void setFecha_n(Fecha newFecha_n);
   enum getSexo(void);
   void setSexo(enum newSexo);
   Fecha getFecha_v(void);
   void setFecha_v(Fecha newFecha_v);
   enum getEstado_civil(void);
   void setEstado_civil(enum newEstado_civil);
   Fecha getFecha_emision(void);
   void setFecha_emision(Fecha newFecha_emision);
   std::string getDactilar(void);
   void setDactilar(std::string newDactilar);
   enum getTipo_sangre(void);
   void setTipo_sangre(enum newTipo_sangre);
   bool getDonante(void);
   void setDonante(bool newDonante);
   Persona();
   ~Persona();

protected:
private:
   std::string num_cedula;
   std::string apellido;
   std::string nombre;
   Pais pais;
   Fecha fecha_n;
   enum sexo;
   Fecha fecha_v;
   enum estado_civil;
   Fecha fecha_emision;
   std::string dactilar;
   enum tipo_sangre;
   bool donante;


};

#endif