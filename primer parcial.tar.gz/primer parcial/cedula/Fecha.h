/***********************************************************************
 * Module:  Fecha.h
 * Author:  jhoan
 * Modified: s�bado, 11 de mayo de 2024 23:01:13
 * Purpose: Declaration of the class Fecha
 ***********************************************************************/

#if !defined(__cedula_ej2_Fecha_h)
#define __cedula_ej2_Fecha_h

class Fecha
{
public:
   int getDia(void);
   void setDia(int newDia);
   int getMes(void);
   void setMes(int newMes);
   int getAnio(void);
   void setAnio(int newAnio);
   Fecha();
   ~Fecha();

protected:
private:
   int dia;
   int mes;
   int anio;


};

#endif