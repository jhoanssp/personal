/***********************************************************************
 * Module:  Provincia.cpp
 * Author:  jhoan
 * Modified: s�bado, 11 de mayo de 2024 23:01:13
 * Purpose: Implementation of the class Provincia
 ***********************************************************************/

#include "Provincia.h"

////////////////////////////////////////////////////////////////////////
// Name:       Provincia::getId_provincia()
// Purpose:    Implementation of Provincia::getId_provincia()
// Return:     int
////////////////////////////////////////////////////////////////////////

int Provincia::getId_provincia(void)
{
   return id_provincia;
}

////////////////////////////////////////////////////////////////////////
// Name:       Provincia::setId_provincia(int newId_provincia)
// Purpose:    Implementation of Provincia::setId_provincia()
// Parameters:
// - newId_provincia
// Return:     void
////////////////////////////////////////////////////////////////////////

void Provincia::setId_provincia(int newId_provincia)
{
   id_provincia = newId_provincia;
}

////////////////////////////////////////////////////////////////////////
// Name:       Provincia::getNom_provincia()
// Purpose:    Implementation of Provincia::getNom_provincia()
// Return:     std::string
////////////////////////////////////////////////////////////////////////

std::string Provincia::getNom_provincia(void)
{
   return nom_provincia;
}

////////////////////////////////////////////////////////////////////////
// Name:       Provincia::setNom_provincia(std::string newNom_provincia)
// Purpose:    Implementation of Provincia::setNom_provincia()
// Parameters:
// - newNom_provincia
// Return:     void
////////////////////////////////////////////////////////////////////////

void Provincia::setNom_provincia(std::string newNom_provincia)
{
   nom_provincia = newNom_provincia;
}

////////////////////////////////////////////////////////////////////////
// Name:       Provincia::getObservacion()
// Purpose:    Implementation of Provincia::getObservacion()
// Return:     std::string
////////////////////////////////////////////////////////////////////////

std::string Provincia::getObservacion(void)
{
   return observacion;
}

////////////////////////////////////////////////////////////////////////
// Name:       Provincia::setObservacion(std::string newObservacion)
// Purpose:    Implementation of Provincia::setObservacion()
// Parameters:
// - newObservacion
// Return:     void
////////////////////////////////////////////////////////////////////////

void Provincia::setObservacion(std::string newObservacion)
{
   observacion = newObservacion;
}

////////////////////////////////////////////////////////////////////////
// Name:       Provincia::Provincia()
// Purpose:    Implementation of Provincia::Provincia()
// Return:     
////////////////////////////////////////////////////////////////////////

Provincia::Provincia()
{
}

////////////////////////////////////////////////////////////////////////
// Name:       Provincia::~Provincia()
// Purpose:    Implementation of Provincia::~Provincia()
// Return:     
////////////////////////////////////////////////////////////////////////

Provincia::~Provincia()
{
   // TODO : implement
}