#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <regex>

using namespace std;

// Generador de placas
class GeneradorPlacas {
private:
    char letrasIniciales[24] = {'A', 'B', 'U', 'C', 'X', 'H', 'O', 'E', 'W', 'G', 'I', 'L', 'R', 'M', 'V', 'N', 'S', 'P', 'Q', 'K', 'T', 'Z', 'Y', 'J'};
    int indexInicial;
    string letras;
    int numero;

public:
    GeneradorPlacas() : indexInicial(0), letras("AA"), numero(1) {
        letras[0] = letrasIniciales[indexInicial];
    }

    void setIniciales(char letra1, char letra2, int num) {
        letras[0] = letra1;
        letras[1] = letra2;
        numero = num;
    }

    string generarPlaca() {
        string placa = letras + "-" + (numero < 10 ? "000" :
                                       numero < 100 ? "00" :
                                       numero < 1000 ? "0" : "") + to_string(numero);
        numero++;
        if (numero > 9999) {
            numero = 1;
            incrementarLetras();
        }
        return placa;
    }

    void guardarEstado(ofstream &archivo) {
        archivo << "PLACA_ESTADO: " << letras[0] << " " << letras[1] << " " << numero << endl;
    }

    void cargarEstado(ifstream &archivo) {
        string etiqueta;
        char letra1, letra2;
        int num;
        archivo >> etiqueta >> letra1 >> letra2 >> num;
        setIniciales(letra1, letra2, num);
    }

private:
    void incrementarLetras() {
        if (letras[1] < 'Z') {
            letras[1]++;
        } else {
            letras[1] = 'A';
            if (indexInicial < 23) {
                indexInicial++;
                letras[0] = letrasIniciales[indexInicial];
            } else {
                indexInicial = 0;
                letras[0] = letrasIniciales[indexInicial];
            }
        }
    }
};

// Clase Persona
class Persona {
private:
    string cedula;
    string nombre;
    string apellido;

public:
    Persona(string ced, string nom, string ape) : cedula(ced), nombre(nom), apellido(ape) {}

    string getCedula() { return cedula; }
    string getNombre() { return nombre; }
    string getApellido() { return apellido; }

    void setCedula(string ced) { cedula = ced; }
    void setNombre(string nom) { nombre = nom; }
    void setApellido(string ape) { apellido = ape; }
};

// Clase Vehiculo
class Vehiculo {
public:
    string placa;
    string marca;
    string modelo;
    string color;
    string tipo;

    Vehiculo* prev;
    Vehiculo* next;

    Vehiculo(string pla, string mar, string mod, string col, string tip) 
        : placa(pla), marca(mar), modelo(mod), color(col), tipo(tip), prev(nullptr), next(nullptr) {}
};

// Clase Fecha (composición de Persona)
class Fecha {
private:
    Persona* persona;
    Vehiculo* head;

public:
    Fecha(Persona* per) : persona(per), head(nullptr) {}

    Persona* getPersona() {
        return persona;
    }

    void agregarVehiculo(Vehiculo* nuevoVehiculo) {
        if (!head) {
            head = nuevoVehiculo;
            head->next = head;
            head->prev = head;
        } else {
            Vehiculo* tail = head->prev;
            tail->next = nuevoVehiculo;
            nuevoVehiculo->prev = tail;
            nuevoVehiculo->next = head;
            head->prev = nuevoVehiculo;
        }
    }

    Vehiculo* buscarVehiculo(string placa) {
        if (!head) return nullptr;

        Vehiculo* actual = head;
        do {
            if (actual->placa == placa) return actual;
            actual = actual->next;
        } while (actual != head);

        return nullptr;
    }

    void eliminarVehiculo(string placa) {
        if (!head) return;

        Vehiculo* vehiculoAEliminar = buscarVehiculo(placa);
        if (!vehiculoAEliminar) return;

        if (vehiculoAEliminar == head && vehiculoAEliminar->next == head) {
            head = nullptr;
        } else {
            Vehiculo* prev = vehiculoAEliminar->prev;
            Vehiculo* next = vehiculoAEliminar->next;

            prev->next = next;
            next->prev = prev;

            if (vehiculoAEliminar == head) {
                head = next;
            }
        }

        delete vehiculoAEliminar;
    }

    void mostrarVehiculos() {
        if (!head) {
            cout << "No hay vehículos registrados para " << persona->getNombre() << " " << persona->getApellido() << "." << endl;
            return;
        }

        Vehiculo* actual = head;
        do {
            cout << "Placa: " << actual->placa << ", Marca: " << actual->marca
                 << ", Modelo: " << actual->modelo << ", Color: " << actual->color
                 << ", Tipo: " << actual->tipo << endl;
            actual = actual->next;
        } while (actual != head);
    }

    void guardarDatos(ofstream &archivo) {
        archivo << "Cedula: " << persona->getCedula() << ", Nombre: " << persona->getNombre()
                << ", Apellido: " << persona->getApellido() << endl;

        if (!head) {
            archivo << "No hay vehículos registrados." << endl;
            return;
        }

        Vehiculo* actual = head;
        do {
            archivo << "    Placa: " << actual->placa << ", Marca: " << actual->marca
                    << ", Modelo: " << actual->modelo << ", Color: " << actual->color
                    << ", Tipo: " << actual->tipo << endl;
            actual = actual->next;
        } while (actual != head);
    }
};

// Mapa global para almacenar las personas y verificar cédulas duplicadas
map<string, Fecha*> registros;
GeneradorPlacas generadorPlacas;

// Función para cargar cédulas y vehículos desde el archivo
void cargarCedulasDesdeArchivo() {
    ifstream archivo("/home/kali/Downloads/proyectoGR.txt");
    if (!archivo.is_open()) {
        cout << "No se pudo abrir el archivo /home/kali/Downloads/proyectoGR.txt" << endl;
        return;
    }

    string linea;
    Persona* personaActual = nullptr;
    Fecha* fechaActual = nullptr;
    
    while (getline(archivo, linea)) {
        if (linea.substr(0, 7) == "Cedula:") {
            string cedula = linea.substr(8, 10);
            string nombre, apellido;
            size_t posNombre = linea.find("Nombre: ");
            size_t posApellido = linea.find(", Apellido: ");
            if (posNombre != string::npos && posApellido != string::npos) {
                nombre = linea.substr(posNombre + 8, posApellido - (posNombre + 8));
                apellido = linea.substr(posApellido + 11);
                personaActual = new Persona(cedula, nombre, apellido);
                fechaActual = new Fecha(personaActual);
                registros[cedula] = fechaActual;
            }
        } else if (linea.substr(0, 10) == "    Placa:" && fechaActual) {
            size_t posMarca = linea.find("Marca: ");
            size_t posModelo = linea.find(", Modelo: ");
            size_t posColor = linea.find(", Color: ");
            size_t posTipo = linea.find(", Tipo: ");
            if (posMarca != string::npos && posModelo != string::npos && posColor != string::npos && posTipo != string::npos) {
                string placa = linea.substr(11, posMarca - 12);
                string marca = linea.substr(posMarca + 7, posModelo - (posMarca + 7));
                string modelo = linea.substr(posModelo + 9, posColor - (posModelo + 9));
                string color = linea.substr(posColor + 8, posTipo - (posColor + 8));
                string tipo = linea.substr(posTipo + 7);

                Vehiculo* vehiculo = new Vehiculo(placa, marca, modelo, color, tipo);
                fechaActual->agregarVehiculo(vehiculo);
            }
        } else if (linea.substr(0, 13) == "PLACA_ESTADO:") {
            char letra1, letra2;
            int num;
            sscanf(linea.c_str(), "PLACA_ESTADO: %c %c %d", &letra1, &letra2, &num);
            generadorPlacas.setIniciales(letra1, letra2, num);
        }
    }

    archivo.close();
}

void guardarCedulasYVehiculosEnArchivo() {
    ofstream archivo("/home/kali/Downloads/proyectoGR.txt");
    if (!archivo.is_open()) {
        cout << "No se pudo abrir el archivo /home/kali/Downloads/proyectoGR.txt" << endl;
        return;
    }

    for (const auto& registro : registros) {
        registro.second->guardarDatos(archivo);
    }
    generadorPlacas.guardarEstado(archivo);

    archivo.close();
}

bool validarCedula(const string& cedula) {
    regex patron("^[0-9]{10}$");
    return regex_match(cedula, patron);
}

void registrarPersonaYVehiculo() {
    string cedula, nombre, apellido;
    cout << "Ingrese la cedula: ";
    cin >> cedula;

    if (!validarCedula(cedula)) {
        cout << "Cédula inválida. Asegúrese de que tenga exactamente 10 dígitos." << endl;
        return;
    }

    if (registros.find(cedula) != registros.end()) {
        Fecha* registroExistente = registros[cedula];
        Persona* personaExistente = registroExistente->getPersona();
        cout << "El usuario ya existe: " << personaExistente->getNombre() << " " << personaExistente->getApellido() << endl;

        string marca, modelo, color, tipo;
        string placa = generadorPlacas.generarPlaca();
        cout << "Placa generada automáticamente: " << placa << endl;
        cout << "Ingrese la marca del vehículo: ";
        cin >> marca;
        cout << "Ingrese el modelo del vehículo: ";
        cin >> modelo;
        cout << "Ingrese el color del vehículo: ";
        cin >> color;
        cout << "Ingrese el tipo del vehículo (camion, moto, carro): ";
        cin >> tipo;

        Vehiculo* vehiculo = new Vehiculo(placa, marca, modelo, color, tipo);
        registroExistente->agregarVehiculo(vehiculo);

        // Guardar en el archivo
        guardarCedulasYVehiculosEnArchivo();
        cout << "Datos guardados en /home/kali/Downloads/proyectoGR.txt" << endl;
        return;
    }

    cout << "Ingrese el nombre: ";
    cin >> nombre;
    cout << "Ingrese el apellido: ";
    cin >> apellido;

    Persona* persona = new Persona(cedula, nombre, apellido);
    Fecha* registro = new Fecha(persona);

    string marca, modelo, color, tipo;
    string placa = generadorPlacas.generarPlaca();
    cout << "Placa generada automáticamente: " << placa << endl;
    cout << "Ingrese la marca del vehículo: ";
    cin >> marca;
    cout << "Ingrese el modelo del vehículo: ";
    cin >> modelo;
    cout << "Ingrese el color del vehículo: ";
    cin >> color;
    cout << "Ingrese el tipo del vehículo (camion, moto, carro): ";
    cin >> tipo;

    Vehiculo* vehiculo = new Vehiculo(placa, marca, modelo, color, tipo);
    registro->agregarVehiculo(vehiculo);

    registros[cedula] = registro;

    // Guardar en el archivo
    guardarCedulasYVehiculosEnArchivo();
    cout << "Datos guardados en /home/kali/Downloads/proyectoGR.txt" << endl;
}

int main() {
    cargarCedulasDesdeArchivo(); // Cargar cédulas al inicio del programa

    int opcion;
    do {
        cout << "\nMenu:\n";
        cout << "1. Registrar persona y vehículo\n";
        cout << "2. Mostrar vehículos de una persona\n";
        cout << "3. Eliminar vehículo de una persona\n";
        cout << "4. Salir\n";
        cout << "Seleccione una opción: ";
        cin >> opcion;

        switch (opcion) {
            case 1:
                registrarPersonaYVehiculo();
                break;
            case 2: {
                string cedula;
                cout << "Ingrese la cedula: ";
                cin >> cedula;
                if (registros.find(cedula) != registros.end() && registros[cedula] != nullptr) {
                    registros[cedula]->mostrarVehiculos();
                } else {
                    cout << "Cédula no encontrada." << endl;
                }
                break;
            }
            case 3: {
                string cedula, placa;
                cout << "Ingrese la cedula: ";
                cin >> cedula;
                if (registros.find(cedula) != registros.end() && registros[cedula] != nullptr) {
                    cout << "Ingrese la placa del vehículo a eliminar: ";
                    cin >> placa;
                    registros[cedula]->eliminarVehiculo(placa);

                    // Guardar en el archivo
                    guardarCedulasYVehiculosEnArchivo();
                } else {
                    cout << "Cédula no encontrada." << endl;
                }
                break;
            }
            case 4:
                cout << "Saliendo del programa." << endl;
                break;
            default:
                cout << "Opción no válida." << endl;
                break;
        }
    } while (opcion != 4);

    // Limpiar memoria
    for (auto it = registros.begin(); it != registros.end(); ++it) {
        delete it->second;
    }

    return 0;
}
