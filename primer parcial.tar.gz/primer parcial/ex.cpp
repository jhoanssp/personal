#include <iostream>
#include <cctype>
#include <string>
#include <fstream>
#include <cstdlib>

using namespace std;

// Estructura para un nodo de la lista
struct Node {
    string name;
    string surname;
    Node* next;
};

// Función para validar que una cadena contenga solo letras
bool isValidName(const string& str) {
    for (char ch : str) {
        if (!isalpha(ch)) {
            return false;
        }
    }
    return true;
}

// Función para agregar un nodo a la lista
void addNode(Node*& head, const string& name, const string& surname) {
    Node* newNode = new Node();
    newNode->name = name;
    newNode->surname = surname;
    newNode->next = head;
    head = newNode;
}

// Función para mostrar la lista
void displayList(Node* head) {
    Node* temp = head;
    while (temp != nullptr) {
        cout << "Nombre: " << temp->name << ", Apellido: " << temp->surname << endl;
        temp = temp->next;
    }
}

// Función para guardar la lista en un archivo
void saveListToFile(Node* head, const string& filePath) {
    ofstream outFile(filePath);
    if (!outFile) {
        cerr << "Error opening file for writing." << endl;
        return;
    }

    Node* temp = head;
    while (temp != nullptr) {
        outFile << "Nombre: " << temp->name << ", Apellido: " << temp->surname << endl;
        temp = temp->next;
    }

    outFile.close();
}

// Función principal
int main() {
    Node* head = nullptr;
    string name, surname;
    char option;

    do {
        cout << "Ingrese el nombre: ";
        cin >> name;
        cout << "Ingrese el apellido: ";
        cin >> surname;

        // Validar entrada
        if (!isValidName(name) || !isValidName(surname)) {
            cout << "Error: Solo se permiten letras en el nombre y apellido." << endl;
        } else {
            addNode(head, name, surname);
        }

        cout << "¿Desea ingresar otro nombre? (s/n): ";
        cin >> option;

    } while (option == 's' || option == 'S');

    // Mostrar la lista
    displayList(head);

    // Guardar la lista en un archivo
    string homeDir = getenv("HOME");
    string filePath = homeDir + "/Downloads/pruebaexamen.txt";
    saveListToFile(head, filePath);

    // Liberar memoria
    while (head != nullptr) {
        Node* temp = head;
        head = head->next;
        delete temp;
    }

    cout << "La lista ha sido guardada en " << filePath << endl;

    return 0;
}
