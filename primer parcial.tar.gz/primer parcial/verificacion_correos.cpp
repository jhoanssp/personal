#include <iostream>
#include <sstream>
#include <algorithm>
#include <map>
#include <set>
#include <fstream>
#include <cctype>
#include <iomanip> // para setw y setfill
#include <limits>  // para numeric_limits
#include <cstring>

using namespace std;

class Clave {
public:
    string clave;

    Clave(string clave) {
        this->clave = clave;
    }
};

class Persona {
public:
    string cedula;
    string nombre1;
    string nombre2;
    string apellido;
    string correo;

    Persona(string cedula, string nombre1, string nombre2, string apellido, string correo) {
        this->cedula = cedula;
        this->nombre1 = nombre1;
        this->nombre2 = nombre2;
        this->apellido = apellido;
        this->correo = correo;
    }
};

class Empleado : public Persona {
public:
    string idEmpleado;
    Clave clave;
    string claveCifrada;
    double sueldo;

    Empleado(string idEmpleado, string cedula, string nombre1, string nombre2, string apellido, string correo, string clave, string claveCifrada, double sueldo)
        : Persona(cedula, nombre1, nombre2, apellido, correo), clave(clave), claveCifrada(claveCifrada) {
        this->idEmpleado = idEmpleado;
        this->sueldo = sueldo;
    }

    void setSueldo(double nuevoSueldo) {
        this->sueldo = nuevoSueldo;
    }
};

class Node {
public:
    Empleado* empleado;
    Node* next;
    Node* prev;

    Node(Empleado* empleado) : empleado(empleado), next(nullptr), prev(nullptr) {}
};

class DoublyLinkedList {
public:
    Node* head;
    Node* tail;

    DoublyLinkedList() : head(nullptr), tail(nullptr) {}

    void append(Empleado* empleado) {
        Node* newNode = new Node(empleado);
        if (!head) {
            head = tail = newNode;
        } else {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
    }

    Empleado* findByCedula(const string& cedula) {
        Node* current = head;
        while (current) {
            if (current->empleado->cedula == cedula) {
                return current->empleado;
            }
            current = current->next;
        }
        return nullptr;
    }

    void saveToFile(const string& filePath) {
        ofstream archivo(filePath, ios::trunc); // Modo de apertura para sobrescribir
        if (archivo.is_open()) {
            Node* current = head;
            while (current) {
                Empleado* empleado = current->empleado;
                archivo << empleado->idEmpleado << endl;
                archivo << empleado->nombre1 << " " << empleado->nombre2 << " " << empleado->apellido << endl;
                archivo << empleado->cedula << endl;
                archivo << empleado->correo << endl;
                archivo << empleado->clave.clave << endl;
                archivo << empleado->claveCifrada << endl;
                archivo << empleado->sueldo << endl;
                current = current->next;
            }
            archivo.close();
            cout << "Los datos han sido guardados y actualizados en '" << filePath << "'." << endl;
        } else {
            cout << "No se pudo abrir el archivo para escribir." << endl;
        }
    }
};

void cargarDatosExistentes(string filePath, map<string, int>& correosExistentes, map<string, int>& contrasenasExistentes, set<string>& cedulasExistentes, DoublyLinkedList& empleados, int& ultimoID) {
    ifstream archivo(filePath);
    if (archivo.is_open()) {
        string linea;
        while (getline(archivo, linea)) {
            string idEmpleado;
            string nombreCompleto;
            string cedula;
            string correo;
            string contrasena;
            string contrasenaCifrada;
            double sueldo;

            idEmpleado = linea;

            getline(archivo, nombreCompleto);
            getline(archivo, cedula);
            getline(archivo, correo);
            getline(archivo, contrasena);
            getline(archivo, contrasenaCifrada);
            archivo >> sueldo;
            archivo.ignore(); // Ignorar el salto de línea después del sueldo

            // Descomponer el nombre completo
            stringstream ss(nombreCompleto);
            string nombre1, nombre2, apellido;
            ss >> nombre1 >> nombre2 >> apellido;

            if (nombre2.empty() || apellido.empty()) {
                apellido = nombre2;
                nombre2 = "";
            }

            Empleado* empleado = new Empleado(idEmpleado, cedula, nombre1, nombre2, apellido, correo, contrasena, contrasenaCifrada, sueldo);
            empleados.append(empleado);

            cedulasExistentes.insert(cedula);

            // Verificar y procesar el correo para manejar los números al final
            size_t atPos = correo.find('@');
            if (atPos != string::npos) {
                string correoBase = correo.substr(0, atPos);
                size_t numPos = correoBase.find_last_not_of("0123456789");

                if (numPos != string::npos) {
                    string base = correoBase.substr(0, numPos + 1);
                    string numStr = correoBase.substr(numPos + 1);
                    int num = numStr.empty() ? 0 : stoi(numStr);
                    correosExistentes[base] = max(correosExistentes[base], num + 1);
                }
            }

            // Verificar y procesar la contraseña para manejar los números al final
            size_t numPos = contrasena.find_last_not_of("0123456789");
            if (numPos != string::npos) {
                string base = contrasena.substr(0, numPos + 1);
                string numStr = contrasena.substr(numPos + 1);
                int num = numStr.empty() ? 0 : stoi(numStr);
                contrasenasExistentes[base] = max(contrasenasExistentes[base], num + 1);
            }

            // Obtener el último ID
            if (idEmpleado.length() > 5) {
                try {
                    int idNum = stoi(idEmpleado.substr(5));
                    ultimoID = max(ultimoID, idNum);
                } catch (const std::invalid_argument& e) {
                    cerr << "Error al convertir ID de empleado a entero: " << e.what() << endl;
                }
            }
        }
        archivo.close();
    } else {
        cout << "No se pudo abrir el archivo para leer." << endl;
    }
}

bool validarCedula(const string& cedula) {
    return cedula.length() == 10 && all_of(cedula.begin(), cedula.end(), ::isdigit);
}

bool validarNombreApellido(const string& nombre) {
    if (nombre.length() < 2) {
        return false;
    }
    return all_of(nombre.begin(), nombre.end(), ::isalpha);
}

string cifrarContrasena(const string& contrasena) {
    string cifrada;
    for (char c : contrasena) {
        if (isalpha(c)) {
            if (islower(c)) {
                cifrada += (c - 'a' + 2) % 26 + 'a';
            } else {
                cifrada += (c - 'A' + 2) % 26 + 'A';
            }
        } else if (isdigit(c)) {
            cifrada += (c - '0' + 2) % 10 + '0';
        }
    }

    // Si no hay números en la contraseña original, agregar un '3' al final de la cifrada
    if (cifrada.find_first_of("0123456789") == string::npos) {
        cifrada += '3';
    }

    return cifrada;
}




string descifrarContrasena(const string& cifrada) {
    string contrasena;
    string cifrada_sin_3 = cifrada;

    // Si el último carácter es '3' y no hay números en la parte anterior de la cadena, eliminarlo
    if (cifrada.back() == '3' && cifrada.find_first_of("0123456789") == cifrada.size() - 1) {
        cifrada_sin_3.pop_back();
    }

    for (char c : cifrada_sin_3) {
        if (isalpha(c)) {
            if (islower(c)) {
                contrasena += (c - 'a' - 4 + 26) % 26 + 'a';
            } else {
                contrasena += (c - 'A' - 4 + 26) % 26 + 'A';
            }
        } else if (isdigit(c)) {
            contrasena += (c - '0' - 2 + 10) % 10 + '0';
        }
    }

    return contrasena;
}


string generarCorreo(map<string, int>& correosExistentes, const string& nombre1, const string& nombre2, const string& apellido) {
    string correoBase;
    correoBase += tolower(nombre1[0]); // Primera letra del primer nombre
    if (!nombre2.empty()) { // Comprobar si hay segundo nombre
        correoBase += tolower(nombre2[0]); // Primera letra del segundo nombre
    }

    // Convertir el apellido a minúsculas
    string apellidoMin = apellido;
    transform(apellidoMin.begin(), apellidoMin.end(), apellidoMin.begin(), ::tolower);

    correoBase += apellidoMin; // Apellido en minúsculas

    // Generar un correo único con números incrementales
    string correo = correoBase;
    if (correosExistentes[correoBase] > 0) {
        correo += to_string(correosExistentes[correoBase]);
    }
    correosExistentes[correoBase]++;
    correo += "@espe.edu.ec";

    return correo;
}

string generarContrasena(map<string, int>& contrasenasExistentes, const string& nombre1, const string& nombre2, const string& apellido) {
    string contrasenaBase;
    if (!nombre1.empty() && nombre1.length() >= 2) {
        contrasenaBase += nombre1[0];
    }
    if (!nombre2.empty() && nombre2.length() >= 1) {
        contrasenaBase += nombre2[0];
    }
    if (!apellido.empty() && apellido.length() >= 1) {
        contrasenaBase += apellido.back();
    }
    string apellidoReversed = apellido.substr(0, apellido.length() - 1);
    reverse(apellidoReversed.begin(), apellidoReversed.end());
    contrasenaBase += apellidoReversed;

    // Generar una contraseña única con números incrementales
    string contrasena = contrasenaBase;
    if (contrasenasExistentes[contrasenaBase] > 0) {
        contrasena += to_string(contrasenasExistentes[contrasenaBase]);
    }
    contrasenasExistentes[contrasenaBase]++;

    return contrasena;
}

string generarIDEmpleado(int& ultimoID) {
    ultimoID++;
    stringstream ss;
    ss << "espe-" << setw(3) << setfill('0') << ultimoID;
    return ss.str();
}

bool validarSueldo(const string& sueldo) {
    bool puntoEncontrado = false;
    bool comaEncontrada = false;
    for (char c : sueldo) {
        if (isdigit(c)) {
            continue;
        } else if (c == '.') {
            if (puntoEncontrado || comaEncontrada) {
                return false;
            }
            puntoEncontrado = true;
        } else if (c == ',') {
            if (comaEncontrada || puntoEncontrado) {
                return false;
            }
            comaEncontrada = true;
        } else {
            return false;
        }
    }
    return true;
}

double pedirSueldo() {
    string sueldoStr;
    do {
        cout << "Ingrese el sueldo (solo un punto o una coma permitidos): ";
        getline(cin, sueldoStr);
        if (!validarSueldo(sueldoStr)) {
            cout << "Entrada inválida. Asegúrese de ingresar un número válido con solo un punto o una coma." << endl;
        }
    } while (!validarSueldo(sueldoStr));

    replace(sueldoStr.begin(), sueldoStr.end(), ',', '.'); // Reemplazar coma por punto para convertir a double
    return stod(sueldoStr);
}

void agregarEmpleado(DoublyLinkedList& empleados, map<string, int>& correosExistentes, map<string, int>& contrasenasExistentes, set<string>& cedulasRegistradas, int& ultimoID) {
    string primerNombre, segundoNombre, primerApellido, cedula;
    double sueldo;

    cout << "\nCREACIÓN DE NUEVO EMPLEADO" << endl;

    do {
        cout << "\nIngrese el primer nombre (mínimo 2 letras): ";
        getline(cin, primerNombre);
    } while (!validarNombreApellido(primerNombre));

    cout << "Ingrese el segundo nombre (o dejar vacío si no tiene): ";
    getline(cin, segundoNombre);

    do {
        cout << "Ingrese el primer apellido (mínimo 2 letras): ";
        getline(cin, primerApellido);
    } while (!validarNombreApellido(primerApellido));

    do {
        cout << "Ingrese la cédula (10 dígitos): ";
        getline(cin, cedula);
    } while (!validarCedula(cedula) || cedulasRegistradas.count(cedula));

    sueldo = pedirSueldo();

    // Generar el correo y la contraseña
    string correo = generarCorreo(correosExistentes, primerNombre, segundoNombre, primerApellido);
    string contrasena = generarContrasena(contrasenasExistentes, primerNombre, segundoNombre, primerApellido);
    string contrasenaCifrada = cifrarContrasena(contrasena);
    string generarContrasena= descifrarContrasena(contrasena);

    // Generar el ID del empleado
    string idEmpleado = generarIDEmpleado(ultimoID);

    // Crear y agregar el nuevo empleado a la lista
    Empleado* nuevoEmpleado = new Empleado(idEmpleado, cedula, primerNombre, segundoNombre, primerApellido, correo, contrasena, contrasenaCifrada, sueldo);
    empleados.append(nuevoEmpleado);
    cedulasRegistradas.insert(cedula); // Registrar la nueva cédula

    cout << "\nEmpleado creado exitosamente:" << endl;
    cout << "ID Empleado: " << idEmpleado << endl;
    cout << "Nombre completo: " << primerNombre << " " << segundoNombre << " " << primerApellido << endl;
    cout << "Cédula: " << cedula << endl;
    cout << "Correo electrónico: " << correo << endl;
    cout << "Contraseña generada: " << contrasena << endl;
    cout << "Contraseña cifrada: " << contrasenaCifrada << endl;
    cout << "contraseña descifrada: " << generarContrasena << endl;
    cout << "Sueldo: $" << fixed << setprecision(2) << sueldo << endl;
}

void buscarEmpleadoPorCedula(DoublyLinkedList& empleados, const string& cedulaBusqueda, const string& filePath) {
    Empleado* empleado = empleados.findByCedula(cedulaBusqueda);
    if (empleado) {
        cout << "\nEmpleado encontrado:" << endl;
        cout << "ID Empleado: " << empleado->idEmpleado << endl;
        cout << "Nombre completo: " << empleado->nombre1 << " " << empleado->nombre2 << " " << empleado->apellido << endl;
        cout << "Cédula: " << empleado->cedula << endl;
        cout << "Correo electrónico: " << empleado->correo << endl;
        cout << "Sueldo actual: $" << fixed << setprecision(2) << empleado->sueldo << endl;

        double nuevoSueldo = pedirSueldo();
        empleado->setSueldo(nuevoSueldo);

        cout << "Sueldo actualizado correctamente." << endl;

        // Guardar datos después de la actualización
        empleados.saveToFile(filePath);
    } else {
        cout << "No se encontró ningún empleado con la cédula ingresada." << endl;
    }
}

void mostrarMenu() {
    cout << "\nMENU:" << endl;
    cout << "1. Crear nuevo empleado" << endl;
    cout << "2. Buscar empleado por cédula y actualizar sueldo" << endl;
    cout << "3. Salir del programa" << endl;
    cout << "Ingrese la opción deseada (1-3): ";
}

int main() {
    DoublyLinkedList empleados;
    map<string, int> correosExistentes;
    map<string, int> contrasenasExistentes;
    set<string> cedulasRegistradas;
    int ultimoID = 0;

    string homePath = getenv("HOME"); // Obtener el directorio home del usuario
    string filePath = homePath + "/Downloads/correosTG.txt";

    cargarDatosExistentes(filePath, correosExistentes, contrasenasExistentes, cedulasRegistradas, empleados, ultimoID); // Cargar datos existentes del archivo

    int opcion;
    do {
        mostrarMenu();
        while (!(cin >> opcion)) {
            cout << "Opción no válida. Ingrese una opción del 1 al 3: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Limpiar el buffer de entrada

        switch (opcion) {
            case 1:
                agregarEmpleado(empleados, correosExistentes, contrasenasExistentes, cedulasRegistradas, ultimoID);
                empleados.saveToFile(filePath); // Guardar datos después de agregar un nuevo empleado
                break;
            case 2:
                {
                    string cedulaBusqueda;
                    cout << "Ingrese la cédula del empleado a buscar: ";
                    getline(cin, cedulaBusqueda);
                    buscarEmpleadoPorCedula(empleados, cedulaBusqueda, filePath);
                }
                break;
            case 3:
                cout << "Saliendo del programa..." << endl;
                break;
            default:
                cout << "Opción no válida. Ingrese una opción del 1 al 3." << endl;
        }
    } while (opcion != 3);

    return 0;
}
