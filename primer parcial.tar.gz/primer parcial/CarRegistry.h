
#ifndef CAR_REGISTRY_H
#define CAR_REGISTRY_H

#include <string>

struct CarNode {
    std::string nombre;
    int edad;
    std::string placa;
    std::string cedula;
    CarNode* siguiente;
    CarNode* anterior;

    CarNode(std::string n, int e, std::string p, std::string c);
};

class CarRegistry {
public:
    CarRegistry();
    ~CarRegistry();

    void insertar(std::string nombre, int edad, std::string placa, std::string cedula);
    void eliminar(std::string cedula, std::string placa);
    CarNode* buscar(std::string cedula, std::string placa);
    void buscarPorCedula(std::string cedula);
    void mostrar();
    void guardarEnArchivo(const std::string& filename);

private:
    CarNode* cabeza;
};

#endif // CAR_REGISTRY_H

